<?php
namespace Company\Custompage\Block;
class Say extends \Magento\Framework\View\Element\Template
{

	
}