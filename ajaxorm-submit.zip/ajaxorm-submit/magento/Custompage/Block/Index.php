<?php
namespace Company\Custompage\Block;
 
use Magento\Framework\View\Element\Template\Context;
use Company\Custompage\Model\News;
use Magento\Framework\View\Element\Template;

class Index extends Template{
	
	protected $myModuleHelper;
	
	public function __construct(Context $context, News $model, \Company\Custompage\Helper\Data $myModuleHelper){		
		$this->model = $model;
		parent::__construct($context);
		$this->_mymoduleHelper = $myModuleHelper;

	}

	public function getNewshelper()	{
		return $this->_mymoduleHelper->getNewsInfo();                                                                                                      
	}
	
	 public function getNewsCollection(){
            $helloCollection = $this->model->getCollection();
            return $helloCollection;
     }
	 
	 public function getFormAction(){
        return $this->getUrl('custompage/index/post', ['_secure' => true]);
    }
		
		
	/*public function testMethod()	{
		return __('testMethod');
	}*/
}