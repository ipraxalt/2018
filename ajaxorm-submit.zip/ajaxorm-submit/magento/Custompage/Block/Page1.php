<?php
namespace Company\Custompage\Block;
class Page1 extends \Magento\Framework\View\Element\Template
{
	
}