<?php 
namespace Company\Custompage\Helper;
use Magento\Framework\App\Helper\AbstractHelper;     
 
class Data extends AbstractHelper {    
    /**
     * Return if display list is enabled on department view
     * @return bool
     */
    public function getNewsInfo() {
		return 'NewsInfo helper call##';
    }
	
	 public function getTestinghelp() {
        return 1;
    }	
}