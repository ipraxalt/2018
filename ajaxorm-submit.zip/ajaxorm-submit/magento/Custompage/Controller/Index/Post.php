<?php
namespace Company\Custompage\Controller\Index; 
use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\ResultFactory;
 
class Post extends Action{
    public function execute(){
		
            $title = $this->getRequest()->getPostValue("title");
			$desc = $this->getRequest()->getPostValue("desc");
		    $email = $this->getRequest()->getPostValue("email");
			
			
            $item = $this->_objectManager->create("Company\Custompage\Model\News");
            $item->setTitle($title);
			$item->setDesc($desc);
			$item->setEmail($email);
			  
            $item->save();
			
            $redirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            //$redirect->setUrl($this->_redirect->getRefererUrl());
             //  $redirect->setUrl("/magento21/custompage");
            //return $redirect;
			 $this->messageManager->addSuccess(
                __('Thanks for contacting us')
            );
			
			$redirect->setUrl("/Magento21/custompage");
            return $redirect;
			
	}
}