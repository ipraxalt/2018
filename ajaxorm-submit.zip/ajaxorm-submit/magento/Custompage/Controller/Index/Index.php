<?php
namespace Company\Custompage\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Company\Custompage\Model\NewsFactory;

class Index extends \Magento\Framework\App\Action\Action
{
	 protected $_modelNewsFactory;
	 
	 public function __construct(
	        Context $context,
	        NewsFactory $modelNewsFactory
    ) {
	        parent::__construct($context);
	        $this->_modelNewsFactory = $modelNewsFactory;
    }
	 

	public function execute()	{
		//echo 'Execute Action Page1_Say';
		//die();
		$this->_view->loadLayout();
        $this->_view->getLayout()->initMessages();
        $this->_view->renderLayout();
		
      /*$newsModel = $this->_modelNewsFactory->create(); 
       $item = $newsModel->load(1);
      var_dump($item->getData());
 
            $newsCollection = $newsModel->getCollection();
        var_dump($newsCollection->getData());*/
	}
}
