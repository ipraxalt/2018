<?php
namespace Company\Custompage\Controller\Index; 
use Magento\Framework\Controller\ResultFactory;

 
class Posttest extends \Magento\Framework\App\Action\Action{
	
	
	 /**
     * @var \Magento\Framework\Translate\Inline\ParserInterface
     */
    protected $inlineParser;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $resultJsonFactory;

   

    /**
     * @param Action\Context $context
     * @param \Magento\Framework\Translate\Inline\ParserInterface $inlineParser
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Translate\Inline\ParserInterface $inlineParser,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
    ) {
        parent::__construct($context);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->inlineParser = $inlineParser;
    }

	
	
	
    public function execute(){
		
		    $title  = $_POST["title"]; 
		    $linkurl = $_POST["letter"];
			$resultMessage='User email details not correct';
			
			/** @var \Magento\Framework\Controller\Result\Json $resultJson */
        $resultJson = $this->resultJsonFactory->create();
        /*try {
            //$this->inlineParser->processAjaxPost($translate);
            $response = ['success' => 'true'];
        } catch (\Exception $e) {
            $response = ['error' => 'true', 'message' => $e->getMessage()];
        }*/

		 $response = ['status' => '1', 'message' => $resultMessage ];
		 
       return $resultJson->setData($response);

			//echo json_encode(array('status'=>'1','message'=>$resultMessage));
			//die;
            /*$fname = $this->getRequest()->getPostValue("fname");
			$phone = $this->getRequest()->getPostValue("phone");
		    $email = $this->getRequest()->getPostValue("email");			
			$date = '';
			$country = $this->getRequest()->getPostValue("country");
		    $state = $this->getRequest()->getPostValue("state");
			
			$item = $this->_objectManager->create("Company\Test\Model\Test");
            $item->setName($fname);
			$item->setPhone($phone);
			$item->setEmail($email);			
			$item->setdate($date);
			$item->setCountry($country);
			$item->setState($state);			  
            $item->save();
			
            $redirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            //$redirect->setUrl($this->_redirect->getRefererUrl());
            //$redirect->setUrl("/magento21/test");
            //return $redirect;
			
    		$this->messageManager->addSuccess( __('Thanks for contacting us'));			
			
			$redirect->setUrl("/Magento21/test");
			
            return $redirect;*/
			
	}
}