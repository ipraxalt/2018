<?php
namespace Company\Custompage\Controller\Add; 
use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\ResultFactory;
 
class Index extends Action{
    public function execute(){
            $title = $this->getRequest()->getPostValue("title");
			$desc = $this->getRequest()->getPostValue("desc");
			$email = $this->getRequest()->getPostValue("email");
			
            $item = $this->_objectManager->create("Company\Custompage\Model\News");
            $item->setTitle($title);
			$item->setDesc($desc);
			$item->setEmail($email);
			  
            $item->save();
            $redirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            //$redirect->setUrl($this->_redirect->getRefererUrl());
               $redirect->setUrl("/Magento21/custompage/");
            return $redirect;
	}
}