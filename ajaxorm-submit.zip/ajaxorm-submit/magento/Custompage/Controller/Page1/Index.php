<?php
namespace Company\Custompage\Controller\Page1;

class Index extends \Magento\Framework\App\Action\Action
{
	public function execute()	{
		//echo 'Execute Action Page1_Say';
		//die();
		$this->_view->loadLayout();
        $this->_view->getLayout()->initMessages();
        $this->_view->renderLayout();
	}
}
