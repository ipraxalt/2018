require(["jquery"], function($){
    alert("retro custompage");
});