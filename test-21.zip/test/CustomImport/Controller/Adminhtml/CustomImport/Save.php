<?php
namespace Escorts\CustomImport\Controller\Adminhtml\CustomImport;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\MediaStorage\Model\File\UploaderFactory;
class Save extends \Magento\Backend\App\Action
{
    
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory
    ) {
        parent::__construct($context);
        $this->_fileUploaderFactory = $fileUploaderFactory;
    }

	public function execute()
    {
		
        $data = $this->getRequest()->getParams();
        if ($data) {
            $model = $this->_objectManager->create('Escorts\CustomImport\Model\CustomImport');
		
            // echo "<pre>"; print_r($_FILES); echo "</pre>"; exit();
            if(isset($_FILES['upload']['name']) && $_FILES['upload']['name'] != '') {
				try {
					    // $uploader = $this->_objectManager->create('Magento\Core\Model\File\Uploader', array('fileId' => 'image'));
                        $uploader = $this->_fileUploaderFactory->create(array('fileId' => 'upload'));
						$uploader->setAllowedExtensions(array('csv'));
						$uploader->setAllowRenameFiles(true);
						$uploader->setFilesDispersion(false);
						$mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')
							->getDirectoryRead(DirectoryList::MEDIA);
						// $config = $this->_objectManager->get('Magento\Bannerslider\Model\Banner');
						$result = $uploader->save($mediaDirectory->getAbsolutePath('escorts/import'));
                        echo "<pre>"; print_r($result); echo "</pre>";
                        if ($result['file']) {
                            $filePath = $result['path'].'/'.$result['file'];
                            $handle=fopen($filePath, 'r');
                            $row = 0;
                            while (($_fileData = fgetcsv($handle)) !== FALSE)
                            {
                                if ($row > 0) {
                                    echo "<pre>"; print_r($_fileData); echo "</pre>";    
                                }
                                $row++;
                            }
                        }
                        exit();
						unset($result['tmp_name']);
						unset($result['path']);
						$data['image'] = $result['file'];
				} catch (Exception $e) {
					$data['file'] = $_FILES['upload']['name'];
				}
			}
			
            exit();
			$id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
            }
			
            $model->setData($data);
			
            try {
                $model->save();
                $this->messageManager->addSuccess(__('The Frist Grid Has been Saved.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    $this->_redirect('*/*/edit', array('id' => $model->getId(), '_current' => true));
                    return;
                }
                $this->_redirect('*/*/');
                return;
            } catch (\Magento\Framework\Model\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the banner.'));
            }

            $this->_getSession()->setFormData($data);
            $this->_redirect('*/*/edit', array('banner_id' => $this->getRequest()->getParam('banner_id')));
            return;
        }
        $this->_redirect('*/*/');
    }
}
