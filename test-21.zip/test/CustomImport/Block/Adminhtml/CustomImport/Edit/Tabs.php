<?php
namespace Escorts\CustomImport\Block\Adminhtml\CustomImport\Edit;

class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    protected function _construct()
    {
		
        parent::_construct();
        $this->setId('checkmodule_customimport_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Custom Import Information'));
    }
}