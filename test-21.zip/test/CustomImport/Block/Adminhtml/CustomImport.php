<?php
namespace Escorts\CustomImport\Block\Adminhtml;
class CustomImport extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
		
        $this->_controller = 'adminhtml_customImport';/*block grid.php directory*/
        $this->_blockGroup = 'Escorts_CustomImport';
        $this->_headerText = __('Custom Import');
        $this->_addButtonLabel = __('Add New Entry'); 
        parent::_construct();
		$this->removeButton('add');
    }
}
