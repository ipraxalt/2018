<?php
/**
 * Copyright © 2015 Escorts. All rights reserved.
 */
namespace Escorts\CustomImport\Model\ResourceModel;

/**
 * CustomImport resource
 */
class CustomImport extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('customimport_customimport', 'id');
    }

  
}
