<?php
namespace Escorts\ProjectOfficer\Block\Adminhtml\ProjectOfficer\Edit;

class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    protected function _construct()
    {
		
        parent::_construct();
        $this->setId('checkmodule_projectofficer_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('ProjectOfficer Information'));
    }
}