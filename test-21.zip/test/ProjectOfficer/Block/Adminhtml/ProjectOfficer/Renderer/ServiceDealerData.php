<?php

namespace Escorts\ProjectOfficer\Block\Adminhtml\ProjectOfficer\Renderer;

use Magento\Framework\DataObject;

class ServiceDealerData extends \Magento\Framework\Data\Form\Element\AbstractElement
{
    protected $_backendUrl;
    protected $request;
   /**
    * @param  \Escorts\ProjectOfficer\Helper\Data
    */
    protected $_helperObject;
  
    public function __construct( 
        \Magento\Backend\Model\UrlInterface $backendUrl,       
        \Magento\Framework\App\Request\Http $request,
         \Escorts\ProjectOfficer\Helper\Data $helperObject     
    ) {      
        $this->request = $request;
        $this->_backendUrl = $backendUrl;
        $this->_helperObject = $helperObject;
    }



   
    public function getAfterElementHtml(){
      $poId = $this->request->getParam('id');
     
        $downloadLink="";$customerData=[];

         if(!empty($poId)){     
                    $customerData= $this->_helperObject->getServiceDealerDetails($poId);
                    if(!empty($customerData)){
                     if(!empty($customerData['customername'])){
                    $resultData = "<p>Name: ".$customerData['customername']."</p>";
                    }

                     if(!empty($customerData['vendorcode'])){

                    $resultData =  $resultData."<p>VendorCode: ".$customerData['vendorcode']."</p>";
                    }

                    if(!empty($customerData['mobile'])){
                    $resultData =  $resultData."<p>Mobile: ".$customerData['mobile']."</p>";
                    }
                    if(!empty($customerData['Address'])){

                      $resultData =  $resultData."<p>Address: ".$customerData['Address']."</p>";
                    }

                    if(!empty($customerData['postcode'])){
                         $resultData =  $resultData."<p>PostCode: ".$customerData['postcode']."</p>";
                    }                  
                     return $resultData;
                }                       
       
        }             
        return $downloadLink;
    }

}