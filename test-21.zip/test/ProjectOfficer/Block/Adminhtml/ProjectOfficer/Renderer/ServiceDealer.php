<?php   
namespace Escorts\ProjectOfficer\Block\Adminhtml\ProjectOfficer\Renderer;
 
use Magento\Framework\DataObject;
 
class ServiceDealer extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer
{
      
    /**
    * @param  \Escorts\ProjectOfficer\Helper\Data
    */
    protected $_helperObject;

    public function __construct(       
        \Escorts\ProjectOfficer\Helper\Data $helperObject  
    ){          
        $this->_helperObject = $helperObject;
    }
 
    /**
     * get ServiceDealer
     * @param  DataObject $row
     * @return string
     */
  
      public function render(DataObject $row){
        $resultData="";       
        $poId = $row->getPoId();
       if(!empty($poId)){               
               
                 $resultData= $this->_helperObject->getServiceDealerName($poId);
                if(!empty($resultData)){
                     return $resultData;
                }               
        }   
        return $resultData;
    }

}