<?php
 
namespace Escorts\ProjectOfficer\Block\Adminhtml\ProjectOfficer\Renderer;
 
use Magento\Framework\DataObject;
 
class PoItemCount extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer
{
      
    /**
    * @param  \Escorts\ProjectOfficer\Helper\Data
    */
    protected $_helperObject;

    public function __construct(       
        \Escorts\ProjectOfficer\Helper\Data $helperObject  
    ){          
        $this->_helperObject = $helperObject;
    }
 
    /**
     * get PoItemCount
     * @param  DataObject $row
     * @return string
     */
  
      public function render(DataObject $row){
        $poItemCount=0;       
        $poId = $row->getPoId();
       if(!empty($poId)){               
                $countValue= $this->_helperObject->getPoItemCount($poId);
                if(!empty($countValue)){
                     return $countValue;
                }               
        }   
        return $poItemCount;
    }

}