<?php
/**
 * Copyright © 2015 Escorts. All rights reserved.
 */
namespace Escorts\ProjectOfficer\Model\ResourceModel;

/**
 * ProjectOfficer resource
 */
class ProjectOfficer extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('escorts_edms_po', 'po_id');
    }

  
}
