<?php
/**
 * Copyright © 2015 Escorts . All rights reserved.
 */
namespace Escorts\ProjectOfficer\Helper;
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	protected $_timezone;
	protected $_edmsPo;
	protected $_edmsPoItem;
	 protected $_commonHelper;  
	 protected $_distributors; 
  
	/**
    * @param \Magento\Framework\App\Helper\Context $context
    */
	public function __construct(
			\Magento\Framework\App\Helper\Context $context,
			\Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
			\Escorts\SpareParts\Model\EdmsPoFactory $edmsPoFactory,
			\Escorts\SpareParts\Model\EdmsPoItemFactory $edmsPoItemFactory,
			\Escorts\Distributors\Model\DistributorsFactory $distributorsFactory,
			\Escorts\Common\Helper\Data $commonHelper
	) {
			$this->_timezone = $timezone;    
			$this->_edmsPo = $edmsPoFactory;
			$this->_edmsPoItem = $edmsPoItemFactory;  
			$this->_commonHelper = $commonHelper;
			$this->_distributors = $distributorsFactory;
			parent::__construct($context);
	}

	   public function getPoItemCount($poId) {
        $itemCount = 0;
        try {
		        	$edmsPoItem = $this->_edmsPoItem->create()->getCollection();
		        	$edmsPoItem->addFieldToSelect('po_id');
		            $edmsPoItem->addFieldToFilter('po_id', $poId);
		            if($edmsPoItem->getSize()){
		                  $itemCount = $edmsPoItem->getSize(); 		                     
		            }              
        } catch (\Exception $e) {
              $itemCount = 0;
              //\Zend_Debug::dump($e->getMessage());
        }
        return $itemCount;
    }

    
     /*Admin Grid*/
     public function getDistributorName($poId) {
        $resultData = "";
        try {
		        	$edmsPo = $this->_edmsPo->create()->load($poId);
		             if (!empty($distributorId = $edmsPo->getDistributorId())) {
		                    $distributorModel = $this->_distributors->create()->load($distributorId);	             	   	             	   
		             	    $customerName = $distributorModel->getname();
                            $vendorCode = $distributorModel->getVendorCode();		                  		
		                    $resultData =  $customerName.' ('.$vendorCode.')';      
		                    return $resultData;              
		            }              
        } catch (\Exception $e) {             
              //\Zend_Debug::dump($e->getMessage());
        }
        return $resultData;
    }


     /*Admin Grid*/
     public function getServiceDealerName($poId) {
       $resultData = "";
        try {
		        	 //$edmsPo = $this->_edmsPo->create()->load($poId);	      
		             $paymentCollection = $this->_edmsPo->create()->getCollection();
                     $paymentCollection->getSelect()
					                    ->join(['secondTable' => $paymentCollection->getTable('escorts_custom_cart')], "main_table.cart_id= secondTable.cart_id"
					                    )->where('main_table.po_id=' . $poId);		             	   	             	   
                     if (!empty($paymentCollection->getSize())) {
                     	    $cartData = $paymentCollection->getFirstItem()->getData();
                            $customerId = $cartData['customer_id'];
		             	    $customerName = $this->_commonHelper->getCustomerNameById($customerId);
                            $vendorCode = $this->_commonHelper->getCustomerVendorCodeById($customerId);		                  		
		                    $resultData =  $customerName.' ('.$vendorCode.')';      
		                     return $resultData;              
		            }              
        } catch (\Exception $e) {             
              //\Zend_Debug::dump($e->getMessage());
        }
        return $resultData;
    }


    /*Admin Block*/
     public function getServiceDealerDetails($poId) {
       $resultData = [];
        try {
		        	 //$edmsPo = $this->_edmsPo->create()->load($poId);	      
		             $paymentCollection = $this->_edmsPo->create()->getCollection();
                     $paymentCollection->getSelect()
					                    ->join(['secondTable' => $paymentCollection->getTable('escorts_custom_cart')], "main_table.cart_id= secondTable.cart_id"
					                    )->where('main_table.po_id=' . $poId);		             	   	             	   
                     if (!empty($paymentCollection->getSize())) {
                     	    $cartData = $paymentCollection->getFirstItem()->getData();
                     	    $customerId = $cartData['customer_id'];;
                            $resultData['customerid'] = $cartData['customer_id'];
                           
                            $resultData['customername'] = $this->_commonHelper->getCustomerNameById($customerId);
                            $resultData['mobile'] = $this->_commonHelper->getCustomerMobileByID($customerId);
                            $resultData['vendorcode'] = $this->_commonHelper->getCustomerVendorCodeById($customerId);
                            $resultData['Address'] = $this->_commonHelper->getCustomerAddressByCustomerId($customerId);
                            $resultData['postcode'] = $this->_commonHelper->getCustomerPostCodeByID($customerId);
		                    return $resultData;              
		            }              
        } catch (\Exception $e) {             
              //\Zend_Debug::dump($e->getMessage());
        }
        return $resultData;
    }
}


  
 
  
