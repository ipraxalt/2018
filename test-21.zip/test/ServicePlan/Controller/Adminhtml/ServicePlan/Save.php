<?php
namespace Escorts\ServicePlan\Controller\Adminhtml\ServicePlan;
use Magento\Framework\App\Filesystem\DirectoryList;
class Save extends \Magento\Backend\App\Action
{

    /**
     * @var \Escorts\ServicePlan\Model\ServicePlanItemsFactory $servicePlanItemsFactory
     */
    protected $servicePlanItemsFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Escorts\ServicePlan\Model\ServicePlanItemsFactory $servicePlanItemsFactory
    ) {
        $this->servicePlanItemsFactory = $servicePlanItemsFactory;
        parent::__construct($context);
    }
    
	public function execute()
    {
		
        $data = $this->getRequest()->getParams();
        // echo "<pre>"; print_r($data); echo "</pre>"; exit();
        
        if ($data) {
            $model = $this->_objectManager->create('Escorts\ServicePlan\Model\ServicePlan');
            
			$id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
            }
			//echo "<pre>"; print_r($data); echo "</pre>"; exit();
            $model->setData($data);
			
            try {
                $model->save();


                $_serviceType = $data['service_type'];
                $_hours = $data['hours'];
                $_days = $data['days'];
                $_reimburshment = $data['reimburshment'];
                $conveyance_charges = $data['conveyance_charges'];
                $_sortOrder = $data['sort_order'];

                $_colletions = $this->servicePlanItemsFactory->create()->getCollection();
                $_colletions->addFieldToFilter('setvice_plan_id', ['eq' => $model->getId()]);

                if (!$_colletions->getSize()) {
                    $k = 0;
                    foreach ($_serviceType as $serviceType) {
                        if (!empty($serviceType)) {
                            $serviceItemModel = $this->servicePlanItemsFactory->create();
                            $serviceItemModel->setTitle($serviceType);
                            $serviceItemModel->setHours($_hours[$k]);
                            $serviceItemModel->setDays($_days[$k]);
                            $serviceItemModel->setReimburshment($_reimburshment[$k]);
                            $serviceItemModel->setConveyanceCharges($conveyance_charges[$k]);
                            $serviceItemModel->setSetvicePlanId($model->getId());
                            $serviceItemModel->setSortOrder($_sortOrder[$k]);
                            $serviceItemModel->save();
                            $serviceItemModel->unsetData();
                        }
                        $k++;
                    }
                } else {
                    $k = 0;
                    foreach ($_serviceType as $_id => $serviceType) {
                        $_colletions = $this->servicePlanItemsFactory->create()->getCollection();
                        $_colletions->addFieldToFilter('setvice_plan_id', ['eq' => $model->getId()])
                                    ->addFieldToFilter('id', ['eq' => $_id]);
                        //echo "<pre>*******"; print_r($_colletions->getData()); echo "</pre>";
                        if ($_colletions->getSize()) {
                            $serviceItemModel = $this->servicePlanItemsFactory->create()->load($_id);
                            $serviceItemModel->setTitle($serviceType);
                            $serviceItemModel->setHours($_hours[$_id]);
                            $serviceItemModel->setDays($_days[$_id]);
                            $serviceItemModel->setReimburshment($_reimburshment[$_id]);
                            $serviceItemModel->setConveyanceCharges($conveyance_charges[$_id]);
                            $serviceItemModel->setSetvicePlanId($model->getId());
                            $serviceItemModel->setSortOrder($_sortOrder[$_id]);
                            $serviceItemModel->save();
                            $serviceItemModel->unsetData();
                        } else {
                            $serviceItemModel = $this->servicePlanItemsFactory->create();
                            $serviceItemModel->setTitle($serviceType);
                            $serviceItemModel->setHours($_hours[$_id]);
                            $serviceItemModel->setDays($_days[$_id]);
                            $serviceItemModel->setReimburshment($_reimburshment[$_id]);
                            $serviceItemModel->setConveyanceCharges($conveyance_charges[$_id]);
                            $serviceItemModel->setSetvicePlanId($model->getId());
                            $serviceItemModel->setSortOrder($_sortOrder[$_id]);
                            $serviceItemModel->save();
                            $serviceItemModel->unsetData();
                        }
                        $k++;
                    }
                }

                // exit();

                $this->messageManager->addSuccess(__('The Service Plan Items Has been Saved.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    $this->_redirect('*/*/edit', array('id' => $model->getId(), '_current' => true));
                    return;
                }
                $this->_redirect('*/*/');
                return;
            } catch (\Magento\Framework\Model\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            } /*catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the service plan items.'));
            }*/

            $this->_getSession()->setFormData($data);
            $this->_redirect('*/*/edit', array('banner_id' => $this->getRequest()->getParam('banner_id')));
            return;
        }
        $this->_redirect('*/*/');
    }
}
