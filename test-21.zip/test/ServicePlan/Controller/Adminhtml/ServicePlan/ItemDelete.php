<?php
namespace Escorts\ServicePlan\Controller\Adminhtml\ServicePlan;

class ItemDelete extends \Magento\Backend\App\Action
{

    protected $servicePlanItemsFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Escorts\ServicePlan\Model\ServicePlanItemsFactory $servicePlanItemsFactory
    ){
        $this->servicePlanItemsFactory = $servicePlanItemsFactory;
        parent::__construct($context);
    }

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    public function execute()
    {
		$id = $this->getRequest()->getParam('item_id');
        $service_id = $this->getRequest()->getParam('service_id');
        /*exit();*/
		try {
			$sparePartsItem = $this->servicePlanItemsFactory->create()->load($id);
            /*echo "<pre>++++"; print_r($sparePartsItem->getData()); echo "</pre>";
            exit();*/
			$sparePartsItem->delete();
            $this->messageManager->addSuccess(
                __('Delete successfully !')
            );
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
	    $this->_redirect('*/*/edit', ['id' => $service_id, '_current' => true]);
    }
}
