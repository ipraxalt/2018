<?php
namespace Escorts\ServicePlan\Block\Adminhtml;
class ServicePlan extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
		
        $this->_controller = 'adminhtml_servicePlan';/*block grid.php directory*/
        $this->_blockGroup = 'Escorts_ServicePlan';
        $this->_headerText = __('Service Plan');
        $this->_addButtonLabel = __('Add New'); 
        parent::_construct();
		
    }
}
