<?php

namespace Escorts\ServicePlan\Block\Adminhtml\ServicePlan\Edit\Tab;


class ServicePlanItems extends \Magento\Backend\Block\Template implements \Magento\Backend\Block\Widget\Tab\TabInterface 
{

    /**
	 * @var \Escorts\ServicePlan\Model\ServicePlanItemsFactory $servicePlanItemsFactory
	 */
	protected $servicePlanItemsFactory;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Escorts\ServicePlan\Model\ServicePlanItemsFactory $servicePlanItemsFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Escorts\ServicePlan\Model\ServicePlanItemsFactory $servicePlanItemsFactory,
        array $data = array()
    ) {
        $this->servicePlanItemsFactory = $servicePlanItemsFactory;
        parent::__construct($context, $data);
    }


	public function getServicePlanId()
	{
		return $this->getRequest()->getParam('id');
	}

	public function getServicePlanItemCollection()
	{
		if ($this->getServicePlanId()) {
			$itemCollection = $this->servicePlanItemsFactory->create()->getCollection();
			$itemCollection->addFieldToFilter('setvice_plan_id', ['eq' => $this->getServicePlanId()]);
			$itemCollection->setOrder('sort_order','ASC');
			return $itemCollection;
		}
	}



	/**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel() {
        return __('Service Plan Items');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle() {
        return __('Service Plan Items');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab() {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden() {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId) {
        return $this->_authorization->isAllowed($resourceId);
    }
}