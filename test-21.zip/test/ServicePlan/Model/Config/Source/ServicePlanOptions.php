<?php

namespace Escorts\ServicePlan\Model\Config\Source;

use Magento\Eav\Model\ResourceModel\Entity\Attribute\OptionFactory;
use Magento\Framework\DB\Ddl\Table;

/**
 * Custom Attribute Renderer
 */
class ServicePlanOptions extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource {

    /**
     * @var OptionFactory
     */
    protected $optionFactory;
    /**
     * @param OptionFactory $optionFactory
     */

    /**
     * @var Object
     */
    protected $servicePlanFactory;

    public function __construct(
    \Escorts\ServicePlan\Model\ServicePlanFactory $servicePlanFactory
    ) {
        $this->servicePlanFactory = $servicePlanFactory;
    }

    /**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions() {
        $servicePlan = $this->servicePlanFactory->create();
        $collection = $servicePlan->getCollection();
        foreach ($collection as $item) {
            $arr = $item->getData();
            $this->_options[] = ['label' => $arr['title'], 'value' => $arr['id']];
        }
        return $this->_options;
    }

}
