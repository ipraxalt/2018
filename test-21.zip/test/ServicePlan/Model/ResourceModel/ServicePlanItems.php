<?php
/**
 * Copyright © 2015 Escorts. All rights reserved.
 */
namespace Escorts\ServicePlan\Model\ResourceModel;

/**
 * ServicePlanItems resource
 */
class ServicePlanItems extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('escorts_service_plan_item', 'id');
    }

  
}
