<?php

namespace Escorts\Warrantyplan\Controller\Index;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\ResultFactory;

class Index extends Action {

    protected $resultJsonFactory;

    public function __construct(
         //  Context  $context

    ) {

      //  parent::__construct($context);
    }


    public function execute() {
    /* @var \Magento\Framework\Controller\Result\Json $result */
       echo 'Hiii'; exit;
        $resultJson = $this->resultJsonFactory->create(ResultFactory::TYPE_JSON);
        return $resultJson->setData(['success' => true]);
   } 
}
