<?php
namespace Escorts\Warrantyplan\Controller\Adminhtml\PartsDescription;
use Magento\Framework\App\Filesystem\DirectoryList;
class Index extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */


    /**
     * @var \Escorts\SpareParts\Model\SparePartsFactory
     */
    protected $sparePartsFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Escorts\SpareParts\Model\SparePartsFactory $sparePartsFactory
    ) {
        $this->sparePartsFactory = $sparePartsFactory;
        parent::__construct($context);
    }


	public function execute()
    {
        $catId = $this->getRequest()->getParam('catid');
        $sparepartCollection = $this->sparePartsFactory->create()->getCollection();;
        $sparepartCollection->addFieldToFilter('category_id', ['eq' => $catId]);

        $response = array();
        $response[] = array('id'=>'','label'=>'Select Data');
        foreach ($sparepartCollection as $sparepart) {
            $response[] = array('id'=>$sparepart->getId(),'label'=>$sparepart->getPartName());
        }
        echo json_encode($response);
        exit();
    }
}
