<?php
namespace Escorts\Warrantyplan\Controller\Adminhtml\Warrantyplan;

class ItemDelete extends \Magento\Backend\App\Action
{

    protected $warrantyPlanSparePartsFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Escorts\Warrantyplan\Model\WarrantyplansparepartsFactory $warrantyPlanSparePartsFactory
    ){
        $this->warrantyPlanSparePartsFactory = $warrantyPlanSparePartsFactory;
        parent::__construct($context);
    }

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    public function execute()
    {
		$id = $this->getRequest()->getParam('item_id');
        $warranty_id = $this->getRequest()->getParam('warranty_id');
		try {
			$warrantyItem = $this->warrantyPlanSparePartsFactory->create()->load($id);
			$warrantyItem->delete();
            $this->messageManager->addSuccess(
                __('Delete successfully !')
            );
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
	    $this->_redirect('*/*/edit', ['id' => $warranty_id, '_current' => true]);
    }
}
