<?php

namespace Escorts\Warrantyplan\Controller\Adminhtml\Warrantyplan;

use Magento\Framework\App\Filesystem\DirectoryList;

class Save extends \Magento\Backend\App\Action {

    protected $warrantyPlanSparePartsFactory;

    public function __construct(
    \Magento\Backend\App\Action\Context $context, \Escorts\Warrantyplan\Model\WarrantyplansparepartsFactory $warrantyPlanSparePartsFactory
    ) {
        $this->warrantyPlanSparePartsFactory = $warrantyPlanSparePartsFactory;
        parent::__construct($context);
    }

    public function execute() {
        $data = $this->getRequest()->getParams();
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getParams();

        //echo '<pre>';
        //print_r($data);
        //die;

        if ($data) {
            $model = $this->_objectManager->create('Escorts\Warrantyplan\Model\Warrantyplan');
            $id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
            }

            //$model->setData($data);
            $model->setName($data['name']);
            $model->setDescription($data['description']);
            $model->setNumberOfYears($data['number_of_years']);
            $model->setHours($data['hours']);
            $model->setLessOrMore($data['less_or_more']);
            $model->setPrice($data['price']);
            $model->setSortOrder($data['sort_order']);

            try {
                $model->save();
                $ldId = $model->getId();

                if (count($data['category_id'])) {
                    $warrantyItemsModel = $this->warrantyPlanSparePartsFactory->create();
                    foreach ($data['category_id'] as $key => $categoryId) {
                        $warrantyItems = $warrantyItemsModel->getCollection()
                                ->addFieldToFilter('id', ['eq' => $key])
                                ->addFieldToFilter('warranty_plan_id', ['eq' => $ldId])
                                ->setPageSize(1);

                        if ($warrantyItems->getSize()) {
                            $warrantyItem = $warrantyItemsModel->load($warrantyItems->getFirstItem()->getId());
                            $warrantyItem->setPartId($data['part_id'][$key]);
                            $warrantyItem->setCategoryId($categoryId);
                            $warrantyItem->setWarrantyYears($data['warranty_years'][$key]);
                            $warrantyItem->setWarrantyBy($data['warranty_by'][$key]);
                            $warrantyItem->setWarrantyPlanId($ldId);
                            $warrantyItem->save();
                            $warrantyItem->unsetData();
                        } else {
                            $model2 = $this->warrantyPlanSparePartsFactory->create();
                            $model2->setPartId($data['part_id'][$key]);
                            $model2->setCategoryId($categoryId);
                            $model2->setWarrantyYears($data['warranty_years'][$key]);
                            $model2->setWarrantyBy($data['warranty_by'][$key]);
                            $model2->setWarrantyPlanId($ldId);
                            $model2->save();
                        }
                    }
                }

                $this->messageManager->addSuccess(__('Saved successfully'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    $this->_redirect('*/*/edit', array('id' => $model->getId(), '_current' => true));
                    return;
                }
                $this->_redirect('*/*/');
                return;
            } catch (\Magento\Framework\Model\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            }

            $this->_getSession()->setFormData($data);
            return;
        }
        $this->_redirect('*/*/');
    }

}
