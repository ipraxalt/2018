<?php

namespace Escorts\Warrantyplan\Block\Adminhtml\Warrantyplan\Edit\Tab;

class Warrantyparts extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface {

    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @var \Escorts\SpareParts\Model\SparePartsCategoryFactory
     */
    protected $_sparePartsCategoryFactory;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
    \Magento\Backend\Block\Template\Context $context, \Magento\Framework\Registry $registry, \Magento\Framework\Data\FormFactory $formFactory, \Magento\Store\Model\System\Store $systemStore, \Escorts\SpareParts\Model\SparePartsCategoryFactory $sparePartsCategoryFactory, array $data = array()
    ) {
        $this->_systemStore = $systemStore;
        $this->_sparePartsCategoryFactory = $sparePartsCategoryFactory;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm() {
        /* @var $model \Magento\Cms\Model\Page */
        $model = $this->_coreRegistry->registry('warrantyplan_warrantyplan');
        $isElementDisabled = false;
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('page_');

        $fieldset = $form->addFieldset('base_fieldset', array('legend' => __('Warrantyparts')));

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', array('name' => 'id'));
        }


        $fieldset->addField(
                'category', 'select', [
            'label' => __('Number of Years'),
            'title' => __('Number of Years'),
            //'required' => true,
            'options' => ['1' => __('cat1'), '2' => __('cat2'), '3' => __('cat43')]
                ]
        );

        $fieldset->addField(
                'part_of_desc', 'select', [
            'label' => __('Part of description'),
            'title' => __('Part of description'),
            //'required' => true,
            'options' => ['1' => __('cat1id'), '2' => __('cat2id'), '3' => __('cat3id')]
                ]
        );

        $fieldset->addField(
                'year_of_warranty', 'select', [
            'label' => __('Year of Warranty'),
            'title' => __('Year of Warranty'),
            //'required' => true,
            'options' => ['1' => __(1), '2' => __(2)]
                ]
        );


        $fieldset->addField(
                'warranty_by', 'select', [
            'label' => __('Warranty By'),
            'title' => __('Warranty By'),
            //'required' => true,
            'options' => ['0' => __('Select Field value'), '1' => __('Escorts'), '2' => __('OEM')]
                ]
        );


        /* {{CedAddFormField}} */

        if (!$model->getId()) {
            $model->setData('status', $isElementDisabled ? '2' : '1');
        }

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel() {
        return __('Spare Parts Exception');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle() {
        return __('Spare Parts Exception');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab() {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden() {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId) {
        return $this->_authorization->isAllowed($resourceId);
    }

    public function getSparePartsCategory() {
        $collection = $this->_sparePartsCategoryFactory->create()
                ->getCollection()
                ->addFieldToSelect(['id', 'name', 'parent_id'])
                ->addFieldToFilter('parent_id', ['eq' => 0]);
        $categoryArr = [];
        if ($collection->getSize()) {

            foreach ($collection as $category) {
                $subCategoryArr = [];
                $subCategories = $this->_sparePartsCategoryFactory->create()->getCollection()
                        ->addFieldToFilter('parent_id', ['eq' => $category->getId()]);

                if ($subCategories->getSize()) {
                    foreach ($subCategories as $subCategory) {
                        $subCategoryArr[] = ['id' => $subCategory->getId(), 'name' => $subCategory->getName()];
                    }
                }
                $categoryArr[] = ['id' => $category->getId(), 'name' => $category->getName(), 'sub_category' => $subCategoryArr];
            }
        }
        return $categoryArr;
    }

}
