<?php

namespace Escorts\Warrantyplan\Block\Adminhtml\Warrantyplan\Edit\Tab;

class Information extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface {

    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
    \Magento\Backend\Block\Template\Context $context, \Magento\Framework\Registry $registry, \Magento\Framework\Data\FormFactory $formFactory, \Magento\Store\Model\System\Store $systemStore, array $data = array()
    ) {
        $this->_systemStore = $systemStore;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm() {
        /* @var $model \Magento\Cms\Model\Page */
        $model = $this->_coreRegistry->registry('warrantyplan_warrantyplan');
        $isElementDisabled = false;
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('page_');

        $fieldset = $form->addFieldset('base_fieldset', array('legend' => __('Information')));

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', array('name' => 'id'));
        }

        $fieldset->addField(
                'name', 'text', array(
            'name' => 'name',
            'label' => __('Name'),
            'title' => __('Name'),
                /* 'required' => true, */
                )
        );
        $fieldset->addField(
                'description', 'text', array(
            'name' => 'description',
            'label' => __('Description'),
            'title' => __('Description'),
                /* 'required' => true, */
                )
        );
		
		

		 $fieldset->addField(
            'number_of_years',
            'select',
            [
                'label' => __('Number of Years'),
                'title' => __('Number of Years'),
                'name' => 'number_of_years',
                'required' => true,
                'onchange' => 'statelist(this)',
                'options' => $this->getOptionArray4(),
                'disabled' => $isElementDisabled
            ]
        );
		
		
		$fieldset->addField(
         'hours',
         'select',
		[
			'label' => __('Hours'),
			'title' => __('Hours'),
			'name' => 'hours',
			'required' => true,
			'options' => $this->getOptionArray3(),
            'disabled' => $isElementDisabled
		]
	   );

	    $fieldset->addField(
                'sort_order', 'text', array(
            'name' => 'sort_order',
            'label' => __('Sort Order'),
            'title' => __('Sort Order'),
                /* 'required' => true, */
                )
        );
        /* {{CedAddFormField}} */

        if (!$model->getId()) {
            $model->setData('status', $isElementDisabled ? '2' : '1');
        }

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel() {
        return __('Information');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle() {
        return __('Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab() {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden() {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId) {
        return $this->_authorization->isAllowed($resourceId);
    }
	
	public function getOptionArray4()
    {
        $_id = $this->getRequest()->getParam('id');
		$data_array=array(''=>'Select number of years','1' => __(1), '2' => __(2),'3' => __(3),'4' => __(4),'5' => __(5),'6' => __(6),'7' => __(7),'8' => __(8));
       /* if (!$_id) {
            
            return($data_array);
        }else{
            $_village = $this->_villageFactory->create()->load($_id);
            $states = $this->_stateFactory->create();
            $collection = $states->getCollection();
            $collection->addFieldToFilter('country_id',array('eq' => $_village->getCountry()));
            $data_array = array(''=>'Select State');
            foreach ($collection as $state) {
                $data_array[$state->getId()] = $state->getName();
            }
            return($data_array);
        } */
		return($data_array);
    }
	
	

				
	public function getOptionArray3()
    {
        $_id = $this->getRequest()->getParam('id');
		$data_array=array(''=>'Select hours','50' => __(50), '100' => __(100),'200' => __(200),'300' => __(300),'400' => __(400),'500' => __(500),'600' => __(600),'700' => __(700));
      
		return($data_array);
    }
	
	
    public function getOptionArray2()
    {
        $_id = $this->getRequest()->getParam('id');
		$data_array=array(''=>'Select Value','0' => __('Less than'), '1' => __('Greater than'));
      
		return($data_array);
    }
	
	    public function getOptionArray1()
    {
        $_id = $this->getRequest()->getParam('id');
		$data_array=array(''=>'Select Price','50' => __(50), '100' => __(100),'150' => __(150));
      
		return($data_array);
    }

}
