<?php

namespace Escorts\Warrantyplan\Block\Adminhtml;

class Warrantyplan extends \Magento\Backend\Block\Widget\Grid\Container {

    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct() {

        $this->_controller = 'adminhtml_warrantyplan'; /* block grid.php directory */
        $this->_blockGroup = 'Escorts_Warrantyplan';
        $this->_headerText = __('Warranty Plan');
        $this->_addButtonLabel = __('Add Warranty Plan');
        parent::_construct();
    }

}
