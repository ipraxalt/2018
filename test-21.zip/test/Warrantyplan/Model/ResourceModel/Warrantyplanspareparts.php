<?php
/**
 * Copyright © 2015 Escorts. All rights reserved.
 */
namespace Escorts\Warrantyplan\Model\ResourceModel;

/**
 * Warrantyplanspareparts resource
 */
class Warrantyplanspareparts extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('escorts_warranty_plan_items', 'id');
    }

  
}
