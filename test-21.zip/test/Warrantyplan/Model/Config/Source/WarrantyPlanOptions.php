<?php

namespace Escorts\Warrantyplan\Model\Config\Source;

use Magento\Eav\Model\ResourceModel\Entity\Attribute\OptionFactory;
use Magento\Framework\DB\Ddl\Table;

/**
 * Custom Attribute Renderer
 */
class WarrantyPlanOptions extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource {

    /**
     * @var OptionFactory
     */
    protected $optionFactory;
    /**
     * @param OptionFactory $optionFactory
     */

    /**
     * @var Object
     */
    protected $warrantyPlanFactory;

    public function __construct(
    \Escorts\Warrantyplan\Model\WarrantyplanFactory $warrantyPlanFactory
    ) {
        $this->warrantyPlanFactory = $warrantyPlanFactory;
    }

    /**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions() {
        $collection = $this->warrantyPlanFactory->create()->getCollection();
        
        foreach ($collection as $item) {
            $arr = $item->getData();
            $this->_options[] = ['label' => $arr['name'], 'value' => $arr['id']];
        }
        return $this->_options;
    }

}
