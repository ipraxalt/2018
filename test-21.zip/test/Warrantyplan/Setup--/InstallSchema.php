<?php

/**
 * Copyright © 2015 Escorts. All rights reserved.
 */

namespace Escorts\Warrantyplan\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface {

    /**
     * {@inheritdoc}
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context) {

        $installer = $setup;

        $installer->startSetup();

        /**
         * Create table 'escorts_warranty_plan'
         */
        $table = $installer->getConnection()->newTable(
                        $installer->getTable('escorts_warranty_plan')
                )
                ->addColumn(
                        'id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true], 'escorts_warranty_plan'
                )
                ->addColumn(
                        'name', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, '64k', [], 'name'
                )
                ->addColumn(
                        'description', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, '64k', [], 'description'
                )
                ->addColumn(
                        'sort_order', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, null, [], 'Sort Order'
                )
                ->setComment(
                'Escorts Warranty Plan'
        );

        $installer->getConnection()->createTable($table);


        /**
         * Create table 'escorts_warranty_plan_items'
         */
        $table = $installer->getConnection()->newTable(
                        $installer->getTable('escorts_warranty_plan_items')
                )
                ->addColumn(
                        'id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true], 'escorts_warranty_plan_items'
                )
                ->addColumn(
                        'part_id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, [], 'Part ID'
                )
                ->addColumn(
                        'warranty_years', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, null, [], 'Warranty Years'
                )
                ->addColumn(
                        'warranty_hours', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, null, [], 'Warranty Hours'
                )
                ->addColumn(
                        'from_date_manufacture', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, null, [], 'Warranty Hours'
                )
                ->addColumn(
                        'warranty_plan_id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, [], 'Warranty plan id'
                )
                ->setComment(
                'Escorts Warranty Plan Items'
        );

        $installer->getConnection()->createTable($table);

        $installer->endSetup();
    }

}
