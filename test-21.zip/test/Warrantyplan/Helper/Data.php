<?php

/**
 * Copyright © 2015 Escorts . All rights reserved.
 */

namespace Escorts\Warrantyplan\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper {

    /**
     * @var \Magento\Backend\Model\UrlInterface
     */
    private $backendUrl;
    protected $_customerTractorFactory;
    protected $_productFactory;
    protected $_warrantyPlan;
    protected $_warrantyPlanSpareParts;
    protected $_timezone;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Escorts\ServiceRequest\Model\CustomerTractorFactory $_customerTractorFactory
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     */
    public function __construct(
    \Magento\Framework\App\Helper\Context $context, \Magento\Backend\Model\UrlInterface $backendUrl, \Escorts\ServiceRequest\Model\CustomerTractorFactory $_customerTractorFactory, \Magento\Catalog\Model\ProductFactory $productFactory, \Escorts\Warrantyplan\Model\WarrantyplanFactory $warrantyPlanFactory, \Escorts\Warrantyplan\Model\WarrantyplansparepartsFactory $WarrantyplansparepartsFactory, \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
    ) {
        $this->backendUrl = $backendUrl;
        $this->_customerTractorFactory = $_customerTractorFactory;
        $this->_productFactory = $productFactory;
        $this->_warrantyPlan = $warrantyPlanFactory;
        $this->_warrantyPlanSpareParts = $WarrantyplansparepartsFactory;
        $this->_timezone = $timezone;
        parent::__construct($context);
    }

    public function getWarrantyItemUrl() {
        return $this->backendUrl->getUrl('warrantyplan/warrantyplan/items', ['_current' => true]);
    }

    public function getOptionArray() {
        return [
            [
                'label' => __('------- Please choose Hourse -------'),
                'value' => '',
            ],
            [
                'label' => __('Custom Options'),
                'value' => [
                    ['value' => '1', 'label' => __('50')],
                    ['value' => '2', 'label' => __('100')],
                    ['value' => '3', 'label' => __('200')],
                    ['value' => '4', 'label' => __('300')],
                    ['value' => '5', 'label' => __('400')],
                    ['value' => '5', 'label' => __('500')],
                    ['value' => '5', 'label' => __('600')],
                    ['value' => '5', 'label' => __('700')],
                ],
            ],
        ];
    }

    /**
     * Check part is in warranty or not
     * @param int $tractorId
     * @param int $partId
     * @return boolean
     */
    public function isInWarranty($tractorId, $partId) {

        if (!empty($tractorId) && !empty($partId)) {
            $result = [];
            $warrantyOwner = ['1' => 'Escorts', '2', 'OEM'];
            $tractorCollection = $this->_customerTractorFactory->create()->load($tractorId);
            if (!empty($tractorCollection->getOrderItemId())) {
                try {
                    $productId = $tractorCollection->getOrderItemId();
                    $tractorDeliveryDate = $tractorCollection->getDeliveryDate();
                    $productObj = $this->_productFactory->create()->load($productId);
                    $productWarrantyPlanId = $productObj->getWarrantyPlan();
                    $productPrice = $productObj->getPrice();

                    if (!empty($productWarrantyPlanId)) {
                        $warrantyPlanObj = $this->_warrantyPlan->create()->load($productWarrantyPlanId);
                        $warrantyPrice = $warrantyPlanObj->getPrice();
                        $lessOrMoreValue = $warrantyPlanObj->getLessOrMore();
                        $NumberOfYears = $warrantyPlanObj->getNumberOfYears();

                        if ((($productPrice > $warrantyPrice) && ($lessOrMoreValue == 0)) || (($productPrice < $warrantyPrice) && ($lessOrMoreValue == 1))) {
                            /* Check Part Id exist in warranty plan item */
                            $warrantyPlanSparePartsObj = $this->_warrantyPlanSpareParts->create()->getCollection()
                                    ->addFieldtoFilter('warranty_plan_id', $productWarrantyPlanId)
                                    ->addFieldtoFilter('part_id', $partId);
                            if ($warrantyPlanSparePartsObj->getSize()) {
                                $warrantyItemCollection = $warrantyPlanSparePartsObj->getData();
                                $warrantYears = $warrantyItemCollection[0]['warranty_years'];
                                $warrantyBy = $warrantyItemCollection[0]['warranty_by'];
                                $now = $this->_timezone->date()->format('Y-m-d');
                                $diff = date_diff(date_create($now), date_create($tractorDeliveryDate));
                                $days = $diff->format("%a");
                                if ($days > 0) {
                                    //$result['warrant_years'] = $warrantYears;  
                                    $result['in_warranty'] = 1;
                                    $result['warranty_by'] = $warrantyBy;
                                    if ($warrantyOwner[$warrantyBy]) {
                                        $result['warranty_by'] = $warrantyOwner[$warrantyBy];
                                    }
                                } else {
                                    // $result['warrant_years'] = $NumberOfYears;
                                    $result['in_warranty'] = 1;
                                    $result['warranty_by'] = '';
                                }
                            } else {
                                $result['in_warranty'] = 1;
                                // $result['warrant_years'] = $NumberOfYears;
                                $result['warranty_by'] = '';
                            }
                        } else {
                            return false;
                        }
                    }
                } catch (\Exception $e) {
                    $this->messageManager->addError($e->getMessage());
                }
                return $result;
            }
        }

        return false;
    }

}
