<?php
namespace Oss\Orderapi\Api;

use Oss\Orderapi\Api\Data\PointInterface;

/**
 * Interface OrderInterface
 * @package Oss\Orderapi\Api
 */

interface OrderInterface
{
	 /**
    * get and return val
    * @param string $param
    * @return array
    */
	
public function myorder($customerId);

}