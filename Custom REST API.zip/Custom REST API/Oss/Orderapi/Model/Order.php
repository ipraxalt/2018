<?php
namespace Oss\Orderapi\Model;

class Order implements \Oss\Orderapi\Api\OrderInterface
{
  
	  
	/**
     * customer order details by customer customerId.
     *
     * @api
     * @
     * @return array order array.
     */
	 public function myorder($customerId) {
			if(empty($customerId) || !isset($customerId) || $customerId == ""){
				
			    throw new InputException(__('Id required'));
			}
			else{
				$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
				$orders = $objectManager->create('Magento\Sales\Model\Order')->getCollection()->addFieldToFilter('customer_id',$customerId);
				$orderData = array();
				
				if(count($orders)){
						foreach ($orders as $order){
							$data = array("order_id"=>$order->getEntityId(),"status"=>$order->getStatus(),
							"amount"=>$order->getBaseGrandTotal(),
							"order_date"=>$order->getUpdatedAt()
						);
						$orderData[] = $data;
					   }
			           return $orderData;
			    }
			    else{
			           return $orderData;
			    }
			}
	 }
   
	
}