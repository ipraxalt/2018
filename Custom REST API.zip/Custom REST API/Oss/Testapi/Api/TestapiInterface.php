<?php
namespace Oss\Testapi\Api;
/**
 * Interface TestapiInterface
 * @package Oss\Testapi\Api
 */
interface TestapiInterface
{
    /**
    * getCustomval function
    * @api
    * @return string
    */
    public function getCustomval();
	
	 /**
    * get and return val
    * @param string $param
    * @return string
    */
		
	public function test1($param);
	
	/**
     * Sum an array of numbers.
     *
     * @api
     * @param int[] $nums The array of numbers to sum.
     * @return int The sum of the numbers.
     */
    public function sum($nums);

    
}