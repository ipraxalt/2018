<?php
namespace Oss\Testapi\Model;

class Testapi implements \Oss\Testapi\Api\TestapiInterface
{
   public function __construct(){
	   return true;
   }
   
	 public function getCustomval(){
		 
		 return "Hello getCustomval function, done";
    }
	
	
	  public function test1($param){
       return $param;
      }
	  
	    /**
     * Sum an array of numbers.
     *
     * @api
     * @param int[] $nums The array of numbers to sum.
     * @return int The sum of the numbers.
     */
    public function sum($nums) {
        $total = 0;
        foreach ($nums as $num) {
            $total += $num;
        }
        return $total;
    }
	
}