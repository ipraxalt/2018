<?php

namespace Escorts\JobCard\Controller\Invoice;

class Prints extends \Magento\Framework\App\Action\Action
{
    public function execute()
    { 
	
        $this->_view->loadLayout();
        $this->_view->getLayout()->initMessages();
        $this->_view->renderLayout();
    }
}