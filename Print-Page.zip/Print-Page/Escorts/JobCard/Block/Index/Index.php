<?php

namespace Escorts\JobCard\Block\Index;

use Magento\Framework\View\Element\Template;


class Index extends Template {

   public function __construct(
		Template\Context $context, 
		\Magento\Customer\Model\CustomerFactory $customerFactory, 
           array $data = []
    ) {
    	$this->customerFactory = $customerFactory;
    	//$this->_commonHelper = $_commonHelper;
        parent::__construct($context, $data);
    }
		
	 /**
	 
     * @return void
     */
    protected function _prepareLayout()
    {    
$param	= $this->getRequest()->getparam('key');
        $this->pageConfig->getTitle()->set(__('Order # %1', $param));
        //$infoBlock = $this->paymentHelper->getInfoBlock($this->getOrder()->getPayment(), $this->getLayout());
        //$this->setChild('payment_info', $infoBlock);
    }

	public function getParameters()
    {
    	  $param = $this->getRequest()->getparam('key');
    	return $param;
    }
	 public function getPrint() {
         $productCollection = '12345';
        return $productCollection;
    }
	

}