<?php
/**
 * Copyright © 2015 Escorts. All rights reserved.
 */
namespace Escorts\Recommendation\Model\ResourceModel;

/**
 * Recommendation resource
 */
class Recommendation extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('escorts_recommendation', 'id');
    }  
}
