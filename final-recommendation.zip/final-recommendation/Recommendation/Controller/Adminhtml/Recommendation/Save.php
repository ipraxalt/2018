<?php
namespace Escorts\Recommendation\Controller\Adminhtml\Recommendation;
use Magento\Framework\App\Filesystem\DirectoryList;
class Save extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
	public function execute()
    {		
        $data = $this->getRequest()->getParams();
        if ($data) {
            $model = $this->_objectManager->create('Escorts\Recommendation\Model\Recommendation');	
			      $id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
            }
           
          
            
            $error=0;
            $errorMsg="";

              /*Crop Age*/
             if($data['crop_age_min'] < -10  || $data['crop_age_max']>180 ){
                     $error=1;
                    $errorMsg = $errorMsg.'<p>Crop Age Values is not correct</p>'; 
             }elseif($data['crop_age_min'] > $data['crop_age_max']){
                      $error=1;
                      $errorMsg = $errorMsg.'<p>Crop Age Values is not correct</p>'; 
             }
             elseif($data['crop_age_min'] > 180  || $data['crop_age_max']<-9){
                      $error=1;
                      $errorMsg = $errorMsg.'<p>Crop Age Values is not correct</p>'; 
             }
             elseif($data['crop_age_min'] == $data['crop_age_max']){
                      $error=1;
                      $errorMsg = $errorMsg.'<p>Crop Age Values is not correct</p>'; 
             }
             else{
             }             
            /*Crop Age*/


             /*temperature*/
             if($data['temperature_min'] < -20  || $data['temperature_max']>50 ){
                     $error=1;
                    $errorMsg = $errorMsg.'<p>temperature Values is not correct</p>'; 
             }elseif($data['temperature_min'] > $data['temperature_max']){
                      $error=1;
                      $errorMsg = $errorMsg.'<p>Temperature Values is not correct</p>'; 
             }
             elseif($data['temperature_min'] > 50  || $data['temperature_max']<-19){
                      $error=1;
                      $errorMsg = $errorMsg.'<p>Temperature Values is not correct</p>'; 
             }
             elseif($data['temperature_min'] == $data['temperature_max']){
                      $error=1;
                      $errorMsg = $errorMsg.'<p>Temperature Values is not correct</p>'; 
             }
             else{
                 //$error=0;
                 //$errorMsg="";
             }             
            /*temperature*/

           
             /*humidity*/
             if($data['humidity_min'] < 0  || $data['humidity_max']>100 ){
                     $error=1;
                    $errorMsg = $errorMsg.'<p>Humidity Values is not correct</p>'; 
             }elseif($data['humidity_min'] > $data['humidity_max']){
                      $error=1;
                      $errorMsg = $errorMsg.'<p>humidity Values is not correct</p>'; 
             }
             elseif($data['humidity_min'] > 100  || $data['humidity_max']<1){
                      $error=1;
                      $errorMsg = $errorMsg.'<p>Humidity Values is not correct</p>'; 
             }
             elseif($data['humidity_min'] == $data['humidity_max']){
                      $error=1;
                      $errorMsg = $errorMsg.'<p>Humidity Values is not correct</p>'; 
             }
             else{
                 //$error=0;
                 //$errorMsg="";
             }
             
            /*humadity*/

            /*RainFall*/
             if($data['rainfall_min'] < 0  || $data['rainfall_max']>100 ){
                     $error=1;
                    $errorMsg = $errorMsg.'<p>Rainfall Values is not correct</p>'; 
             }elseif($data['rainfall_min'] > $data['rainfall_max']){
                      $error=1;
                      $errorMsg = $errorMsg.'<p>Rainfall Values is not correct</p>'; 
             }
             elseif($data['rainfall_min'] > 100  || $data['rainfall_max']<1){
                      $error=1;
                      $errorMsg = $errorMsg.'<p>Rainfall Values is not correct</p>'; 
             }
             elseif($data['rainfall_min'] == $data['rainfall_max']){
                      $error=1;
                      $errorMsg = $errorMsg.'<p>Rainfall Values is not correct</p>'; 
             }
             else{
                // $error=0;
                // $errorMsg="";
             }
              /*RainFall*/
             if($error==1){
                $this->messageManager->addError($errorMsg);
                                            $this->_getSession()->setFormData($data);
                                            $this->_redirect('*/*/edit', array('id' => $id));
                                            return;
             }

                           

              



			
			 if (!empty($data['store_ids'])) {
                $data['store_ids'] = implode(',', $data['store_ids']);
            }
            if (!empty($data['sowing_month'])) {
                $data['sowing_month'] = implode(',', $data['sowing_month']);
            }

			
            $model->setData($data);
			
            try {
                $model->save();
               
                $this->messageManager->addSuccess(__('Recommendation Has been Saved.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    $this->_redirect('*/*/edit', array('id' => $model->getId(), '_current' => true));
                    return;
                }
                $this->_redirect('*/*/');
                return;
            } catch (\Magento\Framework\Model\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the Recommendation.'));
            }

            $this->_getSession()->setFormData($data);
            $this->_redirect('*/*/edit', array('banner_id' => $this->getRequest()->getParam('banner_id')));
            return;
        }
        $this->_redirect('*/*/');
    }
}
