<?php
namespace Escorts\Recommendation\Controller\Adminhtml\Recommendation;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Phrase;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;

class ImportSave extends \Magento\Backend\App\Action {
    protected $_recommendationFactory;
    protected $_stateFactory;
   

    public function __construct(\Magento\Backend\App\Action\Context $context) {
       
        parent::__construct($context);
        
     
    }

   /**
   * @var \Magento\Framework\View\Result\PageFactory
   */
    public function execute() {
        $data = $this->getRequest()->getParams();	
        $stateArray=[];
		
        if ($data) {
            $_recommendationFactory = $this->_objectManager->create('Escorts\Recommendation\Model\Recommendation');
            
           
             if(empty($_FILES['csv_attachment']['name'])) {
                    $errorMsg = "Uploaded File CSV.";
                    $this->messageManager->addError($errorMsg);
                    $this->_redirect('*/*/import', array());
                    return;
            }
          
            
               
           
           // $currentTimestamp = $this->_helperObject->getCurrentDate();
           
            if (isset($_FILES['csv_attachment']['name']) && $_FILES['csv_attachment']['name'] != '') {

                /* File Type Validation */
                $uploadedfileName = $_FILES['csv_attachment']['name'];
                $ext = pathinfo($uploadedfileName, PATHINFO_EXTENSION);
                $allowed = array('csv');
                if (!in_array($ext, $allowed)) {
                    $errorMsg = "Uploaded File Type Not Allowed.File Type Must be CSV.";
                    $this->messageManager->addError($errorMsg);
                    $this->_redirect('*/*/import', array());
                    return;
                }

                if (($handle = fopen($_FILES['csv_attachment']['tmp_name'], "r")) !== FALSE) {
                    $row = 1;
                    $csv_array = [];
                    $csv_column_array = [];
                    while (($csvReadValue = fgetcsv($handle, 1000, ",")) !== FALSE) {
                        if ($row > 1) {
                            $csv_array[] = $csvReadValue;
                            if (empty($csvReadValue[0]) || empty($csvReadValue[1]) || empty($csvReadValue[2]) || empty($csvReadValue[3]) || empty($csvReadValue[4]) || empty($csvReadValue[5]) || empty($csvReadValue[6]) || !isset($csvReadValue[7]) || !isset($csvReadValue[8]) || !isset($csvReadValue[9]) || !isset($csvReadValue[10]) || !isset($csvReadValue[11]) || !isset($csvReadValue[12]) || !isset($csvReadValue[13])) {
                                $errorMsg = 'CSV format is not correct';
                                $this->messageManager->addError($errorMsg);
                                $this->_getSession()->setFormData($data);
                                $this->_redirect('*/*/import', array());
                                return;
                            }
                        } else {
                            $num = count($csvReadValue);
                            $csv_column_array = $csvReadValue;
                        }
                        $row++;
                    }
                    /* CSv Column Validate */
                    if ($csv_column_array[0] != "crop_name" || $csv_column_array[1] != "region"  || $csv_column_array[2] != "crop_age_min" || $csv_column_array[3]!= "crop_age_max"  || $csv_column_array[4] != "temperature_min" || $csv_column_array[5] != "temperature_max" || $csv_column_array[6]!= "humidity_min"  || $csv_column_array[7] != "humidity_max" || $csv_column_array[8] != "pest"  || $csv_column_array[9] != "rainfall_min" || $csv_column_array[10] != "rainfall_max"  || $csv_column_array[11] != "sowing_month" || $csv_column_array[12] != "recommendation"  || $csv_column_array[13]!= "store_ids") {
                        $errorMsg = 'CSV format is not correct. ';
                        $this->messageManager->addError($errorMsg);
                        $this->_getSession()->setFormData($data);
                        $this->_redirect('*/*/import', array());
                        return;
                    } /* CSv Column Format Validate */
                    fclose($handle);
                }
            }
           
            /* Get value */
            if (!empty($csv_array)) {
               try {                     
                 $csvArrayStatus = [];
                 $count=0;
                 $errorMsg='';
                 foreach ($csv_array as $csvData) {   
                            $error=0;
                            $count++;
                            
                            $RecommArray = [];
                            $RecommArray['crop_name'] = $csvData[0];
                            $RecommArray['region']   =     $csvData[1];
                            $RecommArray['crop_age_min'] =  $csvData[2];
                            $RecommArray['crop_age_max'] =  $csvData[3];
                            $RecommArray['temperature_min'] =  $csvData[4];
                            $RecommArray['temperature_max'] =  $csvData[5];
                            $RecommArray['humidity_min'] =  $csvData[6];
                            $RecommArray['humidity_max'] =  $csvData[7];
                            $RecommArray['pest'] =          $csvData[8];
                            $RecommArray['rainfall_min'] =  $csvData[9];
                            $RecommArray['rainfall_max'] =  $csvData[10];
                            $RecommArray['sowing_month'] =  $csvData[11];
                            $RecommArray['recommendation'] =  $csvData[12];
                            $RecommArray['store_ids'] =  $csvData[13];
                            
                            /*Region*/
                            if($RecommArray['region'] <1 || $RecommArray['region']>36){
                                $error=1; 
                            }
                            elseif ( strval($RecommArray['region']) !== strval(intval($RecommArray['region'])) ) {
                                $error=1; 
                            }
                            else{
                            } 
                            /*Region*/

                            /*Sowing Month*/
                            $months=[1,2,3,4,5,6,7,8,9,10,11,12]; 
                            $sowingMonthArray = explode(",", $RecommArray['sowing_month']);
                            if(!empty($sowingMonthArray)){
                                foreach($sowingMonthArray as $sowingMonth){
                                    if (in_array($sowingMonth, $months)){
                                    }else{
                                        $error=1;  
                                    }
                                }
                            }
                            /*Sowing Month*/

                            /*stores Ids*/
                            $storeArray=[1,4,7];
                            if (in_array($RecommArray['store_ids'], $storeArray)){
                               // $error=1; 
                            }elseif ( strval($RecommArray['store_ids']) !== strval(intval($RecommArray['store_ids'])) ) {
                                $error=1; 
                            }
                            else{
                                $error=1; 
                            } 
                             /*stores Ids*/

                             /*Crop Age*/
                            if($RecommArray['crop_age_min'] < -10  || $RecommArray['crop_age_max']>180 ){
                                 $error=1;                               
                            }elseif($RecommArray['crop_age_min'] > $RecommArray['crop_age_max']){
                                  $error=1;                                  
                            }
                            elseif($RecommArray['crop_age_min'] > 180  || $RecommArray['crop_age_max']<-9){
                                  $error=1;                                
                            }
                            elseif($RecommArray['crop_age_min'] == $RecommArray['crop_age_max']){
                                  $error=1;                                 
                            }
                            else{
                            }             
                            /*Crop Age*/


                        /*temperature*/
                        if($RecommArray['temperature_min'] < -20  || $RecommArray['temperature_max']>50 ){
                             $error=1;                           
                        }elseif($RecommArray['temperature_min'] > $RecommArray['temperature_max']){
                              $error=1;                             
                        }
                        elseif($RecommArray['temperature_min'] > 50  || $RecommArray['temperature_max']<-19){
                              $error=1;                            
                        }
                        elseif($RecommArray['temperature_min'] == $RecommArray['temperature_max']){
                              $error=1;                             
                        } else{
                        
                        }             
                        /*temperature*/


                        /*humidity*/
                        if($RecommArray['humidity_min'] < 0  || $RecommArray['humidity_max']>100 ){
                             $error=1;                           
                        }elseif($RecommArray['humidity_min'] > $RecommArray['humidity_max']){
                              $error=1;
                        }elseif($RecommArray['humidity_min'] > 100  || $RecommArray['humidity_max']<1){
                              $error=1;                              
                        }elseif($RecommArray['humidity_min'] == $RecommArray['humidity_max']){
                              $error=1;                             
                        }else{
                        }/*humadity*/


                        /*RainFall*/
                        if($RecommArray['rainfall_min'] < 0  || $RecommArray['rainfall_max']>100 ){
                             $error=1;                           
                        }elseif($RecommArray['rainfall_min'] > $RecommArray['rainfall_max']){
                              $error=1;                             
                        }elseif($RecommArray['rainfall_min'] > 100  || $RecommArray['rainfall_max']<1){
                              $error=1;
                        }elseif($RecommArray['rainfall_min'] == $RecommArray['rainfall_max']){
                              $error=1;                            
                        }else{                       
                        }



                        
                        if(empty($error)){
                            //$recommendationModel = $this->_recommendationFactory->create();
                            $_recommendationFactory->setData($RecommArray);
                             $_recommendationFactory->save();
                       }else{
                         $errorMsg = $errorMsg.$count.',';
                       }

                   }//loop end                   
               }catch (\Exception $e) {
                        $this->messageManager->addException($e, __('Something went  while importing CSV.'));
                        //$this->_getSession()->setFormData($error);
                        $this->_redirect('*/*/edit', array('id' => $poId));
                        return;
               }
            }
            
            $successDataSet="";
            if(!empty($errorMsg)){
                $successDataSet= " Rows ".$errorMsg." Not Imported";
            }
            
            try {
                $this->messageManager->addSuccess(__('CSV Data Uploaded Successfully.'.$successDataSet));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData($successDataSet);
               // if ($this->getRequest()->getParam('back')) {
                      $this->_redirect('*/*/import', array());
                        return;
               //}
               $this->_redirect('*/*/');
               return;
           
            } catch (\Magento\Framework\Model\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the csv.'));
            }
            $this->_getSession()->setFormData($data);
            $this->_redirect('*/*/import', array());
            return;
        }
        $this->_redirect('*/*/');
    }

}
