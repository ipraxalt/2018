<?php
namespace Escorts\Recommendation\Block\Adminhtml\Recommendation\Edit\Tab;
class Recommendation extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

     /**
     * @var \Escorts\Blocks\Model\StateFactory
     */
    protected $_stateFactory;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Escorts\Blocks\Model\StateFactory $stateFactory,
        array $data = array()
    ) {
         $this->_stateFactory = $stateFactory;
        $this->_systemStore = $systemStore;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
		/* @var $model \Magento\Cms\Model\Page */
        $model = $this->_coreRegistry->registry('recommendation_recommendation');
		$isElementDisabled = false;
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
        $form->setHtmlIdPrefix('page_');
        $fieldset = $form->addFieldset('base_fieldset', array('legend' => __('Recommendation')));
        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', array('name' => 'id'));
        }

		$fieldset->addField(
            'crop_name',
            'text',
            array(
                'name' => 'crop_name',
                'label' => __('Crop Name'),
                'title' => __('Crop Name'),
                'required' => true,
            )
        );
         
        $fieldset->addField(
            'region',
            'select',
            array(
                'name' => 'region',
                'label' => __('Region/State'),
                'title' => __('Region/State'),
                'values'     => $this->getRegionList(),
                 'required' => true,
            )
        );

        $fieldset = $form->addFieldset('crop_age_range', array('legend' => __('Crop Age')));

        $fieldset->addField(
            'crop_age_min',
            'text',
            array(
                'name' => 'crop_age_min',
                'label' => __('Crop Age (Min)'),
                'title' => __('Crop Age'),
                 'required' => true,
                 'note'      => __('Range -10  To 180 in Days'),
            )
        );
        $fieldset->addField(
            'crop_age_max',
            'text',
            array(
                'name' => 'crop_age_max',
                'label' => __('Crop Age (Max)'),
                'title' => __('crop_age_max'),
                 'required' => true,
                 'note'      => __('Range -9  To 180 in Days'),
            )
        );

        $fieldset = $form->addFieldset('temperature_range', array('legend' => __('Temperature')));
        $fieldset->addField(
            'temperature_min',
            'text',
            array(
                'name' => 'temperature_min',
                'label' => __('Temperature (Min)'),
                'title' => __('Temperature'),
                 'required' => true,
                  'class' => 'validate-number',
                 'note'      => __('Temperature between -20 To 50 in °C'),
            )
        );
         $fieldset->addField(
            'temperature_max',
            'text',
            array(
                'name' => 'temperature_max',
                'label' => __('Temperature (Max)'),
                'title' => __('Temperature'),
                 'required' => true,
                  'class' => 'validate-number',
                 'note'      => __('Temperature between -19 To50 in °C'),
            )
        );




        $fieldset = $form->addFieldset('humidity_range', array('legend' => __('Humidity')));
        $fieldset->addField(
            'humidity_min',
            'text',
            array(
                'name' => 'humidity_min',
                'label' => __('Humidity (Min)'),
                'title' => __('Humidity'),
                'required' => true,
                 'class' => 'validate-number',
                'note'      => __('Humidity between 0 To 100 in (%)'),
            )
        );
         $fieldset->addField(
            'humidity_max',
            'text',
            array(
                'name' => 'humidity_max',
                'label' => __('Humidity (Max)'),
                'title' => __('Humidity'),
                'required' => true,
                 'class' => 'validate-number',
                'note'      => __('Humidity between 1 To 100 in (%)'),
            )
        );






        $fieldset = $form->addFieldset('rainfall_range', array('legend' => __('Rainfall')));
         $fieldset->addField(
            'rainfall_min',
            'text',
            array(
                'name' => 'rainfall_min',
                'label' => __('Rainfall (min)'),
                'title' => __('Rainfall'),
                 'class' => 'validate-number',
                 'note'      => __('Rainfall between 0 To 100 in mm'),
                'required' => true,
            )
        );

          $fieldset->addField(
            'rainfall_max',
            'text',
            array(
                'name' => 'rainfall_max',
                'label' => __('Rainfall (max)'),
                'title' => __('Rainfall'),
                 'class' => 'validate-number',
                 'note'      => __('Rainfall between 1 To 100 in mm'),
                'required' => true,
            )
        );


        

         $fieldset = $form->addFieldset('pest_range', array('legend' => __('')));

        $fieldset->addField(
            'pest',
            'text',
            array(
                'name' => 'pest',
                'label' => __('Pest'),
                'title' => __('Pest'),
                 'required' => true,
            )
        );
       
        $fieldset->addField(
            'sowing_month',
            'multiselect',
            array(
                'name' => 'sowing_month',
                'label' => __('Sowing Month'),
                'title' => __('Sowing Month'),
                'values'     => $this->getMonthsList(),
                'required' => true,
            )
        );
        $fieldset->addField(
            'recommendation',
            'textarea',
            array(
                'name' => 'recommendation',
                'label' => __('Recommendation'),
                'title' => __('Recommendation'),
                 'required' => true,
            )
        );
      

         if (!$this->_storeManager->isSingleStoreMode()) {
            /** @var \Magento\Framework\Data\Form\Element\Renderer\RendererInterface $rendererBlock */
            $rendererBlock = $this->getLayout()->createBlock('Magento\Backend\Block\Store\Switcher\Form\Renderer\Fieldset\Element');
            $fieldset->addField('store_ids', 'multiselect', [
                'name' => 'store_ids',
                'label' => __('Recommendation in Websites'),
                'title' => __('Recommendation in Websites'),
                'values' => $this->_systemStore->getStoreValuesForForm(false, true)
            ])->setRenderer($rendererBlock);

            if (!$model->hasData('store_ids')) {
                $model->setStoreIds(0);
            }
        } else {
            $fieldset->addField('store_ids', 'hidden', [
                'name' => 'store_ids',
                'value' => $this->_storeManager->getStore()->getId()
            ]);
        }
        
		/*{{CedAddFormField}}*/
        
        if (!$model->getId()) {
            $model->setData('status', $isElementDisabled ? '2' : '1');
        }

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();   
    }

    /**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('Recommendation');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return __('Recommendation');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }

     public function getMonthsList()
    {

        $segmentArray = [1 => 'January',2 => 'February',3 => 'March',4 => 'April',5 => 'May',6 => 'June',7 => 'July',8 => 'August',9 => 'September',10 => 'October',11 => 'November',12 => 'December',];

        $segmentOption = array();
        foreach ($segmentArray as $key => $_option) {
            $segmentOption[] = ['value' => $key, 'label' => $_option];
        }

        return $segmentOption;
    }

    
     public function getRegionList(){
        $segmentArray=[];
        $tempCollection = $this->_stateFactory->create()
                               ->getCollection()
                               ->addFieldToSelect(['id'])
                               ->addFieldToSelect(['name'])
                               ->setOrder('name', 'ASC'); 
        if ($tempCollection->getSize()) {
                foreach ($tempCollection as $item) {
                    $regionId=$item->getId();
                    $segmentArray[$regionId] = $item->getName();
        }
        } 
        $segmentOption = array();
        foreach ($segmentArray as $key => $_option) {
            $segmentOption[] = ['value' => $key, 'label' => $_option];
        }
        return $segmentOption;      
    }

}