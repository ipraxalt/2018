<?php
 
namespace Escorts\Recommendation\Block\Adminhtml\Recommendation\Renderer;
 
use Magento\Framework\DataObject;
 
class HumidityData extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer
{
  
     /**
     * get Crop Age
     * @param  DataObject $row
     * @return string
     */
    public function render(DataObject $row)
    {

         $humidity_min = $row->getHumidityMin();
         $humidity_max = $row['humidity_max'];;
         $html= $humidity_min;
         if(!empty($humidity_max)){
             $html.= '% To '.$humidity_max.'%';      
         }        
        return $html;
    }
}