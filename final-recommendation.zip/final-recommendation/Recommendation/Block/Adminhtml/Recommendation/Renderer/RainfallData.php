<?php
 
namespace Escorts\Recommendation\Block\Adminhtml\Recommendation\Renderer;
 
use Magento\Framework\DataObject;
 
class RainfallData extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer
{
  
     /**
     * get Crop Age
     * @param  DataObject $row
     * @return string
     */
    public function render(DataObject $row)
    {

         $rainfall_min = $row->getRainfallMin();
         $rainfall_max = $row['rainfall_max'];;
         $html= $rainfall_min;
         if(!empty($rainfall_max)){
             $html.= 'mm To '.$rainfall_max.'mm';      
         }        
        return $html;
    }
}