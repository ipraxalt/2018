<?php
 
namespace Escorts\Recommendation\Block\Adminhtml\Recommendation\Renderer;
 
use Magento\Framework\DataObject;
 
class MonthsSegment extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer
{
     
    /**
     * get Month Name
     * @param  DataObject $row
     * @return string
     */
    public function render(DataObject $row)
    {
        $sowingMonthIds = $row->getSowingMonth();		
        $segmentArray = [1 => 'January',2 => 'February',3 => 'March',4 => 'April',5 => 'May',6 => 'June',7 => 'July',8 => 'August',9 => 'September',10 => 'October',11 => 'November',12 => 'December'];
        
		$html='';
        $html.='<ul>';
        foreach (explode(',', $sowingMonthIds) as $segmentId) {
            $html.='<li>'.$segmentArray[$segmentId].'</li>';
        }
        $html.='</ul>';       
        return $html;
    }
}