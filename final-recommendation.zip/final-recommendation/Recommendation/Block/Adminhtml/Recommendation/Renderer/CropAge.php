<?php
 
namespace Escorts\Recommendation\Block\Adminhtml\Recommendation\Renderer;
 
use Magento\Framework\DataObject;
 
class CropAge extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer
{
  
     /**
     * get Crop Age
     * @param  DataObject $row
     * @return string
     */
    public function render(DataObject $row)
    {

         $crop_age_min = $row->getCropAgeMin();
         $crop_age_max = $row['crop_age_max'];;
         $html= $crop_age_min;
         if(!empty($crop_age_max)){
             $html.= ' To '.$crop_age_max.' Days';      
         }        
        return $html;
    }
}