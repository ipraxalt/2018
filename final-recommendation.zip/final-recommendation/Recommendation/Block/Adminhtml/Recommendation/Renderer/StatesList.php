<?php
 
namespace Escorts\Recommendation\Block\Adminhtml\Recommendation\Renderer;
 
use Magento\Framework\DataObject;
 
class StatesList extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer
{
   /**
     * @var \Escorts\Blocks\Model\StateFactory
     */
    protected $_stateFactory;

    /**
     * @param \Magento\Catalog\Model\CategoryFactory $categoryFactory
     */
    public function __construct(
        \Escorts\Blocks\Model\StateFactory $stateFactory
    ) {
        $this->_stateFactory = $stateFactory;
    }
 
    /**
     * get category name
     * @param  DataObject $row
     * @return string
     */
    public function render(DataObject $row)
    {
        $rowRegionId = $row->getRegion();
		  $tempCollection = $this->_stateFactory->create()
                               ->getCollection()
                               ->addFieldToSelect(['id'])
                               ->addFieldToSelect(['name']);
        if ($tempCollection->getSize()) {
                foreach ($tempCollection as $item) {
                    $regionId=$item->getId();
                    $segmentArray[$regionId] = $item->getName();
                }
        } 
        
		$html=$segmentArray[$rowRegionId];
        return $html;
    }
}