<?php
 
namespace Escorts\Recommendation\Block\Adminhtml\Recommendation\Renderer;
 
use Magento\Framework\DataObject;
 
class TemperatureData extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer
{
  
     /**
     * get Crop Age
     * @param  DataObject $row
     * @return string
     */
    public function render(DataObject $row)
    {

         $temperature_min = $row->getTemperatureMin();
         $temperature_max = $row['temperature_max'];;
         $html= $temperature_min;
         if(!empty($temperature_max)){
             $html.= '°C To '.$temperature_max.'°C';      
         }        
        return $html;
    }
}