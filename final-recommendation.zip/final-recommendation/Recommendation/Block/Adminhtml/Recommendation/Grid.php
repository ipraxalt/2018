<?php
namespace Escorts\Recommendation\Block\Adminhtml\Recommendation;


class Grid extends \Magento\Backend\Block\Widget\Grid\Extended
{
    /**
     * @var \Magento\Framework\Module\Manager
     */
    protected $moduleManager;

    /**
     * @var \Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory]
     */
    protected $_setsFactory;

    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $_productFactory;

    /**
     * @var \Magento\Catalog\Model\Product\Type
     */
    protected $_type;

    /**
     * @var \Magento\Catalog\Model\Product\Attribute\Source\Status
     */
    protected $_status;
	protected $_collectionFactory;

    /**
     * @var \Magento\Catalog\Model\Product\Visibility
     */
    protected $_visibility;

    /**
     * @var \Magento\Store\Model\WebsiteFactory
     */
    protected $_websiteFactory;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Backend\Helper\Data $backendHelper
     * @param \Magento\Store\Model\WebsiteFactory $websiteFactory
     * @param \Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory $setsFactory
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     * @param \Magento\Catalog\Model\Product\Type $type
     * @param \Magento\Catalog\Model\Product\Attribute\Source\Status $status
     * @param \Magento\Catalog\Model\Product\Visibility $visibility
     * @param \Magento\Framework\Module\Manager $moduleManager
     * @param array $data
     *
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Magento\Store\Model\WebsiteFactory $websiteFactory,
		\Escorts\Recommendation\Model\ResourceModel\Recommendation\Collection $collectionFactory,
        \Magento\Framework\Module\Manager $moduleManager,
        array $data = []
    ) {
		
		$this->_collectionFactory = $collectionFactory;
        $this->_websiteFactory = $websiteFactory;
        $this->moduleManager = $moduleManager;
        parent::__construct($context, $backendHelper, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
		
        $this->setId('productGrid');
        $this->setDefaultSort('id');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(false);
       
    }

    /**
     * @return Store
     */
    protected function _getStore()
    {
        $storeId = (int)$this->getRequest()->getParam('store', 0);
        return $this->_storeManager->getStore($storeId);
    }

    /**
     * @return $this
     */
    protected function _prepareCollection()
    {
		try{
			
			
			$collection =$this->_collectionFactory->load();

		  

			$this->setCollection($collection);

			parent::_prepareCollection();
		  
			return $this;
		}
		catch(Exception $e)
		{
			echo $e->getMessage();die;
		}
    }

    /**
     * @param \Magento\Backend\Block\Widget\Grid\Column $column
     * @return $this
     */
    protected function _addColumnFilterToCollection($column)
    {
        if ($this->getCollection()) {
            if ($column->getId() == 'websites') {
                $this->getCollection()->joinField(
                    'websites',
                    'catalog_product_website',
                    'website_id',
                    'product_id=entity_id',
                    null,
                    'left'
                );
            }
        }
        return parent::_addColumnFilterToCollection($column);
    }

    /**
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareColumns()
    {
        $this->addColumn(
            'id',
            [
                'header' => __('ID'),
                'type' => 'number',
                'index' => 'id',
                'header_css_class' => 'col-id',
                'column_css_class' => 'col-id'
            ]
        );

         $this->addColumn(
            'crop_name',
            [
                'header' => __('Crop Name'),
                'type' => 'text',
                'index' => 'crop_name',               
            ]
        );

          $this->addColumn(
            'region',
            [
                'header' => __('Region/State'),
                'type' => 'text',
                'index' => 'region',   
                'renderer' => '\Escorts\Recommendation\Block\Adminhtml\Recommendation\Renderer\StatesList'            
            ]
        );

           $this->addColumn(
            'crop_age_min',
            [
                'header' => __('Crop Age'),
                'type' => 'text',
                'index' => 'crop_age_min', 
                'renderer' =>'\Escorts\Recommendation\Block\Adminhtml\Recommendation\Renderer\CropAge',
            ]
        );

        

        $this->addColumn(
            'temperature_min',
            [
                'header' => __('Temperature'),
                'type' => 'text',
                'renderer' =>'\Escorts\Recommendation\Block\Adminhtml\Recommendation\Renderer\TemperatureData',               
            ]
        );

         $this->addColumn(
            'humidity_min',
            [
                'header' => __('Humidity'),
                'type' => 'text',
                'renderer' =>'\Escorts\Recommendation\Block\Adminhtml\Recommendation\Renderer\HumidityData',  
                             
            ]
        );

        $this->addColumn(
            'pest',
            [
                'header' => __('Pest'),
                'type' => 'text',
                'index' => 'pest',               
            ]
        );

        $this->addColumn(
            'rainfall_min',
            [
                'header' => __('Rainfall'),
                'type' => 'text',
                'index' => 'rainfall_min',  
                'renderer' =>'\Escorts\Recommendation\Block\Adminhtml\Recommendation\Renderer\RainfallData',               
            ]
        );
        

        $this->addColumn(
            'sowing_month',
            [
                'header' => __('Sowing Month'),
                'index' => 'sowing_month',
                'class' => 'sowing_month',
                'renderer' => '\Escorts\Recommendation\Block\Adminhtml\Recommendation\Renderer\MonthsSegment'
            ]
        );

      
        $this->addColumn(
            'recommendation',
            [
                'header' => __('Recommendation'),
                'type' => 'text',
                'index' => 'recommendation',               
            ]
        );

       if (!$this->_storeManager->isSingleStoreMode()) {
            $this->addColumn('store_ids', array(
            'header'        => __('Store View'),
            'index'         => 'store_ids',
            'type'          => 'store_ids',
            'store_all'     => true,
            'store_view'    => true,
            'sortable'      => true,
            'renderer' => '\Escorts\Recommendation\Block\Adminhtml\Recommendation\Renderer\Store',
            'filter_condition_callback' => [$this, '_filterStoreCondition']
         ));
       } 

		/*{{CedAddGridColumn}}*/

        $block = $this->getLayout()->getBlock('grid.bottom.links');
        if ($block) {
            $this->setChild('grid.bottom.links', $block);
        }

        return parent::_prepareColumns();
    }

     /**
     * @return $this
     */
    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('id');
        $this->getMassactionBlock()->setFormFieldName('id');

        $this->getMassactionBlock()->addItem(
            'delete',
            array(
                'label' => __('Delete'),
                'url' => $this->getUrl('recommendation/*/massDelete'),
                'confirm' => __('Are you sure?')
            )
        );
        return $this;
    }

    /**
     * @return string
     */
    public function getGridUrl()
    {
        return $this->getUrl('recommendation/*/index', ['_current' => true]);
    }

    /**
     * @param \Magento\Catalog\Model\Product|\Magento\Framework\Object $row
     * @return string
     */
    public function getRowUrl($row)
    {
        return $this->getUrl(
            'recommendation/*/edit',
            ['store' => $this->getRequest()->getParam('store'), 'id' => $row->getId()]
        );
    }
}
