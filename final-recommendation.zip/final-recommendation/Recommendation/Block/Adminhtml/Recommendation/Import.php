<?php

namespace Escorts\Recommendation\Block\Adminhtml\Recommendation;

class Import extends \Magento\Backend\Block\Widget\Container
{

    /**
     * @return $this
     */
    protected function _prepareLayout()
    {

        $onClick = "setLocation('" . $this->getUrl('recommendation/recommendation/index') . "')";
        $this->getToolbar()->addChild(
            'options_button',
            \Magento\Backend\Block\Widget\Button::class,
            ['label' => __('Recommendation List'), 'onclick' => $onClick]
        );
        return parent::_prepareLayout();    
    }


    public function __construct(\Magento\Backend\Block\Widget\Context $context,array $data = [])
    {
        parent::__construct($context, $data);
    }


  public function getMediaUrl(){
	$_objectManager = \Magento\Framework\App\ObjectManager::getInstance(); //instance of\Magento\Framework\App\ObjectManager
	$storeManager = $_objectManager->get('Magento\Store\Model\StoreManagerInterface'); 
	$currentStore = $storeManager->getStore();
	$mediaUrl = $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);  	
  	return $mediaUrl;
  }
    


}
