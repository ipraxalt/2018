<?php
namespace Escorts\Recommendation\Block\Adminhtml;
class Recommendation extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
		
        $this->_controller = 'adminhtml_recommendation';/*block grid.php directory*/
        $this->_blockGroup = 'Escorts_Recommendation';
        $this->_headerText = __('Recommendation');
        $this->_addButtonLabel = __('Add New'); 
        parent::_construct();
		
    }

    /**
     * @return $this
     */
    protected function _prepareLayout()
    {

        $onClick = "setLocation('" . $this->getUrl('recommendation/recommendation/import') . "')";

        $this->getToolbar()->addChild(
            'options_button',
            \Magento\Backend\Block\Widget\Button::class,
            ['label' => __('Import'), 'onclick' => $onClick]
        );

        return parent::_prepareLayout();
    }
    
}
