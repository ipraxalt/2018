<?php
namespace Escorts\SpecialOffer\Block\Adminhtml;
class SpecialOffer extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
		
        $this->_controller = 'adminhtml_specialOffer';/*block grid.php directory*/
        $this->_blockGroup = 'Escorts_SpecialOffer';
        $this->_headerText = __('SpecialOffer');
        $this->_addButtonLabel = __('Add New Entry'); 
        parent::_construct();
		
    }
	
	 /**
     * @return $this
     */
    protected function _prepareLayout()
    {

        $onClick = "setLocation('" . $this->getUrl('specialoffer/specialoffer/import') . "')";

        $this->getToolbar()->addChild(
            'options_button',
            \Magento\Backend\Block\Widget\Button::class,
            ['label' => __('Import'), 'onclick' => $onClick]
        );

        return parent::_prepareLayout();
    }
}
