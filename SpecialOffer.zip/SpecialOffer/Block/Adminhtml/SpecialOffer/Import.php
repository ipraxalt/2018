<?php

namespace Escorts\SpecialOffer\Block\Adminhtml\SpecialOffer;

class Import extends \Magento\Backend\Block\Widget\Container
{



    public function __construct(\Magento\Backend\Block\Widget\Context $context,array $data = [])
    {
        parent::__construct($context, $data);
    }



}
