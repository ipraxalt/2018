<?php

namespace Escorts\SpecialOffer\Controller\Adminhtml\SpecialOffer;


class Import extends \Magento\Backend\App\Action
{
    public function execute()
    {

        $this->_view->loadLayout();
        $this->_view->getLayout()->initMessages();
        $this->_view->renderLayout();
	}
}

?>