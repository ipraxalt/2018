<?php
/**
 * Copyright © 2015 Escorts. All rights reserved.
 */
namespace Escorts\SpecialOffer\Model\ResourceModel;

/**
 * SpecialOffer resource
 */
class SpecialOffer extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('escorts_specialoffer', 'id');
    }

  
}
