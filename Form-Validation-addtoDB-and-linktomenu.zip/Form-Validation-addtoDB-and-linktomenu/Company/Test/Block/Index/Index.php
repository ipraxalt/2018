<?php

namespace Company\Test\Block\Index;
use Company\Test\Model\Test;


class Index extends \Magento\Framework\View\Element\Template {

    public function __construct(\Magento\Catalog\Block\Product\Context $context,Test $model,  array $data = []) {
		$this->model = $model;

        parent::__construct($context, $data);

    }


    protected function _prepareLayout()
    {
        return parent::_prepareLayout();
    }
	
	 public function getFormAction(){
        return $this->getUrl('test/index/post', ['_secure' => true]);
    }

	
	 public function getNewsCollection(){
            $helloCollection = $this->model->getCollection();
            return $helloCollection;
     }
	 
}