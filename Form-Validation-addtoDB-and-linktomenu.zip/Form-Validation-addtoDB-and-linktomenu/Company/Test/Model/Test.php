<?php
namespace Company\Test\Model;
use Magento\Framework\Model\AbstractModel;
class Test extends AbstractModel{
    /**
     * Define resource model
     */
    protected function _construct()  {
        $this->_init('Company\Test\Model\Resource\Test');
    }
}
