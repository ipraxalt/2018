<?php

namespace Escorts\ServiceRequest\Helper;

use Magento\Store\Model\ScopeInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper {

    const XML_PATH_ESCORTS = 'servicerequest/';

    protected $_timezone;
    protected $_serviceFactory;
    protected $_blockHelper;
    protected $_commonHelper;
    protected $_smsNotificationHelper;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
     * @param \Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory
     * @param \Escorts\Blocks\Helper\Data $blockHelper
     * @param \Escorts\Common\Helper\Data $commonHelper
     * @param \Escorts\SmsNotification\Helper\Data $smsNotificationHelper
     */
    public function __construct(
    \Magento\Framework\App\Helper\Context $context, \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone, \Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory, \Escorts\Blocks\Helper\Data $blockHelper, \Escorts\Common\Helper\Data $commonHelper, \Escorts\SmsNotification\Helper\Data $smsNotificationHelper
    ) {
        $this->_timezone = $timezone;
        $this->_serviceFactory = $serviceFactory;
        $this->_blockHelper = $blockHelper;
        $this->_commonHelper = $commonHelper;
        $this->_smsNotificationHelper = $smsNotificationHelper;
        parent::__construct($context);
    }

    /**
     * @param string $field
     * @param int $storeId
     * @return mixed
     */
    public function getConfigValue($field, $storeId = null) {
        return $this->scopeConfig->getValue($field, ScopeInterface::SCOPE_STORE, $storeId);
    }

    public function getGeneralConfig($code, $storeId = null) {
        return $this->getConfigValue(self::XML_PATH_ESCORTS . 'general/' . $code, $storeId);
    }

    public function serviceRequestEscalationAuto() {
        $serviceRequests = $this->_serviceFactory->create()->getCollection();
        $serviceRequests->addFieldToFilter('status', ['eq' => SR_STATUS_PENDING]);
        $serviceRequests->addFieldToFilter('service_request_type', ['neq' => SR_TYPE_PDI]);

        //echo $serviceRequests->getSelect();die;
        if ($serviceRequests->getSize()) {
            $tat = $this->getGeneralConfig('tat');
            foreach ($serviceRequests as $serviceRequest) {
                //$this->_timezone->date()->format('Y-m-d H:i:s')
                $diff = round(abs($this->_timezone->scopeTimeStamp() - strtotime($serviceRequest->getCreatedAt())) / 3600, 2);
                if ($diff > $tat) {
                    //Escalate the service request
                    $this->doServiceRequestEscalation($serviceRequest, true);
                } elseif ($diff > ($tat / 2)) {
                    // Only notify to assigned SD
                }
            }
        }
    }

    /**
     * Service Request Escalate
     * @param \Escorts\ServiceRequest\Model\Service $serviceRequest
     * @param type $isAuto
     * @param type $reasons
     * @param type $comment
     * @return boolean
     */
    public function doServiceRequestEscalation(
    \Escorts\ServiceRequest\Model\Service $serviceRequest, $isAuto = false, $reasons = null, $comment = null
    ) {
        $response = false;

        if (!in_array($serviceRequest->getStatus(), [SR_STATUS_PENDING, SR_STATUS_SCHEDULED, SR_STATUS_IN_PROGRESS])) {
            return $response;
        }

        if (!empty($serviceRequest->getAssignedPo())) {
            try {
                if ($reasons)
                    $serviceRequest->setEscalatedReason($reasons);

                if ($comment)
                    $serviceRequest->setEscalatedComment($comment);

                if ($isAuto)
                    $serviceRequest->setIsAutoEscalated(1);

                $serviceRequest->setEscalatedAt($this->_timezone->date()->format('Y-m-d H:i:s'));
                $serviceRequest->setStatus(SR_STATUS_ESCALATED);
                $serviceRequest->save();

                /* Notify to Project Officer */
                $mobileNumber = $this->_commonHelper->getCustomerMobileByID($serviceRequest->getAssignedPo());
                $message = 'Escalated Service Request #' . $serviceRequest->getId();
                $this->_smsNotificationHelper->sendSms($mobileNumber, $message);

                $response = true;
            } catch (Exception $e) {
                //Exception
                $response = false;
            }
        } else {
            //Email to admin
            //SMS to admin
            $smsText = "Dear Admin, No one available to serve Escalated Service Request # " . $serviceRequest->getId();
            $this->_commonHelper->sendSmsToAdmin($smsText);

            //Notify to Customer support to take care this service request
            $response = false;
        }

        return $response;
    }

    /**
     * Service Request Reject
     * @param \Escorts\ServiceRequest\Model\Service $serviceRequest
     * @param type $reasons
     * @param type $comment
     * @return boolean
     */
    public function doServiceRequestReject(
    \Escorts\ServiceRequest\Model\Service $serviceRequest, $reasons = null, $comment = null
    ) {
        $response = false;

        if (!in_array($serviceRequest->getStatus(), [SR_STATUS_PENDING, SR_STATUS_SCHEDULED, SR_STATUS_IN_PROGRESS, SR_STATUS_ESCALATED])) {
            return $response;
        }

        // $postcode = $this->_commonHelper->getCustomerPostCodeByID($serviceRequest->getCustomerId());
        //if ($postcode) {
        /* if ($serviceRequest->getParentId()) {
          //$assigned_to = $this->_blockHelper->getBlockServiceManager($postcode);
          $response = false;
          } else {
          $assigned_to = $this->_blockHelper->getBlockProjectOfficer($postcode);
          } */

        //if (!empty($assigned_to['id'])) {
        if (!empty($serviceRequest->getAssignedPo())) {
            try {
                $newServiceRequest = $this->_serviceFactory->create();
                $newServiceRequest->setTractorId($serviceRequest->getTractorId());
                $newServiceRequest->setCustomerId($serviceRequest->getCustomerId());
                $newServiceRequest->setAddressId($serviceRequest->getAddressId());
                $newServiceRequest->setLat($serviceRequest->getLat());
                $newServiceRequest->setLong($serviceRequest->getLong());
                $newServiceRequest->setServiceRequestType($serviceRequest->getServiceRequestType());
                $newServiceRequest->setAssignedTo($serviceRequest->getAssignedPo());
                //$newServiceRequest->setAssignedPo($serviceRequest->getAssignedPo());
                $newServiceRequest->setIsFreeService($serviceRequest->getIsFreeService());
                $newServiceRequest->setServiceNo($serviceRequest->getServiceNo());
                $newServiceRequest->setCreatedAt($this->_timezone->date()->format('Y-m-d H:i:s'));
                $newServiceRequest->setCouponCode($serviceRequest->getCouponCode());
                $newServiceRequest->setIssuesId($serviceRequest->getIssuesId());
                $newServiceRequest->setCustomerComment($serviceRequest->getCustomerComment());
                $newServiceRequest->setParentId($serviceRequest->getId());
                $newServiceRequest->setStatus(SR_STATUS_PENDING);
                $newServiceRequest->save();

                if ($reasons) {
                    $serviceRequest->setRejectedReason($reasons);
                }

                if ($comment) {
                    $serviceRequest->setRejectedComment($comment);
                }

                $serviceRequest->setRejectedAt($this->_timezone->date()->format('Y-m-d H:i:s'));
                $serviceRequest->setStatus(SR_STATUS_REJECTED);
                $serviceRequest->save();

                /* Notify to Project Officer */
                $mobileNumber = $this->_commonHelper->getCustomerMobileByID($serviceRequest->getAssignedTo());
                $message = 'A Service Request #' . $newServiceRequest->getId() . ' assigned to you after Reject the Service Request #' . $serviceRequest->getId();
                $this->_smsNotificationHelper->sendSms($mobileNumber, $message);

                $response = true;
            } catch (Exception $e) {
                $response = false;
            }
        }

        /* else {
          //Email to admin
          //SMS to admin
          $smsText = "Dear Admin, No one available to server Service Request Number " . $serviceRequest->getId();
          $this->_commonHelper->sendSmsToAdmin($smsText);

          //Notify to Customer support for take care this service request
          $response = false;
          }
          } */
        return $response;
    }

}
