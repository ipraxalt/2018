<?php

/**
 * Copyright © 2015 Escorts . All rights reserved.
 */

namespace Escorts\ServiceRequest\Helper;

class ServiceRequest extends \Magento\Framework\App\Helper\AbstractHelper {

    /**
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     */
    protected $_orderFactory;

    /**
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     */
    protected $_productFactory;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     */
    protected $_serviceIssuesFactory;

    /**
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $date
     */
    protected $date;

    /**
     * @param \Escorts\ServiceRequest\Model\CustomerTractorFactory $customerTractorFactory
     */
    protected $customerTractorFactory;

    /**
     * @param \Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory
     */
    protected $serviceFactory;

    /**
     * @param \Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory
     */
    protected $_commonHelper;

    /**
     * @param \Escorts\SmsNotification\Helper\Data $smsHelper
     */
    protected $_smsHelper;

    public function __construct(
    \Magento\Framework\App\Helper\Context $context, \Magento\Sales\Model\OrderFactory $orderFactory, \Magento\Catalog\Model\ProductFactory $productFactory, \Escorts\ServiceRequest\Model\ServiceIssuesFactory $serviceIssuesFactory, \Magento\Framework\Stdlib\DateTime\TimezoneInterface $date, \Escorts\ServiceRequest\Model\CustomerTractorFactory $customerTractorFactory, \Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory, \Escorts\Common\Helper\Data $commonHelper, \Escorts\SmsNotification\Helper\Data $smsHelper
    ) {
        $this->_orderFactory = $orderFactory;
        $this->_productFactory = $productFactory;
        $this->_serviceIssuesFactory = $serviceIssuesFactory;
        $this->date = $date;
        $this->customerTractorFactory = $customerTractorFactory;
        $this->serviceFactory = $serviceFactory;
        $this->_commonHelper = $commonHelper;
        $this->_smsHelper = $smsHelper;
        parent::__construct($context);
    }

    public function getServiceProduct($customerId) {
        $orders = $this->_orderFactory->create()->getCollection();
        $orders->addAttributeToSelect("*")
                ->addAttributeToFilter('customer_id', $customerId)
                ->addAttributeToFilter('status', 'complete')->load();
        $response = [];
        foreach ($orders as $order) {
            $orderItems = $order->getAllItems();

            foreach ($orderItems as $item) {
                $_product = $this->_productFactory->create()->load($item->getProductId());
                if ($_product->getAttributeSetId() == TRACTOR_ATTRIBUTE_SET_ID) {
                    /* echo "<pre>"; print_r($i->getProductId()); echo "</pre>";
                      echo "<pre>"; print_r($i->getName()); echo "</pre>";
                      echo "<pre>"; print_r($order->getCreatedAt()); echo "</pre>"; */

                    /* echo "<pre>++"; print_r($order->getEntityId()); echo "</pre>";
                      echo "<pre>**"; print_r($i->getProductId()); echo "</pre>"; */
                    $response[] = [
                        'order_id' => $order->getEntityId(),
                        'created_at' => $order->getCreatedAt(),
                        'delivery_date' => 'XX-YY-ZZZZ',
                        'item_id' => $item->getProductId(),
                        'item_name' => $item->getName(),
                        'status' => $order->getStatus(),
                        'serial_number_1' => $order->getSerialNumber1(),
                        'manufacturing_year_1' => $order->getManufacturingYear1(),
                        'delivery_date_1' => $order->getDeliveryDate1(),
                        'chassis_number_1' => $order->getChassisNumber1(),
                        'engine_number_1' => $order->getEngineNumber1()
                    ];
                }
            }
        }

        if ($response) {
            return $response;
        } else {
            return $response = 'false';
        }
    }

    public function getIssuesList() {
        $issuesCollection = $this->_serviceIssuesFactory->create()->getCollection();

        return $issuesCollection;
    }

    public function addCustomerTractor() {
        $fromDate = $this->date->date()->format('Y-m-d H:i:s');
        $toDate = date('Y-m-d H:i:s', strtotime('-90 days', strtotime($fromDate)));

        $fromDate = date('Y-m-d H:i:s', strtotime($fromDate));
        $toDate = date('Y-m-d H:i:s', strtotime($toDate));

        $orders = $this->_orderFactory->create()->getCollection();
        $orders->addAttributeToFilter('created_at', ['from' => $toDate, 'to' => $fromDate])
                ->addAttributeToFilter('status', ['in' => ['complete', 'delivered', 'in_transit']]);

        foreach ($orders as $order) {
            $orderItems = $order->getAllItems();
            $postcode = $order->getShippingAddress()->getData()['postcode'];

            $serviceDealer = $this->_commonHelper->getBlockServiceDealer($postcode);
            $projectOfficer = $this->_commonHelper->getBlockProjectOfficer($postcode);
            if ($projectOfficer) {
                $po = $projectOfficer['id'];
            } else {
                $po = 0;
            }
            foreach ($orderItems as $item) {
                $_product = $this->_productFactory->create()->load($item->getProductId());
                if ($_product->getAttributeSetId() == TRACTOR_ATTRIBUTE_SET_ID) {
                    $_customerTractor = $this->customerTractorFactory->create()->getCollection();
                    $_customerTractor->addFieldToFilter('order_id', ['eq' => $order->getId()]);

                    if (!$_customerTractor->getSize()) {
                        $customerTractorModel = $this->customerTractorFactory->create();
                        $customerTractorModel->setOrderId($order->getId());
                        $customerTractorModel->setOrderItemId($item->getProductId());
                        $customerTractorModel->setCustomerId($order->getCustomerId());
                        $customerTractorModel->setMakeId(DIGITRAC_MAKE_ID);
                        $customerTractorModel->setModelId($_product->getModel());
                        $customerTractorModel->setSerialNumber($order->getSerialNumber1());
                        $customerTractorModel->setEngineNumber($order->getEngineNumber1());
                        $customerTractorModel->setManufacturingYear($order->getManufacturingYear1());
                        $customerTractorModel->setChassisNumber($order->getChassisNumber1());
                        $customerTractorModel->setCreatedAt($fromDate);
                        $customerTractorModel->setStatus(0);
                        $customerTractorModel->save();
                    }

                    if ($_customerTractor->getSize()) {
                        $tractorId = $_customerTractor->getData()[0]['tractor_id'];
                    } else {
                        $tractorId = $customerTractorModel->getTractorId();
                    }
                    //if order status is in_transit 
                    //Reference code model-test.php Line No. 457 - 

                    if ($order->getStatus() == 'in_transit') {
                        // echo "transit===".$tractorId;
                        $collections = $this->serviceFactory->create()->getCollection();
                        $collections->addFieldToFilter("tractor_id", array("eq" => $tractorId))
                                ->addFieldToFilter("customer_id", array("eq" => $order->getCustomerId()))
                                ->addFieldToFilter("service_request_type", array("eq" => 1))
                                ->addFieldToFilter("service_no", array("eq" => 0))
                                ->load();
                        // echo "<pre>@!@!@!@!"; print_r($collections->getData()); echo "</pre>";
                        if (!empty($serviceDealer) && !empty($po) && $po != 0) {
                            // echo "<pre>++++"; print_r($collections->getData()); echo "</pre>";
                            $model = $this->serviceFactory->create();
                            $model->setTractorId($tractorId);
                            $model->setCustomerId($order->getCustomerId());
                            $model->setServiceRequestType(1);
                            $model->setAssignedTo($serviceDealer);
                            $model->setAssignedPo($po);
                            $model->setIsFreeService(1);
                            $model->setServiceNo(0);
                            $model->save();
                        } elseif (empty($serviceDealer) && !empty($po) && $po != 0) {
                            $model = $this->serviceFactory->create();
                            $model->setTractorId($tractorId);
                            $model->setCustomerId($order->getCustomerId());
                            $model->setServiceRequestType(1);
                            // $model->setAssignedTo($serviceDealer);
                            $model->setAssignedPo($po);
                            $model->setIsFreeService(1);
                            $model->setServiceNo(0);
                            $model->save();
                        } elseif (!empty($serviceDealer) && $po == 0) {
                            $model = $this->serviceFactory->create();
                            $model->setTractorId($tractorId);
                            $model->setCustomerId($order->getCustomerId());
                            $model->setServiceRequestType(1);
                            $model->setAssignedTo($serviceDealer);
                            // model->setAssignedPo($po);
                            $model->setIsFreeService(1);
                            $model->setServiceNo(0);
                            $model->save();
                        } else {
                            echo "No SD, PO found";
                        }
                    }
                }
            }
        }
        exit();
    }

    /**
     * Add Tractor and Create PDI service request, when shipment generated on Tractor Order
     * @param mixed $order
     * @return mixed
     */
    public function addTractorCreatePdi($order) {
        $result = false;

        if (!empty($order->getEntityId())) {
            $fromDate = $this->date->date()->format('Y-m-d H:i:s');
            $orderItems = $order->getAllItems();
            $postcode = $order->getShippingAddress()->getData()['postcode'];

            $serviceDealer = $this->_commonHelper->getBlockServiceDealer($postcode);
            $projectOfficer = $this->_commonHelper->getBlockProjectOfficer($postcode);

            if ($projectOfficer) {
                $po = $projectOfficer['id'];
            } else {
                $po = 0;
            }

            foreach ($orderItems as $item) {
                $_product = $this->_productFactory->create()->load($item->getProductId());

                if ($_product->getAttributeSetId() == TRACTOR_ATTRIBUTE_SET_ID) {
                    $_customerTractor = $this->customerTractorFactory->create()
                            ->getCollection()
                            ->addFieldToFilter('order_id', ['eq' => $order->getId()])
                            ->setPageSize(1);

                    if ($_customerTractor->getSize()) {
                        $tractorId = $_customerTractor->getFirstItem()->getTractorId();
                    } else {
                        $customerTractorModel = $this->customerTractorFactory->create();
                        $customerTractorModel->setOrderId($order->getId());
                        $customerTractorModel->setOrderItemId($item->getProductId());
                        $customerTractorModel->setCustomerId($order->getCustomerId());
                        $customerTractorModel->setMakeId(DIGITRAC_MAKE_ID);
                        $customerTractorModel->setModelId($_product->getModel());
                        $customerTractorModel->setSerialNumber($order->getSerialNumber1());
                        $customerTractorModel->setEngineNumber($order->getEngineNumber1());
                        $customerTractorModel->setManufacturingYear($order->getManufacturingYear1());
                        $customerTractorModel->setChassisNumber($order->getChassisNumber1());
                        $customerTractorModel->setCreatedAt($fromDate);
                        $customerTractorModel->setStatus(0);
                        $customerTractorModel->save();
                        $tractorId = $customerTractorModel->getTractorId();
                    }

                    $collections = $this->serviceFactory->create()
                            ->getCollection()
                            ->addFieldToFilter("tractor_id", ["eq" => $tractorId])
                            ->addFieldToFilter("customer_id", ["eq" => $order->getCustomerId()])
                            ->addFieldToFilter("service_request_type", array("eq" => SR_TYPE_PDI))
                            ->addFieldToFilter("service_no", ["eq" => 0])
                            ->setPageSize(1);

                    if (!$collections->getSize()) {
                        $tractorName = $this->_commonHelper->getTractorNameByTractorId($tractorId);
                        $customerName = $order->getCustomerName();
                        $customerMobile = $this->_commonHelper->getCustomerMobileByID($order->getCustomerId());

                        if (!empty($serviceDealer) && !empty($po) && $po != 0) {
                            $model = $this->serviceFactory->create();
                            $model->setTractorId($tractorId);
                            $model->setCustomerId($order->getCustomerId());
                            $model->setServiceRequestType(1);
                            $model->setAssignedTo($serviceDealer);
                            $model->setAssignedPo($po);
                            $model->setIsFreeService(1);
                            $model->setServiceNo(0);
                            $model->save();
                            $result = true;

                            // SD Service Request Notification
                            $sdName = $this->_commonHelper->getCustomerNameById($serviceDealer);
                            $params = [
                                'name' => $sdName,
                                'sr_id' => $model->getId(),
                                'customer_name' => $customerName,
                                'cusomer_mobile' => $customerMobile,
                                'tractor_name' => $tractorName,
                                'order_inc_id' => $order->getIncrementId()
                            ];
                            $sdMobile = $this->_commonHelper->getCustomerMobileByID($serviceDealer);
                            //$sdMobile = '8630233796';
                            $this->_smsHelper->sendPdiSrRequestSms($sdMobile, $params);

                            $poMobile = $projectOfficer['mobile_number'];
                            //$poMobile = '8630233796';
                            $params['name'] = $projectOfficer['name'];
                            $this->_smsHelper->sendPdiSrRequestSms($poMobile, $params);
                        } elseif (empty($serviceDealer) && !empty($po) && $po != 0) {
                            $model = $this->serviceFactory->create();
                            $model->setTractorId($tractorId);
                            $model->setCustomerId($order->getCustomerId());
                            $model->setServiceRequestType(1);
                            // $model->setAssignedTo($serviceDealer);
                            $model->setAssignedPo($po);
                            $model->setIsFreeService(1);
                            $model->setServiceNo(0);
                            $model->save();
                            $result = true;

                            $params = [
                                'name' => $projectOfficer['name'],
                                'sr_id' => $model->getId(),
                                'customer_name' => $customerName,
                                'cusomer_mobile' => $customerMobile,
                                'tractor_name' => $tractorName,
                                'order_inc_id' => $order->getIncrementId()
                            ];
                            $poMobile = $projectOfficer['mobile_number'];
                            $this->_smsHelper->sendPdiSrRequestSms($poMobile, $params);
                        } elseif (!empty($serviceDealer) && $po == 0) {
                            $model = $this->serviceFactory->create();
                            $model->setTractorId($tractorId);
                            $model->setCustomerId($order->getCustomerId());
                            $model->setServiceRequestType(1);
                            $model->setAssignedTo($serviceDealer);
                            // model->setAssignedPo($po);
                            $model->setIsFreeService(1);
                            $model->setServiceNo(0);
                            $model->save();
                            $result = true;

                            $sdName = $this->_commonHelper->getCustomerNameById($serviceDealer);
                            $params = [
                                'name' => $sdName,
                                'sr_id' => $model->getId(),
                                'customer_name' => $customerName,
                                'cusomer_mobile' => $customerMobile,
                                'tractor_name' => $tractorName,
                                'order_inc_id' => $order->getIncrementId()
                            ];
                            $sdMobile = $this->_commonHelper->getCustomerMobileByID($serviceDealer);
                            $this->_smsHelper->sendPdiSrRequestSms($sdMobile, $params);
                        } else {
                            //echo "No SD, PO found";
                            $result = false;
                        }

                        /* if ($result) {
                          $params = [
                          'name' => $customerName,
                          'sr_id' => $model->getId(),
                          'tractor_name' => $tractorName
                          ];
                          $this->_smsHelper->sendSrSmsToCust($customerMobile, $params);
                          } */
                    }
                }
            }
        }
        return $result;
    }

}
