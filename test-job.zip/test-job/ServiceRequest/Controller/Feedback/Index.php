<?php

namespace Escorts\ServiceRequest\Controller\Feedback;

use Magento\Framework\Controller\ResultFactory;

class Index extends \Magento\Framework\App\Action\Action {

    protected $_pageFactory;
    protected $_serviceFactory;

    public function __construct(
    \Magento\Framework\App\Action\Context $context, \Magento\Framework\View\Result\PageFactory $pageFactory, \Escorts\ServiceRequest\Model\ServiceFactory $_serviceFactory
    ) {
        $this->_pageFactory = $pageFactory;
        $this->_serviceFactory = $_serviceFactory;
        return parent::__construct($context);
    }

    public function execute() {
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        if (!$this->getRequest()->getParam('key')) {
            $resultRedirect->setUrl($this->_redirect->getRefererUrl());
            return $resultRedirect;
        } else {
            $param = explode('+', base64_decode($this->getRequest()->getParam('key')));
            if (!is_numeric($param[0]) || !is_numeric($param[1])) {
                $resultRedirect->setUrl($this->_redirect->getRefererUrl());
                return $resultRedirect;
            }
            $servicefeedbaack = $this->_serviceFactory->create()->load($param[1]);
            // echo "<pre>"; print_r($servicefeedbaack->getData()); echo "</pre>";
            if ($servicefeedbaack->getStatus() != SR_STATUS_COMPLETED) {
                $resultRedirect->setUrl($this->_redirect->getRefererUrl());
                return $resultRedirect;
            }
            if ($servicefeedbaack->getCustomerId() != $param[0]) {
                $resultRedirect->setUrl($this->_redirect->getRefererUrl());
                return $resultRedirect;
            }
            if ($servicefeedbaack->getFeedbackStatus() == 1) {
                $resultRedirect->setUrl($this->_redirect->getRefererUrl());
                return $resultRedirect;
            }
            return $this->_pageFactory->create();
        }
    }

}
