<?php
namespace Escorts\ServiceRequest\Controller\Feedback;

class Save extends \Magento\Framework\App\Action\Action
{
	protected $_serviceFactory;
	protected $_timezone;
   
    public function __construct(
			\Magento\Framework\App\Action\Context $context,
			\Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory,
			\Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
    ) {
    	parent::__construct($context);
    	$this->_serviceFactory = $serviceFactory;
    	$this->_timezone = $timezone;
    }

    public function execute()
    {
    	echo "<pre>@@@@"; print_r($this->getRequest()->getPost()); echo "</pre>";
    }
}