<?php

namespace Escorts\ServiceRequest\Controller\Customer;
use Magento\Framework\Controller\ResultFactory; 



class Requestpost extends \Magento\Customer\Controller\AbstractAccount{
	 /**
     * @var \Magento\Framework\Translate\Inline\ParserInterface
     */
    protected $inlineParser;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $resultJsonFactory;

   
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Translate\Inline\ParserInterface $inlineParser,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
    ) {
        parent::__construct($context);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->inlineParser = $inlineParser;
    }

	
	
	
	
    public function execute(){
		$issuesArray  = $_POST["service_issues"]; 
		$comment = $_POST["comment"];
		$resultMessage='Issues Details not correct';
			
		//print_r($issuesArray);
        $resultJson = $this->resultJsonFactory->create();
        /*try {
            //$this->inlineParser->processAjaxPost($translate);
            $response = ['success' => 'true'];
        } catch (\Exception $e) {
            $response = ['error' => 'true', 'message' => $e->getMessage()];
        }*/

		 $response = ['status' => '1', 'message' => $resultMessage ];
		 
         return $resultJson->setData($response);
	}
}