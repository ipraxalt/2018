<?php
namespace Escorts\ServiceRequest\Controller\Customer;
use Magento\Framework\Controller\ResultFactory; 

class Commentpost extends \Magento\Framework\App\Action\Action{	

	/**
     * @var \Escorts\ServiceRequest\Model\ServiceFactory
	 * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
	protected $_serviceFactory;
	protected $_timezone;
   
    public function __construct(
			\Magento\Framework\App\Action\Context $context,
			\Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory,
			\Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
    ) {
            parent::__construct($context);		
			$this->_serviceFactory = $serviceFactory;
			$this->_timezone = $timezone;
    }

	
	
    public function execute(){
	
		 $rating  = $_POST["rating"]; 
		 $comment = $_POST["comment"];
		 $srid =    $_POST["srid"];
		$serviceCollection = $this->_serviceFactory->create()->load($srid);				  
		$feedbackStatus =  $serviceCollection['feedback_status'];
		
		if(empty($feedbackStatus)){	
			$serviceCollection->setData('feedback_status',1);
			$serviceCollection->setData('feedback_rating',$rating);
			$serviceCollection->setData('feedback_comment',$comment);
			$currentDate = $this->_timezone->date()->format('m-d-Y H:i:s');	
			$serviceCollection->setData('feedback_at',$currentDate);
			try{
				  $serviceCollection->save();
				  $status=1;
				  $resultMessage= 'Feedback Submitted';
				  
			} catch (\Exception $e) { 
				  $this->messageManager->addException($e, __('Something went wrong while adding the feedback.'));
				   $status=0;		
				  $resultMessage = 'Something went wrong while adding the feedback.';
			}						
		}
		else{	
                  $status=0;		
				  $resultMessage = 'Feedback Already Submitted';					
		}
	
			
	    $response = ['status' => $status, 'message' => $resultMessage];
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $resultJson->setData($response); 
        return $resultJson;
	}
}