<?php

namespace Escorts\ServiceRequest\Controller\Customer;

class Request extends \Magento\Customer\Controller\AbstractAccount {

    public function execute() { 
  
    $this->_view->loadLayout(); 
    $this->_view->renderLayout(); 
  } 
  
} 
