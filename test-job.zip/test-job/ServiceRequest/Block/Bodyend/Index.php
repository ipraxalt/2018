<?php

namespace Escorts\ServiceRequest\Block\Bodyend;

use Magento\Framework\View\Element\Template;

class Index extends Template 
{
    protected $_customerSession;

    public function __construct(
    Template\Context $context, \Magento\Customer\Model\Session $_customerSession, array $data = []
    ) {
        $this->_customerSession = $_customerSession;
        parent::__construct($context, $data);
    }

    public function getCustomerId()
    {
        if ($this->_customerSession->isLoggedIn()) {
            return true;
        }
        return false;
    }
}
