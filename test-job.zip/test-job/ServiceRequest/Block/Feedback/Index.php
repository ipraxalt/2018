<?php

namespace Escorts\ServiceRequest\Block\Feedback;

use Magento\Framework\View\Element\Template;

class Index extends Template
{
	protected $_commonHelper;

	public function __construct(
		Template\Context $context, \Magento\Customer\Model\CustomerFactory $customerFactory, \Escorts\Common\Helper\Data $_commonHelper, array $data = []
    ) {
    	$this->customerFactory = $customerFactory;
    	$this->_commonHelper = $_commonHelper;
        parent::__construct($context, $data);
    }

    public function getParameters()
    {
    	$param = $this->getRequest()->getparam('key');
    	return $param;
    }

    public function getCustomerId()
    {
    	$params = explode('+', base64_decode($this->getParameters()));
    	return $params[0];
    }

    public function getSrId()
    {
    	$params = explode('+', base64_decode($this->getParameters()));
    	return $params[1];
    }

    public function getCustomerName()
    {
    	// echo "--".$this->getCustomerId(); die();
    	if ($this->getCustomerId()) {
    		$name = $this->customerFactory->create()->load($this->getCustomerId())->getName();
    		if (!empty($name)) {
    			return $name;
    		}
    	}
    	return false;
    }

    public function getCustomerToken()
    {
    	return $this->_commonHelper->getCustomerTokenById($this->getCustomerId());
    }

}