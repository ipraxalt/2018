<?php

namespace Escorts\ServiceRequest\Block\Customer\ServiceRequest;

class RequestList extends \Magento\Framework\View\Element\Template {

    protected $customerSession;
    protected $customerFactory;
    protected $_serviceFactory;
    protected $resultPageFactory;
    protected $_productloader;
    protected $_serviceTypeFactory;
    protected $request;
    protected $_serviceIssuesFactory;
    protected $_addressModel;
    protected $_commonHelper;
    protected $_countryFactory;
    protected $_timezone;
    protected $_storeManager;
    protected $_jobNoFactory;
    protected $_currencyHelper;

    public function __construct(
    \Magento\Framework\View\Element\Template\Context $context, \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone, \Magento\Framework\ObjectManagerInterface $objectManager, \Magento\Directory\Model\CountryFactory $countryFactory, \Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory, \Magento\Customer\Model\Session $customerSession, \Escorts\Common\Helper\Data $commonHelper, \Magento\Customer\Model\CustomerFactory $customerFactory, \Magento\Framework\View\Result\PageFactory $resultPageFactory, \Escorts\ServiceRequest\Model\RequestTypeFactory $serviceTypeFactory, \Magento\Framework\App\Request\Http $request, \Escorts\ServiceRequest\Model\ServiceIssuesFactory $serviceIssuesFactory, \Magento\Customer\Model\Address $addressModel, \Magento\Catalog\Model\ProductFactory $_productloader, \Magento\Store\Model\StoreManagerInterface $storeManager, \Escorts\ServiceRequest\Model\ServiceJobNoFactory $jobNoFactory, \Magento\Framework\Pricing\Helper\Data $currencyHelper, array $data = []
    ) {
        $this->_serviceTypeFactory = $serviceTypeFactory;
        $this->resultPageFactory = $resultPageFactory;
        $this->customerSession = $customerSession;
        $this->_serviceFactory = $serviceFactory;
        $this->_productloader = $_productloader;
        $this->request = $request;
        $this->_serviceIssuesFactory = $serviceIssuesFactory;
        $this->_customerFactory = $customerFactory;
        $this->_addressModel = $addressModel;
        $this->_commonHelper = $commonHelper;
        $this->_storeManager = $storeManager;
        $this->_countryFactory = $countryFactory;
        $this->_timezone = $timezone;
        $this->_jobNoFactory = $jobNoFactory;
        $this->_currencyHelper = $currencyHelper;
        parent::__construct($context, $data);
    }

    protected function _prepareLayout() {
        parent::_prepareLayout();
        $this->pageConfig->getTitle()->set(__('Service Request'));
        if ($this->getCurrentCustomerServiceRequestList()) {
            $pager = $this->getLayout()->createBlock('Magento\Theme\Block\Html\Pager', 'vlc.history.pager')->setAvailableLimit([5 => 5, 10 => 10, 15 => 15, 20 => 20]);
            $pager->setLimit(5)->setShowPerPage(true);
            $pager->setCollection($this->getCurrentCustomerServiceRequestList());
            $this->setChild('pager', $pager);
            $this->getCurrentCustomerServiceRequestList()->load();
        }
        return $this;
    }

    public function getPagerHtml() {
        return $this->getChildHtml('pager');
    }

    public function getCustomer() {
        return $this->customerSession->getCustomer()->getData();
    }

    /* Get Product Details By ID */

    public function getProduct($pid) {
        $productCollection = $this->_productloader->create()->load($pid);
        return $productCollection;
    }

    /* Get Service Type Name By ID */

    public function getServiceType($typeId) {
        $serviceTypeResponce = '';
        $serviceTypeName = "";
        $serviceTypeCollection = $this->_serviceTypeFactory->create()->getCollection()
                ->addFieldToSelect('value')
                ->addFieldToFilter('id', ['eq' => $typeId]);
        $serviceTypeResponce = $serviceTypeCollection->getData();
        if ($serviceTypeResponce) {
            $serviceTypeName = $serviceTypeResponce[0]['value'];
        }
        return $serviceTypeName;
    }

    /**
     * Get Current Customer All request
     * @return mixed
     */
    public function getCurrentCustomerServiceRequestList() {
        if ($this->getCustomer()) {
            //get values of current page
            $page = ($this->getRequest()->getParam('p')) ? $this->getRequest()->getParam('p') : 1;
            //get values of current limit
            $pageSize = ($this->getRequest()->getParam('limit')) ? $this->getRequest
                    ()->getParam('limit') : 5;
            $cid = $this->customerSession->getCustomer()->getId();
            $serviceModel = $this->_serviceFactory->create()
                    ->getCollection()
                    ->addFieldToFilter('customer_id', ['eq' => $cid])
                    ->addFieldToFilter('status', ['neq' => 1])
                    ->addFieldToFilter('service_request_type', ['neq' => 1]);

            $serviceModel->setPageSize($pageSize);
            $serviceModel->setCurPage($page);
        }
        return $serviceModel;
    }

    /**
     * Returns Service Total Amount
     * @param type $srId
     * @return type
     */
    public function getServiceAmount($srId) {
        if ($srId) {
            $jobModel = $this->_jobNoFactory->create()->load($srId, 'srid');

            if ($jobModel->getStatus()) {
                return $this->_currencyHelper->currency(number_format($jobModel->getGrandTotal(), 2, '.', ''), true, false);
            }
        }

        return __('N/A');
    }

    /**
     * Get Current request details
     * @return mixed
     */
    public function getServiceRequestdetails() {
        $customerId = $this->customerSession->getCustomer()->getId();
        $params = $this->request->getParams();
        $requestData = [];
        $requestId = $params['request_id'];
        $serviceCollection = $this->_serviceFactory->create()
                ->getCollection()
                ->addFieldToFilter('id', ['eq' => $requestId])
                ->addFieldToFilter('customer_id', ['eq' => $customerId]);
        $requestResponce = $serviceCollection->getData();

        if ($requestResponce) {
            $requestData['id'] = $requestResponce[0]['id'];
            $requestData['status'] = $requestResponce[0]['status'];
            $requestData['tractor_id'] = $requestResponce[0]['tractor_id'];
            $requestData['date'] = $requestResponce[0]['created_at'];
            // $productCollection = $this->_productloader->create()->load($requestResponce[0]['order_item_id']);
            $productCollection = $this->_productloader->create()->load($requestResponce[0]['tractor_id']);
            $requestData['product_name'] = $productCollection->getName();
            $serviceTypeCollection = $this->_serviceTypeFactory->create()->getCollection()
                    ->addFieldToSelect('value')
                    ->addFieldToFilter('id', ['eq' => $requestResponce[0]['service_request_type']]);
            $serviceTypeResponce = $serviceTypeCollection->getData();

            if ($serviceTypeResponce) {
                $serviceTypeName = $serviceTypeResponce[0]['value'];
            }

            $requestData['service_type'] = $serviceTypeName;
            $requestData['service_number'] = $requestResponce[0]['service_no'];
            $requestData['coupon_code'] = $requestResponce[0]['coupon_code'];
            $requestData['customer_name'] = "";
            $customerAaddress = "";
            //$requestData['customer_address'] = "";

            $customer = $this->_customerFactory->create()->load($customerId);
            if ($customer) {
                //$requestData['customer_name'] = $customer->getFirstname();
                $shippingAddressId = $customer->getDefaultShipping();
                $address = $this->_addressModel->load($shippingAddressId);
                if ($address) {
                    if (!empty($address->getStreet())) {
                        $customerAaddress = implode(" ", $address->getStreet());
                    }
                    if (!empty($address->getLandmark())) {
                        $customerAaddress = $customerAaddress . ', ' . $address->getLandmark();
                    }
                    if (!empty($address->getVillage())) {
                        $customerAaddress = $customerAaddress . ', ' . $address->getVillage();
                    }
                    if (!empty($address->getTehsil())) {
                        $customerAaddress = $customerAaddress . ', ' . $address->getTehsil();
                    }
                    if (!empty($address->getCity())) {
                        $customerAaddress = $customerAaddress . ', ' . $address->getCity();
                    }
                    if (!empty($address->getCountryId())) {
                        $addressCountry = $this->_countryFactory->create()->loadByCode($address->getCountryId())->getName();
                        $customerAaddress = $customerAaddress . ', ' . $addressCountry;
                    }
                    if (!empty($address->getPostcode())) {
                        $customerAaddress = $customerAaddress . ', ' . $address->getPostcode();
                    }
                }
                $requestData['customer_address'] = $customerAaddress;
            }

            /* dealer customer */
            $requestData['dealer_id'] = $requestResponce[0]['assigned_to'];

            $requestData['dealer_image'] = "";

            $serviceDealerCustomer = $this->_customerFactory->create()->load($requestResponce[0]['assigned_to']);
            if ($serviceDealerCustomer) {
                $requestData['dealer_name'] = $serviceDealerCustomer->getFirstname() . ' ' . $serviceDealerCustomer->getLastname();
            }

            $profileImage = $serviceDealerCustomer->getResource()->getAttribute('profile_picture')->getFrontend()->getValue($serviceDealerCustomer);

            if ($profileImage) {
                $media_dir = $this->_storeManager->getStore()
                        ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
                $path = $media_dir . '/customer' . $profileImage;
                $requestData['dealer_image'] = $path;
            }

            $requestData['status'] = $requestResponce[0]['status'];
            $requestData['accept_status'] = $requestResponce[0]['accept_status'];
            $issuesId = $requestResponce[0]['issues_id'];
            $issuesArray = [];
            if (!empty($issuesId)) {
                $issuesCollection = $this->_serviceIssuesFactory->create()->getCollection()
                        ->addFieldToSelect('value')
                        ->addFieldToFilter('id', ['in' => $issuesId]);

                foreach ($issuesCollection as $key => $issue) {
                    $issuesArray[$key] = $issue['value'];
                }
            }

            $requestData['issues_id'] = $issuesArray;
            $requestData['feedback_status'] = $requestResponce[0]['feedback_status'];
            $requestData['feedback_rating'] = $requestResponce[0]['feedback_rating'];

            if ($requestData['feedback_status'] == 1 && empty($requestResponce[0]['feedback_comment'])) {
                $requestData['comment'] = "You have added no comment";
            } else {
                $requestData['comment'] = $requestResponce[0]['feedback_comment'];
            }

            if ($requestResponce[0]['status'] == SR_STATUS_COMPLETED) {
                $requestData['feedback_rating'] = 100.50;
            } else {
                $requestData['feedback_rating'] = __('N/A');
            }
        }

        return $requestData;
    }

    public function viewDealerProfile($sdid) {
        $response = [];
        $customer = $this->_customerFactory->create()->load($sdid);
        if ($customer) {
            $response['sd_id'] = $sdid;
            $customerFullName = $customer->getFirstname() . ' ' . $customer->getLastname();
            $response['sd_name'] = $customerFullName;
            $response['sd_image'] = "";
            $profileImage = $customer->getResource()->getAttribute('profile_picture')->getFrontend()->getValue($customer);

            if ($profileImage) {
                $media_dir = $this->_storeManager->getStore()
                        ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
                $path = $media_dir . '/customer' . $profileImage;
                $response['sd_image'] = $path;
            }

            if ($this->_commonHelper->getServiceDealerRating($sdid)) {
                $rating = $this->_commonHelper->getServiceDealerRating($sdid);
                $response['rating'] = $rating;
            } else {
                $response['rating'] = '';
            }

            if ($customer->getCreatedAt()) {
                $customerCreatedDate = $customer->getCreatedAt();
                $currentDate = $this->_timezone->date()->format('Y-m-d H:i:s');
                $dateDiff = abs(strtotime($currentDate) - strtotime($customerCreatedDate));
                $years = floor($dateDiff / (365 * 60 * 60 * 24));
                $months = floor(($dateDiff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
                $response['duration_yr'] = $years;
                $response['duration_month'] = $months;
            }

            $customerExpertise = $customer->getResource()->getAttribute('expertise_models')->getFrontend()->getValue($customer);
            if ($customerExpertise) {
                //$customerExpertise = explode(',',$customerExpertise );
                $response['specialization'] = $customerExpertise;
            } else {
                $response['specialization'] = "";
            }

            $shippingAddressId = $customer->getDefaultShipping();
            $address = $this->_addressModel->load($shippingAddressId);
            if ($address) {
                if (!empty($address->getCity())) {
                    $response['district'] = $address->getCity();
                }
                if (!empty($address->getRegion())) {
                    $response['state'] = $address->getRegion();
                }
                if (!empty($address->getPostcode())) {
                    $response['post_code'] = $address->getPostcode();
                }
            }
            $response['compliment'] = 'Lorem Ipsum is simply dummy text of the printing and typesetting industry';
        }
        return $response;
    }

    /* Page Url Set */

    public function getUrlAction() {
        return $this->getUrl('servicerequest/customer/', ['_secure' => true]);
    }

    public function getTractorName($tractorId) {
        return $this->_commonHelper->getTractorNameByTractorId($tractorId);
    }

}
