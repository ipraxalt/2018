<?php

namespace Escorts\ServiceRequest\Block\Customer\ServiceRequest;

use Magento\Framework\View\Element\Template;

class RequestCreate extends Template {

    protected $customerSession;
    protected $customerFactory;
    protected $_serviceFactory;
    protected $resultPageFactory;
    protected $_productloader;
    protected $_serviceTypeFactory;
    protected $_serviceIssuesFactory;
    protected $_serviceHelper;
    protected $layoutProcessors;
    protected $_commonHelper;

    public function __construct(
    \Magento\Framework\View\Element\Template\Context $context, \Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory, \Magento\Customer\Model\Session $customerSession, \Magento\Customer\Model\CustomerFactory $customerFactory, \Magento\Framework\View\Result\PageFactory $resultPageFactory, \Escorts\ServiceRequest\Model\RequestTypeFactory $serviceTypeFactory, \Magento\Framework\App\Request\Http $request, \Escorts\ServiceRequest\Model\ServiceIssuesFactory $serviceIssuesFactory, \Escorts\ServiceRequest\Helper\ServiceRequest $serviceHelper, \Magento\Catalog\Model\ProductFactory $_productloader, \Escorts\Common\Helper\Data $_commonHelper, array $layoutProcessors = [], array $data = []
    ) {
        $this->_serviceTypeFactory = $serviceTypeFactory;
        $this->resultPageFactory = $resultPageFactory;
        $this->customerSession = $customerSession;
        $this->_serviceFactory = $serviceFactory;
        $this->_productloader = $_productloader;
        $this->_serviceIssuesFactory = $serviceIssuesFactory;
        $this->_serviceHelper = $serviceHelper;
        $this->jsLayout = isset($data['jsLayout']) && is_array($data['jsLayout']) ? $data['jsLayout'] : [];
        $this->layoutProcessors = $layoutProcessors;
        $this->_commonHelper = $_commonHelper;
        parent::__construct($context, $data);
    }

    public function getJsLayout() {
        foreach ($this->layoutProcessors as $processor) {
            $this->jsLayout = $processor->process($this->jsLayout);
        }
        return \Zend_Json::encode($this->jsLayout);
    }

    public function getCustomerToken() {
        return $this->_commonHelper->getLoggedInCustomerToken();
    }

    public function getCustomer() {
        return $this->customerSession->getCustomer()->getData();
    }

    public function getServiceProduct() {
        $cid = $this->customerSession->getCustomer()->getId();
        $requestResponce = $this->_serviceHelper->getServiceProduct($cid);
        return $requestResponce;
    }

    public function getServicesIssuesList() {

        $requestResponce = $this->_serviceHelper->getIssuesList();
        return $requestResponce;
    }

    public function getUrlAction() {
        return $this->getUrl('servicerequest/customer/', ['_secure' => true]);
    }

}
