<?php

namespace Escorts\ServiceRequest\Block\Tractor;

use Magento\Framework\View\Element\Template;

class Index extends Template {

    /**
     * @var array|\Magento\Checkout\Block\Checkout\LayoutProcessorInterface[]
     */
    protected $layoutProcessors;
    protected $_commonHelper;

    public function __construct(
    Template\Context $context, \Escorts\Common\Helper\Data $_commonHelper, array $layoutProcessors = [], array $data = []
    ) {
        parent::__construct($context, $data);
        $this->jsLayout = isset($data['jsLayout']) && is_array($data['jsLayout']) ? $data['jsLayout'] : [];
        $this->layoutProcessors = $layoutProcessors;
        $this->_commonHelper = $_commonHelper;
    }

    public function getJsLayout() {
        foreach ($this->layoutProcessors as $processor) {
            $this->jsLayout = $processor->process($this->jsLayout);
        }
        return \Zend_Json::encode($this->jsLayout);
    }

    public function getCustomerToken() {
        return $this->_commonHelper->getLoggedInCustomerToken();
    }

}
