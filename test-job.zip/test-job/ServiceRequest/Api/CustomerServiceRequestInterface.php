<?php

namespace Escorts\ServiceRequest\Api;

interface CustomerServiceRequestInterface {

    /**
     * @api
     * @param int $customerId
     * @param mixed $serviceRequest
     * @return void
     */
    public function createServiceRequest($customerId, $serviceRequest);

    /**
     * @api
     * @param int $customerId
     * @return JSON array
     */
    public function requestList($customerId);

    /**
     * @api
     * @param int $customerId
     * @param int $srid
     * @return JSON array
     */
    public function requestDetailsById($customerId, $srid);

    /**
     * @api
     * @param int $customerId
     * @param int $sdid
     * @return JSON array
     */
    public function viewDealerProfile($customerId, $sdid);

    /**
     * @api
     * @param int $customerId
     * @param int $srid
     * @param mixed $rating
     * @param string $comment
     * @return JSON array
     */
    public function addServiceRequestFeedback($customerId, $srid, $rating, $comment);

    /**
     * @api
     * @param int $customerId
     * @return JSON array
     */
    public function getCustomerTractors($customerId);

    /**
     * @api
     * @return JSON array
     */
    public function getAllMake();

    /**
     * @api
     * @param int $makeId
     * @return JSON array
     */
    public function getModelByMakeId($makeId);

    /**
     * @api
     * @param int $customerId
     * @param mixed $newTractorRequest
     * @return JSON array
     */
    public function addNewTractor($customerId, $newTractorRequest);

    /**
     * @api
     * @param int $customerId
     * @param mixed $requestData
     * @return JSON array
     */
    public function updateTractor($customerId, $requestData);

    /**
     * @api
     * @param int $customerId
     * @return JSON array
     */
    public function getAllTractor($customerId);

    /**
     * @api
     * @param mixed $srCancelData
     * @return JSON array
     */
    public function cancelServiceRequest($srCancelData);

    /**
     * @api
     * @param int $customerId
     * @param int $tractorId
     * @return JSON array
     */
    public function editTractor($customerId, $tractorId);
}
