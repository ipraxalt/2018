<?php

namespace Escorts\ServiceRequest\Api;

interface ServiceRequestInterface {

    /**
     * @api
     * @param int $customerId
     * @param int $statusId
     * @param int $curPage
     * @param int $pageSize
     * @return mixed
     */
    public function getServiceRequestList($customerId, $statusId, $curPage, $pageSize);

    /**
     * @api
     * @param int $customerId
     * @param int $srid
     * @return mixed
     */
    public function getServiceRequestCustomer($customerId, $srid);

    /**
     * @api
     * @param int $customerId
     * @param int $srid
     * @return mixed
     */
    public function getServiceRequestTractor($customerId, $srid);

    /**
     * @api
     * @param int $customerId
     * @param int $srid
     * @return mixed
     */
    public function getServiceRequestServiceDetail($customerId, $srid);

    /**
     * @api
     * @param int $customerId
     * @param int $srid
     * @return mixed
     */
    public function getServiceRequestDetail($customerId, $srid);

    /**
     * @api
     * @param int $customerId
     * @return mixed
     */
    public function getServiceRequestServiceType($customerId);

    /**
     * @api
     * @param int $customerId
     * @return mixed
     */
    public function getServiceRequestServiceIssues($customerId);

    /**
     * @api
     * @param int $customerId
     * @param mixed $observationId
     * @return mixed
     */
    public function removeObservation($customerId, $observationId);

    /**
     * @api
     * @param int $customerId
     * @param int $srid
     * @param mixed $pdiData
     * @param mixed $observations
     * @param mixed $partsData
     * @return mixed
     */
    public function createServiceRequestPdi($customerId, $srid, $pdiData = null, $observations = null, $partsData = null);

    /**
     * @param int $customerId
     * @param int $srid
     * @param int $jobPartId
     * @return mixed
     */
    public function removeJobPart($customerId, $srid, $jobPartId);

    /**
     * @api
     * @param int $customerId
     * @return mixed
     */
    public function getServiceRequestOptions($customerId);

    /**
     * @api
     * @param int $customerId
     * @param int $serviceRequestType
     * @param int $srid
     * @param mixed $lat
     * @param mixed $long
     * @return mixed
     */
    public function getServiceRequestJobNo($customerId, $serviceRequestType, $srid, $lat = null, $long = null);

    /**
     * @api
     * @param int $customerId
     * @param int $srid
     * @return mixed
     */
    public function getServiceRequestPdi($customerId, $srid);

    /**
     * @api
     * @param int $customerId
     * @param int $srid
     * @return mixed
     */
    public function sendInstallationOtp($customerId, $srid);

    /**
     * @api
     * @param int $customerId
     * @param int $srid
     * @param string $otp
     * @return mixed
     */
    public function verifyInstallationOtp($customerId, $srid, $otp);

    /**
     * @api
     * @param int $customerId
     * @param mixed $serviceRequestInstallation
     * @return mixed
     */
    public function createServiceRequestInstallation($customerId, $serviceRequestInstallation);

    /**
     * @api
     * @param int $customerId
     * @param int $serviceRequestType
     * @param int $srid
     * @return mixed
     */
    public function getServiceRequestInstallation($customerId, $serviceRequestType, $srid);

    /**
     * @api
     * @param int $customerId
     * @param int $srid
     * @param mixed $reasons
     * @param string $comment
     * @return mixed
     */
    public function serviceRequestEscalate($customerId, $srid, $reasons, $comment);

    /**
     * @api
     * @param int $customerId
     * @param int $srid
     * @return mixed
     */
    public function serviceRequestAccept($customerId, $srid);

    /**
     * @api
     * @param int $customerId
     * @param int $srid
     * @param string $reasons
     * @param string $comment
     * @return mixed
     */
    public function serviceRequestReject($customerId, $srid, $reasons, $comment = null);

    /**
     * @api
     * @param int $customerId
     * @param int $srid
     * @param string $datetime
     * @param string $comment
     * @return mixed
     */
    public function serviceRequestSchedule($customerId, $srid, $datetime, $comment = null);

    /**
     * @api
     * @param int $customerId
     * @param int $srid
     * @return mixed
     */
    public function serviceRequestSchedules($customerId, $srid);
}
