<?php

/**
 * Escorts
 */

namespace Escorts\ServiceRequest\Model;

use Escorts\ServiceRequest\Api\CustomerServiceRequestInterface;
//use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Phrase;

class CustomerServiceRequest implements CustomerServiceRequestInterface {

    const XML_FOUR_RATING_AMOUNT = 'servicerequest/rating/four';
    const XML_FIVE_RATING_AMOUNT = 'servicerequest/rating/five';
    const CONST_NULL = null;
    const SR_ACCEPT_STATUS = '1';
    const FEEDBACK_STATUS_ENABLE = '1';
    const STATUSES = [
        ['id' => 0, 'value' => 'Pending'],
        ['id' => 2, 'value' => 'Closed/Done']
    ];
    const SR_TYPES = [
        [
            'sr_type_id' => 1,
            'sr_type_value' => 'PDI'
        ],
        [
            'sr_type_id' => 2,
            'sr_type_value' => 'Installation'
        ],
        [
            'sr_type_id' => 3,
            'sr_type_value' => 'Free/Routine Service'
        ],
        [
            'sr_type_id' => 4,
            'sr_type_value' => 'Repair'
        ]
    ];

    /**
     * @var Escorts\ServiceRequest\Model\Service
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $jsonHelper;
    protected $_serviceFactory;
    protected $_serviceIssuesFactoryArray;
    protected $_commonHelper;
    protected $_productloader;
    protected $_ServiceJobNoFactory;
    protected $_jobNoFactory;
    protected $_customerFactory;
    protected $_addressModel;
    protected $_countryFactory;
    protected $objectManager;
    protected $_timezone;
    protected $_customerTractorFactory;
    protected $_makeMasterFactory;
    protected $_modelMasterFactory;
    protected $_servicePlanItemsFactory;
    protected $_smsHelper;
    protected $_serviceStatusesFactory;
    protected $_serviceRequestTypeFactory;
    protected $customEmailsHelper;
    protected $_serviceFeedbackInvoiceFactory;
    protected $_scopeConfig;

    /**
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
     * @param \Escorts\Common\Helper\Data $commonHelper
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Magento\Customer\Model\Address $addressModel
     * @param \Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory
     * @param \Magento\Directory\Model\CountryFactory $countryFactory
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     * @param \Escorts\ServiceRequest\Model\ServiceJobNoFactory $jobNoFactory
     * @param \Magento\Catalog\Model\ProductFactory $_productloader
     * @param \Escorts\ServiceRequest\Model\ServiceIssuesFactory $serviceIssuesFactory
     * @param \Escorts\ServiceRequest\Model\CustomerTractorFactory $_customerTractorFactory
     * @param \Escorts\ModelMaster\Model\MakeMasterFactory $_makeMasterFactory
     * @param \Escorts\ModelMaster\Model\ModelMasterFactory $_modelMasterFactory
     * @param \Escorts\ServicePlan\Model\ServicePlanItemsFactory $_servicePlanItemsFactory
     * @param \Escorts\SmsNotification\Helper\Data $_smsHelper
     * @param \Escorts\ServiceRequest\Model\ServiceStatusesFactory $serviceStatusesFactory
     * @param \Escorts\ServiceRequest\Model\RequestTypeFactory $serviceRequestTypeFactory
     * @param \Escorts\CustomEmails\Helper\Data $customEmailsHelper
     * @param \Escorts\ServiceRequest\Model\ServiceFeedbackInvoice $serviceFeedbackInvoiceFactory
     */
    public function __construct(\Magento\Framework\Json\Helper\Data $jsonHelper, \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone, \Escorts\Common\Helper\Data $commonHelper, \Magento\Framework\ObjectManagerInterface $objectManager, \Magento\Customer\Model\Address $addressModel, \Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory, \Magento\Directory\Model\CountryFactory $countryFactory, \Magento\Customer\Model\CustomerFactory $customerFactory, \Escorts\ServiceRequest\Model\ServiceJobNoFactory $jobNoFactory, \Magento\Catalog\Model\ProductFactory $_productloader, \Escorts\ServiceRequest\Model\ServiceIssuesFactory $serviceIssuesFactory, \Escorts\ServiceRequest\Model\CustomerTractorFactory $_customerTractorFactory, \Escorts\ModelMaster\Model\MakeMasterFactory $_makeMasterFactory, \Escorts\ModelMaster\Model\ModelMasterFactory $_modelMasterFactory, \Escorts\ServicePlan\Model\ServicePlanItemsFactory $_servicePlanItemsFactory, \Escorts\SmsNotification\Helper\Data $_smsHelper, \Escorts\ServiceRequest\Model\ServiceStatusesFactory $serviceStatusesFactory, \Escorts\ServiceRequest\Model\RequestTypeFactory $serviceRequestTypeFactory, \Escorts\CustomEmails\Helper\Data $customEmailsHelper, \Escorts\ServiceRequest\Model\ServiceFeedbackInvoiceFactory $serviceFeedbackInvoiceFactory, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        $this->_serviceFactory = $serviceFactory;
        $this->jsonHelper = $jsonHelper;
        $this->_serviceIssuesFactory = $serviceIssuesFactory;
        $this->_jobNoFactory = $jobNoFactory;
        $this->_commonHelper = $commonHelper;
        $this->_productloader = $_productloader;
        $this->_customerFactory = $customerFactory;
        $this->_addressModel = $addressModel;
        $this->_countryFactory = $countryFactory;
        $this->objectManager = $objectManager;
        $this->_timezone = $timezone;
        $this->_customerTractorFactory = $_customerTractorFactory;
        $this->_makeMasterFactory = $_makeMasterFactory;
        $this->_modelMasterFactory = $_modelMasterFactory;
        $this->_servicePlanItemsFactory = $_servicePlanItemsFactory;
        $this->_smsHelper = $_smsHelper;
        $this->_serviceStatusesFactory = $serviceStatusesFactory;
        $this->_serviceRequestTypeFactory = $serviceRequestTypeFactory;
        $this->customEmailsHelper = $customEmailsHelper;
        $this->_serviceFeedbackInvoiceFactory = $serviceFeedbackInvoiceFactory;
        $this->_scopeConfig = $scopeConfig;
    }

    /**
     * Get Customer Service Request List
     * @param int $customerId
     * @return mixed
     */
    public function requestList($customerId) {
        $response = [];
        $issuesArray = [];
        $currencyArray = [];

        /* Load service request list */
        $serviceModal = $this->_serviceFactory->create()->getCollection()
                ->addFieldToFilter('customer_id', ['eq' => $customerId])
                ->addFieldToFilter('status', ['neq' => 1])
                ->addFieldToFilter('service_request_type', ['neq' => 1]);

        if (!empty($serviceModal->getSize())) {
            /* Get Issues List */
            $issuesCollection = $this->_serviceIssuesFactory->create()->getCollection();
            if (!empty($issuesCollection->getSize())) {
                foreach ($issuesCollection as $issue) {
                    $key = $issue->getId();
                    $issuesArray[] = ['id' => $key, 'value' => $issue->getValue()];
                }
            }
            /* Get currency Symbol and code */
            //$currencyArray['currency_symbol'] = $this->_commonHelper->getStoreCurrencySymbol();
            //$currencyArray['currency_code'] = $this->_commonHelper->getStoreCurrencyCode();

            $count = 0;
            $checkSrType = [SR_TYPE_ROUTINE, SR_TYPE_REPAIR];

            foreach ($serviceModal as $serviceItem) {
                $data[$count]['sr_id'] = $serviceItem->getId();
                $data[$count]['sr_id_str'] = str_pad((string) $serviceItem->getId(), 10, '0', STR_PAD_LEFT);
                $data[$count]['sr_type'] = $serviceItem->getServiceRequestType();
                $data[$count]['sr_type_str'] = $this->getSrTypeString($serviceItem->getServiceRequestType());
                $data[$count]['accept_status'] = $serviceItem->getAcceptStatus();
                $data[$count]['status'] = $serviceItem->getStatus();
                $data[$count]['status_str'] = $this->getSrStatusString($serviceItem->getStatus());
                $data[$count]['issues_id'] = self::CONST_NULL;
                $data[$count]['amount'] = null;
                $jobClosedDate = '';

                $issuesId = $serviceItem->getIssuesId();

                $issuesResultArray = [];
                if (!empty($issuesId)) {
                    $issuesCollection = $this->_serviceIssuesFactory->create()->getCollection()
                            ->addFieldToSelect('id', 'value')
                            ->addFieldToFilter('id', ['in' => $issuesId]);

                    foreach ($issuesCollection as $key => $issue) {
                        $issuesResultArray[$key] = $issue['value'];
                    }
                }

                $customerTractor = $this->_customerTractorFactory
                        ->create()
                        ->load($serviceItem->getTractorId());

                $makeId = $customerTractor->getMakeId();
                $modelId = $customerTractor->getModelId();

                $name = $this->_commonHelper->getTractorName($makeId, $modelId);
                // $data[$count]['tr_id'] = $serviceItem->getTractorId();
                // echo "<pre>>>>+"; print_r($name); echo "</pre>";
                // $productCollection = $this->_productloader->create()->load($serviceItem->getOrderItemId());
                //$data[$count]['product_name'] = $productCollection->getName();
                $data[$count]['product_name'] = $name;

                /* if (!$productCollection->getName()) {
                  //throw new \Magento\Framework\Webapi\Exception(new Phrase('Product does not exist.'), 0, \Magento\Framework\Webapi\Exception::HTTP_INTERNAL_ERROR);
                  } */

                $data[$count]['created_at'] = $serviceItem->getCreatedAt();
                $data[$count]['closed_at'] = self::CONST_NULL;

                $jobNoModel = $this->_jobNoFactory->create()
                        ->getCollection()
                        ->addFieldToSelect(['grand_total', 'closed_at'])
                        ->addFieldToFilter('srid', ['eq' => $serviceItem->getId()]);

                if ($jobNoModel->getSize()) {
                    if (in_array($serviceItem->getServiceRequestType(), $checkSrType)) {
                        if ($serviceItem->getStatus() == SR_STATUS_COMPLETED &&
                                $serviceItem->getAcceptStatus() == self::SR_ACCEPT_STATUS) {
                            $data[$count]['amount'] = $jobNoModel->getFirstItem()->getGrandTotal();
                            $data[$count]['issues_id'] = $issuesResultArray;
                        }
                    }

                    if ($serviceItem->getStatus() == SR_STATUS_COMPLETED) {
                        $data[$count]['closed_at'] = $jobNoModel->getFirstItem()->getClosedAt();
                    }
                }

                $count++;
            }

            $response[$key]['status'] = 1;
            $response[$key]['message'] = __('Service request found');
            $response[$key]['service_requests'] = $data;
            $response[$key]['statuses'] = $this->_serviceStatusesFactory->create()
                    ->getCollection()
                    ->addFieldToFilter('status_id', ['neq' => -1])
                    ->getData();

            foreach ($response[$key]['statuses'] as $index => $statuses) {
                if ($statuses['value'] == 'Escalated') {
                    $response[$key]['statuses'][$index]['value'] = 'In Progress';
                }
            }

            $response[$key]['sr_types'] = self::SR_TYPES;
            $response[$key]['sr_issues'] = $issuesArray;
            //$response[$key]['currency'][0] = $currencyArray;
        } else {
            $response[$key]['status'][0] = 0;
            $response[$key]['message'][0] = __('No Service Request Available');
        }

        return $response;
    }

    /**
     * Customer Service Request Detail By Id
     * @param int $customerId
     * @param int $srid
     * @return mixed
     */
    public function requestDetailsById($customerId, $srid) {
        $response = [];
        $key = 0;
        $data = [];

        $serviceCollection = $this->_serviceFactory->create()->getCollection()
                ->addFieldToFilter('customer_id', ['eq' => $customerId])
                ->addFieldToFilter('id', ['eq' => $srid]);

        if (!empty($serviceCollection->getSize())) {
            $serviceModal = $this->_serviceFactory->create()->load($srid);
            $serviceModal = $serviceModal->getData();

            /* Get Issues List */
            $issuesCollection = $this->_serviceIssuesFactory->create()->getCollection();
            if (!empty($issuesCollection->getSize())) {
                foreach ($issuesCollection as $issue) {
                    $key = $issue->getId();
                    $issuesArray[$key] = $issue->getValue();
                }
            }
            /* Get currency Symbol and code */
            //$currencyArray['currency_symbol'] = $this->_commonHelper->getStoreCurrencySymbol();
            //$currencyArray['currency_code'] = $this->_commonHelper->getStoreCurrencyCode();

            $data['sr_id'] = $serviceModal['id'];
            $data['sr_id_str'] = str_pad((string) $serviceModal['id'], 10, '0', STR_PAD_LEFT);
            $data['sr_type'] = $serviceModal['service_request_type'];
            $data['sr_type_str'] = $this->getSrTypeString($serviceModal['service_request_type']);
            $data['issue'] = $serviceModal['issues_id'];
            $data['created_at'] = $serviceModal['created_at'];
            $data['closed_at'] = self::CONST_NULL;
            $jobClosedDate = "";

            if ($serviceModal['status'] == SR_STATUS_COMPLETED) {
                $jobNoModel = $this->_jobNoFactory->create()->getCollection()
                        ->addFieldToSelect('closed_at')
                        ->addFieldToFilter('srid', ['eq' => $serviceModal['id']]);

                foreach ($jobNoModel as $key => $job) {
                    $jobClosedDate = $job['closed_at'];
                }

                if (!$jobClosedDate) {
                    //throw new \Magento\Framework\Webapi\Exception(new Phrase('Closed date does not exist.'), 0, \Magento\Framework\Webapi\Exception::HTTP_INTERNAL_ERROR);
                }

                $data['closed_at'] = $jobClosedDate; //display from escorts_service_job_no
            }

            $data['accept_status'] = $serviceModal['accept_status'];
            $data['status'] = $serviceModal['status'];
            $data['status_str'] = $this->getSrStatusString($serviceModal['status']);

            $customerAaddress = "";
            $customer = $this->_customerFactory->create()->load($customerId);

            if ($customer) {
                $data['customer_name'] = $customer->getFirstname();
                $shippingAddressId = $customer->getDefaultShipping();
                $address = $this->_addressModel->load($shippingAddressId);

                if ($address) {
                    if (!empty($address->getStreet())) {
                        $customerAaddress = implode(" ", $address->getStreet());
                    }
                    if (!empty($address->getLandmark())) {
                        $customerAaddress = $customerAaddress . ',' . $address->getLandmark();
                    }
                    if (!empty($address->getVillage())) {
                        $customerAaddress = $customerAaddress . ',' . $address->getVillage();
                    }
                    if (!empty($address->getTehsil())) {
                        $customerAaddress = $customerAaddress . ',' . $address->getTehsil();
                    }
                    if (!empty($address->getCity())) {
                        $customerAaddress = $customerAaddress . ',' . $address->getCity();
                    }
                    if (!empty($address->getCountryId())) {
                        $addressCountry = $this->_countryFactory->create()->loadByCode($address->getCountryId())->getName();
                        $customerAaddress = $customerAaddress . ',' . $addressCountry;
                    }
                    if (!empty($address->getPostcode())) {
                        $customerAaddress = $customerAaddress . ',' . $address->getPostcode();
                    }
                }
                $data['customer_address'] = $customerAaddress;
            }

            $data['amount'] = "0.00";
            $data['feedback_status'] = $serviceModal['feedback_status'];
            $data['rating'] = '';

            /* Load service request list */
            if ($serviceModal['feedback_status']) {
                if ($this->_commonHelper->getServiceDealerRating($serviceModal['assigned_to'])) {
                    $rating = $this->_commonHelper->getServiceDealerRating($serviceModal['assigned_to']);
                    $data['rating'] = $rating;
                }
            }

            $serviceDealerCustomer = $this->_customerFactory->create()->load($serviceModal['assigned_to']);
            if ($serviceDealerCustomer) {
                $data['sd_id'] = $serviceModal['assigned_to'];
                $data['sd_name'] = $serviceDealerCustomer->getFirstname() . ' ' . $serviceDealerCustomer->getLastname();
            }

            $profileImage = $customer->getResource()->getAttribute('profile_picture')->getFrontend()->getValue($serviceDealerCustomer);

            if ($profileImage) {
                $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
                        ->getStore()
                        ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
                $path = $media_dir . 'customer' . $profileImage;
                $data['sd_image'] = $path;
            }

            $data['feedback_comment'] = $serviceModal['feedback_comment'];
            $response[$key]['status'] = 1;
            $response[$key]['message'] = __('Service request details');
            $response[$key]['sr_details'] = $data;
            $response[$key]['statuses'] = $this->_serviceStatusesFactory->create()
                    ->getCollection()
                    ->addFieldToFilter('status_id', ['neq' => -1])
                    ->getData();

            $response[$key]['sr_types'] = self::SR_TYPES;
            $response[$key]['sr_issues'] = $issuesArray;
            //$response[$key]['currency'] = $currencyArray;
        } else {
            $response[$key]['status'] = 0;
            $response[$key]['message'] = __('No record exist for service request id');
        }

        return $response;
    }

    /**
     * View Service Dealer Profile For Customer Mobile Application
     * @param int $customerId
     * @param int $sdid
     * @return mixed
     * @throws \Magento\Framework\Webapi\Exception
     */
    public function viewDealerProfile($customerId, $sdid) {

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }

        $response = [];
        $key = 0;

        $customer = $this->_customerFactory->create()->load($sdid);

        if ($customer) {
            $response[$key]['status'] = 1;
            $response[$key]['message'] = __('Service Dealer Profile');
            $response[$key]['sd_id'] = $sdid;
            $customerFullName = $customer->getFirstname() . ' ' . $customer->getLastname();
            $response[$key]['sd_name'] = $customerFullName;
            $response[$key]['sd_image'] = "";
            $profileImage = $customer->getResource()->getAttribute('profile_picture')->getFrontend()->getValue($customer);

            if ($profileImage) {
                $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
                        ->getStore()
                        ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

                $path = $media_dir . 'customer' . $profileImage;
                $response[$key]['sd_image'] = $path;
            }

            if ($this->_commonHelper->getServiceDealerRating($sdid)) {
                $rating = $this->_commonHelper->getServiceDealerRating($sdid);
                $response[$key]['rating'] = $rating;
            } else {
                $response[$key]['rating'] = '';
            }

            if ($customer->getCreatedAt()) {
                $customerCreatedDate = $customer->getCreatedAt();
                $currentDate = $this->_timezone->date()->format('Y-m-d H:i:s');
                $dateDiff = abs(strtotime($currentDate) - strtotime($customerCreatedDate));
                $years = floor($dateDiff / (365 * 60 * 60 * 24));
                $months = round(ceil(($dateDiff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24)));
                $response[$key]['duration_yr'] = $years;
                $response[$key]['duration_month'] = $months;
            }

            $customerExpertise = $customer->getResource()->getAttribute('expertise_models')->getFrontend()->getValue($customer);
            if ($customerExpertise) {
                $customerExpertise = explode(',', $customerExpertise);

                $_expertise = [];
                $k = 0;
                foreach ($customerExpertise as $x => $expertise) {
                    $_expertise[$k] = ['id' => $x, 'sd_speciality' => $expertise];
                    $k++;
                }

                $response[$key]['specialization'] = $_expertise;
            } else {
                $response[$key]['specialization'] = "";
            }

            $shippingAddressId = $customer->getDefaultShipping();

            if ($shippingAddressId) {
                $address = $this->_addressModel->load($shippingAddressId);
                if ($address) {
                    if (!empty($address->getCity())) {
                        $response[$key]['district'] = $address->getCity();
                    }

                    if (!empty($address->getRegion())) {
                        $response[$key]['state'] = $address->getRegion();
                    }

                    if (!empty($address->getPostcode())) {
                        $response[$key]['post_code'] = $address->getPostcode();
                    }
                }
            }

            $response[$key]['compliment'] = __('');
        } else {
            $response[$key]['status'] = 0;
            $response[$key]['message'] = __('Service Dealer profile does not exist');
        }
        return $response;
    }

    /**
     * Add Customer feedback and invoice for Service Request
     * @param int $customerId
     * @param int $srid
     * @param mixed $rating
     * @param string $comment
     * @return mixed
     */
    public function addServiceRequestFeedback($customerId, $srid, $rating, $comment) {
        $key = 0;
        $response[$key]['status'] = 0;
        $response[$key]['message'] = __('Something went wrong');

        if (empty($srid)) {
            return $response;
        }

        if (empty($rating)) {
            return $response;
        }

        if (empty($comment)) {
            return $response;
        }

        $serviceModal = $this->_serviceFactory->create()
                ->getCollection()
                ->addFieldToFilter('customer_id', ['eq' => $customerId])
                ->addFieldToFilter('id', ['eq' => $srid]);

        if (!empty($serviceModal->getSize())) {
            $serviceCollection = $this->_serviceFactory->create()->load($srid);


            /* echo "<pre>"; print_r($serviceCollection->getData()); echo "</pre>"; die(); */

            if ($serviceCollection->getStatus() == SR_STATUS_COMPLETED) {
                $feedbackStatus = $serviceCollection['feedback_status'];

                if (empty($feedbackStatus)) {
                    $serviceCollection->setData('feedback_status', 1);
                    $serviceCollection->setData('feedback_rating', $rating);
                    $serviceCollection->setData('feedback_comment', $comment);
                    $currentDate = $this->_timezone->date()->format('Y-m-d H:i:s');
                    $serviceCollection->setData('feedback_at', $currentDate);
                    try {
                        /* save feedback */
                        $serviceCollection->save();

                        /* save feedback invoice */
                        $jobNoModel = $this->_jobNoFactory->create()->load($srid, 'srid');
                        if (!empty($jobNoModel)) {
                            $jobNo = $jobNoModel->getId();
                            $_feedbackInvoiceModel = $this->_serviceFeedbackInvoiceFactory->create()
                                    ->getCollection()
                                    ->addFieldToFilter('job_no', $jobNo);

                            if (empty($_feedbackInvoiceModel->getSize())) {
                                $_feedbackInvoiceCollection = $this->_serviceFeedbackInvoiceFactory->create();
                                /* Rating must be 3,4,5 for feedback invoice entry */
                                //$amountArray = ['3' => 300, '4' => 400, '5' => 500];
                                $amountArray = ['4' => 400, '5' => 500];
                                $rating = round($rating);
                                $ratingIndex = (int) $rating;

                                if (array_key_exists($ratingIndex, $amountArray)) {
                                    $data['job_no'] = 1;
                                    $data['amount'] = $amountArray[$rating];
                                    $data['is_paid'] = 0;
                                    $_feedbackInvoiceCollection->setData($data);
                                    $_feedbackInvoiceCollection->save();
                                }
                            }
                        }

                        $fourRateAmount = $this->_scopeConfig->getValue(self::XML_FOUR_RATING_AMOUNT, \Magento\Store\Model\ScopeInterface::SCOPE_STORES);
                        $fiveRateAmount = $this->_scopeConfig->getValue(self::XML_FIVE_RATING_AMOUNT, \Magento\Store\Model\ScopeInterface::SCOPE_STORES);

                        /* Send SMS to SD */
                        if ($serviceCollection->getAssignedTo()) {
                            $sdMobile = $this->_commonHelper->getCustomerMobileByID($serviceCollection->getAssignedTo());
                            if (!empty($sdMobile)) {
                                if ($rating >= 4) {
                                    if ($rating == 4) {
                                        $amounts = $fourRateAmount;
                                    } elseif ($rating == 5) {
                                        $amounts = $fiveRateAmount;
                                    }
                                    $params = ['rating' => $rating, 'srid' => '#' . str_pad($srid, 10, '0', STR_PAD_LEFT), 'amount' => $amounts];
                                    $this->_smsHelper->serviceRateSdGoodNotification($sdMobile, $params);
                                } elseif ($rating <= 3) {
                                    $params = ['rating' => $rating, 'srid' => '#' . str_pad($srid, 10, '0', STR_PAD_LEFT)];
                                    $this->_smsHelper->serviceRateSdBadNotification($sdMobile, $params);
                                }
                            }
                        }

                        /* Send SMS to PO */
                        if ($serviceCollection->getAssignedPo()) {
                            $poMobile = $this->_commonHelper->getCustomerMobileByID($serviceCollection->getAssignedPo());
                            if (!empty($poMobile)) {
                                if ($rating >= 4) {
                                    if ($rating == 4) {
                                        $amounts = $fourRateAmount;
                                    } elseif ($rating == 5) {
                                        $amounts = $fiveRateAmount;
                                    }
                                    $params = ['rating' => $rating, 'srid' => '#' . str_pad($srid, 10, '0', STR_PAD_LEFT), 'amount' => $amounts];
                                    $this->_smsHelper->serviceRatePoGoodNotification($poMobile, $params);
                                } elseif ($rating <= 3) {
                                    $params = ['rating' => $rating, 'srid' => '#' . str_pad($srid, 10, '0', STR_PAD_LEFT)];
                                    $this->_smsHelper->serviceRatePoBadNotification($poMobile, $params);
                                }
                            }
                        }

                        /* Service Request Feedback Email to Admin */
                        $tractorModelName = "";
                        $tractorName = "";

                        $tractorId = $serviceCollection['tractor_id'];
                        $tractorModel = $this->_customerTractorFactory->create()->load($tractorId);

                        if ($tractorModel->gettractorId()) {
                            $makeId = $tractorModel->getMakeId();
                            $modelId = $tractorModel->getModelId();
                            $tractorModelName = $this->_commonHelper->getTractorModelName($modelId);
                            $tractorName = $this->_commonHelper->getTractorNameByTractorId($tractorId);
                        }

                        $customerMobile = $this->_commonHelper->getCustomerMobileByID($customerId);
                        $customerName = $this->_commonHelper->getCustomerNameById($customerId);
                        $dealerId = $serviceCollection['assigned_to'];
                        $serviceDealerName = $this->_commonHelper->getCustomerNameById($dealerId) . ' (' . $this->_commonHelper->getCustomerVendorCodeById($dealerId) . ')';
                        $customerAddress = $serviceCollection['address'];
                        $sridValue = str_pad((string) $srid, 10, '0', STR_PAD_LEFT);
                        $jobNoValue = str_pad((string) $jobNo, 10, '0', STR_PAD_LEFT);

                        $parameters = [
                            'sr_id' => '#' . $sridValue,
                            'job_no' => '#' . $jobNoValue,
                            'feedback_rating' => $rating,
                            'feedback_comment' => $comment,
                            'tractor_model' => $tractorModelName,
                            'tractor_name' => $tractorName,
                            'customer_name' => $customerName,
                            'mobile' => $customerMobile,
                            'customer_address' => $customerAddress,
                            'service_dealer_name' => $serviceDealerName,
                            'subject' => 'Service Request #' . $sridValue . '- Feedback'
                        ];
                        $this->customEmailsHelper->sendFeedbackNotification($parameters);
                        /* Service Request Feedback Email to Admin */

                        $response[$key]['status'] = 1;
                        $response[$key]['message'] = __('Feedback submitted');
                    } catch (\Exception $e) {
                        // echo "===>".$e->getMessage();
                        $this->messageManager->addException($e, __('Something went wrong while adding the feedback'));
                    }
                } else {
                    $response[$key]['message'] = __('Feedback already submitted');
                }
            }
        }

        return $response;
    }

    /**
     * Get All Tractor Makes List
     * @return mixed
     */
    public function getAllMake() {
        try {
            if ($data = $this->_commonHelper->getMakeMaster()) {
                $response[0]['status'] = 1;
                $response[0]['message'] = __('Tractor Brands found');
                $response[0]['make_master'] = $data;
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('Tractor Brands not found');
            }

            return $response;
        } catch (\Exception $e) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __($e->getMessage());
            return $response;
        }
    }

    /**
     * Get Customer Tractors list to create Door Step Service
     * @param int $customerId
     * @return mixed
     */
    public function getCustomerTractors($customerId) {
        try {
            $customerTractorCollection = $this->_customerTractorFactory->create()
                    ->getCollection()
                    ->addFieldToFilter('customer_id', ['eq' => $customerId])
                    ->addFieldToFilter('status', ['eq' => 1]);

            if ($customerTractorCollection->getSize()) {
                $response[0]['status'] = 1;
                $response[0]['message'] = __('Customer Tractor list');
                $i = 0;
                foreach ($customerTractorCollection as $_collection) {
                    // $makeName = $this->_makeMasterFactory->create()->load($_collection->getMakeId())->getMakeName();
                    // $modelName = $this->_modelMasterFactory->create()->load($_collection->getModelId())->getModelName();
                    $name = $this->_commonHelper->getTractorName($_collection->getMakeId(), $_collection->getModelId());

                    $response[0]['tractors'][$i]['tractor_id'] = $_collection->getTractorId();
                    // $response[0]['tractors'][$i]['tractor_name'] = $makeName . ' - ' . $modelName;
                    $response[0]['tractors'][$i]['tractor_name'] = $name;

                    if ($_collection->getSerialNumber()) {
                        $response[0]['tractors'][$i]['serial_number'] = $_collection->getSerialNumber();
                    } else {
                        $response[0]['tractors'][$i]['serial_number'] = null;
                    }

                    $response[0]['tractors'][$i]['brand'] = $this->_commonHelper->getTractorBrandName($_collection->getMakeId());
                    $response[0]['tractors'][$i]['make_id'] = $_collection->getMakeId();
                    $response[0]['tractors'][$i]['model_id'] = $_collection->getModelId();
                    $response[0]['tractors'][$i]['year_of_purchase'] = $_collection->getManufacturingYear();
                    $response[0]['tractors'][$i]['registration_no'] = $_collection->getRegistrationNo();

                    $i++;
                }
            } else {
                $response[0]['status'] = 1;
                $response[0]['message'] = __('Customer Tractor list not found');
            }

            $response[0]['make_master'] = $this->_commonHelper->getMakeMaster();

            $customer = $this->_customerFactory->create()->load($customerId);
            if ($customer->getAddresses()) {
                $customerAddress = [];
                foreach ($customer->getAddresses() as $address) {
                    $customerAddress[] = $address->toArray();
                }
                if ($customerAddress) {
                    $j = 0;
                    foreach ($customerAddress as $customerAddres) {
                        if (!empty($customerAddres['street'])) {
                            $_customerAddress = $customerAddres['street'];
                        }
                        if (!empty($customerAddres['landmark'])) {
                            $_customerAddress = $_customerAddress . ', ' . $customerAddres['landmark'];
                        }
                        if (!empty($customerAddres['village'])) {
                            $_customerAddress = $_customerAddress . ', ' . $customerAddres['village'];
                        }
                        if (!empty($customerAddres['tehsil'])) {
                            $_customerAddress = $_customerAddress . ', ' . $customerAddres['tehsil'];
                        }
                        if (!empty($customerAddres['city'])) {
                            $_customerAddress = $_customerAddress . ', ' . $customerAddres['city'];
                        }
                        if (!empty($customerAddres['region'])) {
                            $_customerAddress = $_customerAddress . ', ' . $customerAddres['region'];
                        }
                        if (!empty($customerAddres['country_id'])) {
                            $_customerAddress = $_customerAddress . ', ' . $this->_countryFactory->create()->loadByCode($customerAddres['country_id'])->getName() . '(' . $customerAddres['country_id'] . ')';
                        }
                        if (!empty($customerAddres['postcode'])) {
                            $_customerAddress = $_customerAddress . ', ' . $customerAddres['postcode'];
                        }

                        $baseUrl = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
                                ->getStore()
                                ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_WEB);

                        $response[0]['address'][$j]['status'] = 1;
                        $response[0]['address'][$j]['customer_name'] = $customer->getName();
                        $response[0]['address'][$j]['id'] = $customerAddres['entity_id'];
                        $response[0]['address'][$j]['edit_url'] = $baseUrl . 'customer/address/edit/id/' . $customerAddres['entity_id'];
                        $response[0]['address'][$j]['new_url'] = $baseUrl . 'customer/address/new';
                        $response[0]['address'][$j]['address_string'] = $_customerAddress;
                        $j++;
                    }
                }
            } else {
                $response[0]['address'][0]['status'] = 0;
                $response[0]['address'][0]['message'] = __('We don\'t find any address. Please update your Address first, if you want to create service request');
            }

            return $response;
        } catch (\Exception $e) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Something went wrong');
            return $response;
        }
    }

    /**
     * Get Tractor Models list by Make Id
     * @param int $makeId
     * @return mixed
     */
    public function getModelByMakeId($makeId) {
        try {
            $modelMasterColletion = $this->_modelMasterFactory->create()->getCollection();
            $modelMasterColletion->addFieldToSelect(['model_master_id', 'model_name'])
                    ->addFieldToFilter('make_master_id', ['eq' => $makeId]);
            if ($modelMasterColletion->getSize()) {
                $response[0]['status'] = 1;
                $response[0]['message'] = __('Model Master list found');
                $i = 0;
                foreach ($modelMasterColletion as $collection) {
                    $response[0]['model_master'][$i]['model_master_id'] = $collection->getModelMasterId();
                    $response[0]['model_master'][$i]['model_name'] = $collection->getModelName();
                    $i++;
                }
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('No Model found');
            }

            return $response;
        } catch (\Exception $e) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Something went wrong');
            return $response;
        }
    }

    /**
     * Create Door Step Service Request
     * @param int $customerId
     * @param mixed $serviceRequest
     * @return mixed
     */
    public function createServiceRequest($customerId, $serviceRequest) {
        try {
            $customerAddress = '';
            if (!empty($serviceRequest['address_id'])) {
                $address = $this->_addressModel->load($serviceRequest['address_id']);

                if ($address) {
                    if (!empty($address->getStreet())) {
                        $customerAddress .= implode(' ', $address->getStreet());
                    }
                    if (!empty($address->getLandmark())) {
                        $customerAddress .= ', ' . $address->getLandmark();
                    }
                    if (!empty($address->getVillage())) {
                        $customerAddress .= ', ' . $address->getVillage();
                    }
                    if (!empty($address->getTehsil())) {
                        $customerAddress .= ', ' . $address->getTehsil();
                    }
                    if (!empty($address->getCity())) {
                        $customerAddress .= ', ' . $address->getCity();
                    }
                    if (!empty($address->getRegion())) {
                        $customerAddress .= ', ' . $address->getRegion();
                    }
                    if (!empty($address->getCountryId())) {
                        $customerAddress .= ', ' . $this->_countryFactory->create()->loadByCode($address->getCountryId())->getName() . '(' . $address->getCountryId() . ')';
                    }
                    if (!empty($address->getPostcode())) {
                        $customerAddress .= ', ' . $address->getPostcode();
                    }
                }
            }

            if (!isset($serviceRequest['tractor_id'])) {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('Please add a new tractor');
                return $response;
            } else {
                $customerName = $this->_commonHelper->getCustomerNameById($customerId);
                //$customerAddress = $this->getCustomerAddressByCustomerId($customerId);
                $customerMobile = $this->_commonHelper->getCustomerMobileByID($customerId);

                // $delivery_date = $serviceRequest['year_of_purchase'].'-01-01 00:00:00';
                if ($serviceRequest['tractor_id'] == '' &&
                        !empty($serviceRequest['make_id']) &&
                        !empty($serviceRequest['model_id']) &&
                        !empty($serviceRequest['year_of_purchase']) &&
                        //!empty($serviceRequest['serial_number']) &&
                        !empty($serviceRequest['registration_no']) &&
                        !empty($serviceRequest['address_id'])
                ) {
                    $delivery_date = $serviceRequest['year_of_purchase'] . '-01-01 00:00:00';
                    //$tractorId = $this->saveCustomerTractor($customerId, $serviceRequest['make_id'], $serviceRequest['model_id'], $serviceRequest['serial_number'], $serviceRequest['registration_no'], $serviceRequest['year_of_purchase'], $delivery_date);
                    $tractorId = $this->saveCustomerTractor($customerId, $serviceRequest['make_id'], $serviceRequest['model_id'], $serviceRequest['registration_no'], $serviceRequest['year_of_purchase'], $delivery_date);

                    if ($tractorId) {
                        $serviceRequestCollection = $this->checkServiceRequestByCurrentDate($tractorId);

                        if (!$serviceRequestCollection->getSize()) {
                            $postcode = $this->_commonHelper->getPostcodeByAddressId($serviceRequest['address_id']);
                            $serviceDealer = $this->_commonHelper->getBlockServiceDealer($postcode);
                            $projectOfficer = $this->_commonHelper->getBlockProjectOfficer($postcode);

                            if ($projectOfficer) {
                                $po = $projectOfficer['id'];
                                $poMobile = $projectOfficer['mobile_number'];
                            } else {
                                $po = 0;
                            }

                            $service_no = $this->getServiceNumber($tractorId);

                            if ($serviceDealer) {
                                $sdName = $this->_commonHelper->getCustomerNameById($serviceDealer);
                                $comment = NULL;

                                if (!empty($serviceRequest['comment'])) {
                                    $comment = $serviceRequest['comment'];
                                }

                                $data = [
                                    'tractor_id' => $tractorId,
                                    'customer_id' => $customerId,
                                    'address_id' => $serviceRequest['address_id'],
                                    'address' => $customerAddress,
                                    'service_request_type' => SR_TYPE_REPAIR,
                                    'assigned_to' => $serviceDealer,
                                    'assigned_po' => $po,
                                    'is_free_service' => 0,
                                    'service_no' => $service_no,
                                    'created_at' => $this->_timezone->date()->format('Y-m-d H:i:s'),
                                    'status' => SR_STATUS_PENDING,
                                    'customer_comment' => $comment
                                ];
                                $_serviceRequest = $this->_serviceFactory->create();
                                $_serviceRequest->setData($data);
                                $_serviceRequest->save();

                                // Customer Service Request Notification
                                $tractorName = $this->_commonHelper->getTractorNameByTractorId($tractorId);
                                $params = [
                                    'name' => $customerName,
                                    'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                    'tractor_name' => $tractorName
                                ];
                                $this->_smsHelper->sendSrSmsToCust($customerMobile, $params);

                                // SD Service Request Notification
                                $params = [
                                    'name' => $sdName,
                                    'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                    'customer_name' => $customerName,
                                    'cusomer_mobile' => $customerMobile,
                                    'cusotomer_address' => $customerAddress,
                                    'tractor_name' => $tractorName
                                ];
                                $sdMobile = $this->_commonHelper->getCustomerMobileByID($serviceDealer);
                                //$sdMobile = '8630233796';
                                $this->_smsHelper->sendNewSrSmsToEtc($sdMobile, $params);

                                // PO Service Request Notification
                                if ($projectOfficer) {
                                    $po = $projectOfficer['id'];
                                    $poMobile = $projectOfficer['mobile_number'];
                                    //$poMobile = '8630233796';
                                    $params = [
                                        'name' => $projectOfficer['name'],
                                        'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                        'customer_name' => $customerName,
                                        'cusomer_mobile' => $customerMobile,
                                        'cusotomer_address' => $customerAddress,
                                        'tractor_name' => $tractorName
                                    ];
                                    $this->_smsHelper->sendNewSrSmsToEtc($poMobile, $params);
                                }

                                /* Service Request Email to Admin */
                                $parameters = [
                                    'customer_name' => $customerName,
                                    'mobile' => $customerMobile,
                                    'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                    'customer_address' => $customerAddress,
                                    'tractor_name' => $tractorName,
                                    'subject' => 'Service Request - Create'
                                ];
                                $this->customEmailsHelper->sendServiceRequestNotification($parameters);
                                /* Service Request Email to Admin */

                                $response[0]['status'] = 1;
                                $response[0]['message'] = __('Service Request created successfully');
                                return $response;
                            } else {
                                $tractorName = $this->_commonHelper->getTractorNameByTractorId($tractorId);
                                $parameters = [
                                    'customer_name' => $customerName,
                                    'mobile' => $customerMobile,
                                    'customer_address' => $customerAddress,
                                    'tractor_name' => $tractorName,
                                    'date_time' => $this->_timezone->date()->format('Y-m-d H:i:s'),
                                    'subject' => 'Service Request - No Service Dealer Available'
                                ];
                                $this->customEmailsHelper->sendNoSdFoundOnServiceRequestCreate($parameters);

                                $response[0]['status'] = 0;
                                $response[0]['message'] = __('Sorry, we couldn\'t find any Service dealer in your area. Your request has been shared with our agent, we will get back to you soon.');
                                return $response;
                            }
                        } else {
                            $response[0]['status'] = 0;
                            $response[0]['message'] = __('You can\'t create more than one Service Request for same Tractor with in a single day');
                            return $response;
                        }
                    } else {
                        $response[0]['status'] = 0;
                        $response[0]['message'] = __('Serial Number already exist');
                        return $response;
                    }
                } elseif ($serviceRequest['tractor_id'] == '' &&
                        !empty($serviceRequest['make_id']) &&
                        !empty($serviceRequest['model_id']) &&
                        !empty($serviceRequest['year_of_purchase']) &&
                        //!empty($serviceRequest['serial_number']) &&
                        !empty($serviceRequest['lat']) &&
                        !empty($serviceRequest['long'])
                ) {
                    $lat = $serviceRequest['lat'];
                    $long = $serviceRequest['long'];
                    $delivery_date = $serviceRequest['year_of_purchase'] . '-01-01 00:00:00';
                    //$tractorId = $this->saveCustomerTractor($customerId, $serviceRequest['make_id'], $serviceRequest['model_id'], $serviceRequest['serial_number'], $serviceRequest['registration_no'], $serviceRequest['year_of_purchase'], $delivery_date);
                    $tractorId = $this->saveCustomerTractor($customerId, $serviceRequest['make_id'], $serviceRequest['model_id'], $serviceRequest['registration_no'], $serviceRequest['year_of_purchase'], $delivery_date);

                    if ($tractorId) {
                        $serviceRequestCollection = $this->checkServiceRequestByCurrentDate($tractorId);

                        if (!$serviceRequestCollection->getSize()) {
                            $postcode = $this->_commonHelper->getPostCodeByLatLong($lat, $long);
                            $serviceDealer = $this->_commonHelper->getBlockServiceDealer($postcode);
                            $projectOfficer = $this->_commonHelper->getBlockProjectOfficer($postcode);

                            if ($projectOfficer) {
                                $po = $projectOfficer['id'];
                                $poMobile = $projectOfficer['mobile_number'];
                            } else {
                                $po = 0;
                            }

                            $service_no = $this->getServiceNumber($tractorId);

                            if ($serviceDealer) {
                                $sdName = $this->_commonHelper->getCustomerNameById($serviceDealer);
                                $comment = NULL;
                                if (!empty($serviceRequest['comment'])) {
                                    $comment = $serviceRequest['comment'];
                                }
                                $data = [
                                    'tractor_id' => $tractorId,
                                    'customer_id' => $customerId,
                                    'address_id' => $serviceRequest['address_id'],
                                    'address' => $customerAddress,
                                    'lat' => $lat,
                                    'long' => $long,
                                    'service_request_type' => SR_TYPE_REPAIR,
                                    'assigned_to' => $serviceDealer,
                                    'assigned_po' => $po,
                                    'is_free_service' => 0,
                                    'service_no' => $service_no,
                                    'created_at' => $this->_timezone->date()->format('Y-m-d H:i:s'),
                                    'status' => SR_STATUS_PENDING,
                                    'customer_comment' => $comment
                                ];
                                $_serviceRequest = $this->_serviceFactory->create();
                                $_serviceRequest->setData($data);
                                $_serviceRequest->save();

                                // Customer Service Request Notification
                                $tractorName = $this->_commonHelper->getTractorNameByTractorId($tractorId);
                                $params = [
                                    'name' => $customerName,
                                    'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                    'tractor_name' => $tractorName
                                ];
                                $this->_smsHelper->sendSrSmsToCust($customerMobile, $params);

                                // SD Service Request Notification
                                $params = [
                                    'name' => $sdName,
                                    'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                    'customer_name' => $customerName,
                                    'cusomer_mobile' => $customerMobile,
                                    'cusotomer_address' => $customerAddress,
                                    'tractor_name' => $tractorName
                                ];
                                $sdMobile = $this->_commonHelper->getCustomerMobileByID($serviceDealer);
                                //$sdMobile = '8630233796';
                                $this->_smsHelper->sendNewSrSmsToEtc($sdMobile, $params);

                                // PO Service Request Notification
                                if ($projectOfficer) {
                                    $po = $projectOfficer['id'];
                                    $poMobile = $projectOfficer['mobile_number'];
                                    //$poMobile = '8630233796';
                                    $params = [
                                        'name' => $projectOfficer['name'],
                                        'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                        'customer_name' => $customerName,
                                        'cusomer_mobile' => $customerMobile,
                                        'cusotomer_address' => $customerAddress,
                                        'tractor_name' => $tractorName
                                    ];
                                    $this->_smsHelper->sendNewSrSmsToEtc($poMobile, $params);
                                }

                                /* Service Request Email to Admin */
                                $parameters = [
                                    'customer_name' => $customerName,
                                    'mobile' => $customerMobile,
                                    'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                    'customer_address' => $customerAddress,
                                    'tractor_name' => $tractorName,
                                    'subject' => 'Service Request - Create'
                                ];
                                $this->customEmailsHelper->sendServiceRequestNotification($parameters);
                                /* Service Request Email to Admin */

                                $response[0]['status'] = 1;
                                $response[0]['message'] = __('Service Request created successfully');
                                return $response;
                            } else {
                                $tractorName = $this->_commonHelper->getTractorNameByTractorId($tractorId);
                                $parameters = [
                                    'customer_name' => $customerName,
                                    'mobile' => $customerMobile,
                                    'customer_address' => $customerAddress,
                                    'tractor_name' => $tractorName,
                                    'date_time' => $this->_timezone->date()->format('Y-m-d H:i:s'),
                                    'subject' => 'Service Request - No Service Dealer Available'
                                ];
                                $this->customEmailsHelper->sendNoSdFoundOnServiceRequestCreate($parameters);

                                $response[0]['status'] = 0;
                                $response[0]['message'] = __('Sorry, we couldn\'t find any Service dealer in your area. Your request has been shared with our agent, we will get back to you soon.');
                                return $response;
                            }
                        } else {
                            $response[0]['status'] = 0;
                            $response[0]['message'] = __('You can\'t create more than one Service Request for same Tractor with in a single day');
                            return $response;
                        }
                    } else {
                        $response[0]['status'] = 0;
                        $response[0]['message'] = __('Serial Number already exists');
                        return $response;
                    }
                } elseif (!empty($serviceRequest['tractor_id']) &&
                        !empty($serviceRequest['address_id'])) {
                    $tractorId = $serviceRequest['tractor_id'];
                    if ($tractorId) {
                        $serviceRequestCollection = $this->checkServiceRequestByCurrentDate($tractorId);

                        if (!$serviceRequestCollection->getSize()) {
                            $postcode = $this->_commonHelper->getPostcodeByAddressId($serviceRequest['address_id']);
                            $serviceDealer = $this->_commonHelper->getBlockServiceDealer($postcode);
                            $projectOfficer = $this->_commonHelper->getBlockProjectOfficer($postcode);
                            if ($projectOfficer) {
                                $po = $projectOfficer['id'];
                                $poMobile = $projectOfficer['mobile_number'];
                            } else {
                                $po = 0;
                            }

                            $customerTractorModel = $this->_customerTractorFactory->create()->load($tractorId);

                            if (!empty($customerTractorModel->getOrderId()) && !empty($customerTractorModel->getOrderItemId())) {
                                $serviceNo = $this->getServiceNumberIfOrderExist($customerTractorModel);
                                if ($serviceNo) {
                                    // "<pre>>>>>"; print_r($serviceNo); echo "</pre>";
                                    $service_no = $serviceNo;
                                    $is_free_service = 1;
                                    $service_request_type = SR_TYPE_ROUTINE;
                                } else {
                                    $serviceReqColl = $this->_serviceFactory->create()->getCollection();
                                    $serviceReqColl->addFieldToFilter('tractor_id', ['eq' => $tractorId]);
                                    $serviceReqColl->setOrder('id')->setPageSize(1);

                                    if ($serviceReqColl->getSize() > 0) {
                                        $tractor = $serviceReqColl->getLastItem();
                                        $service_no = $tractor->getServiceNo() + 1;
                                        $is_free_service = 0;
                                        $service_request_type = SR_TYPE_REPAIR;
                                    } else {
                                        $service_no = 1;
                                        $is_free_service = 0;
                                        $service_request_type = SR_TYPE_REPAIR;
                                    }
                                }
                            } else {
                                $service_no = $this->getServiceNumber($tractorId);
                                $service_request_type = SR_TYPE_REPAIR;
                                $is_free_service = 0;
                            }

                            if ($serviceDealer) {
                                $sdName = $this->_commonHelper->getCustomerNameById($serviceDealer);
                                $comment = NULL;
                                if (!empty($serviceRequest['comment'])) {
                                    $comment = $serviceRequest['comment'];
                                }

                                $data = [
                                    'tractor_id' => $tractorId,
                                    'customer_id' => $customerId,
                                    'address_id' => $serviceRequest['address_id'],
                                    'address' => $customerAddress,
                                    'service_request_type' => $service_request_type,
                                    'assigned_to' => $serviceDealer,
                                    'assigned_po' => $po,
                                    'is_free_service' => $is_free_service,
                                    'service_no' => $service_no,
                                    'created_at' => $this->_timezone->date()->format('Y-m-d H:i:s'),
                                    'status' => SR_STATUS_PENDING,
                                    'customer_comment' => $comment
                                ];

                                // echo "<pre>"; print_r($data); echo "</pre>"; exit();
                                $_serviceRequest = $this->_serviceFactory->create();
                                $_serviceRequest->setData($data);
                                $_serviceRequest->save();

                                // Customer Service Request Notification
                                $tractorName = $this->_commonHelper->getTractorNameByTractorId($tractorId);
                                $params = [
                                    'name' => $customerName,
                                    'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                    'tractor_name' => $tractorName
                                ];
                                $this->_smsHelper->sendSrSmsToCust($customerMobile, $params);

                                // SD Service Request Notification
                                $params = [
                                    'name' => $sdName,
                                    'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                    'customer_name' => $customerName,
                                    'cusomer_mobile' => $customerMobile,
                                    'cusotomer_address' => $customerAddress,
                                    'tractor_name' => $tractorName
                                ];
                                $sdMobile = $this->_commonHelper->getCustomerMobileByID($serviceDealer);
                                //$sdMobile = '8630233796';
                                $this->_smsHelper->sendNewSrSmsToEtc($sdMobile, $params);

                                // PO Service Request Notification
                                if ($projectOfficer) {
                                    $po = $projectOfficer['id'];
                                    $poMobile = $projectOfficer['mobile_number'];
                                    //$poMobile = '8630233796';
                                    $params = [
                                        'name' => $projectOfficer['name'],
                                        'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                        'customer_name' => $customerName,
                                        'cusomer_mobile' => $customerMobile,
                                        'cusotomer_address' => $customerAddress,
                                        'tractor_name' => $tractorName
                                    ];
                                    $this->_smsHelper->sendNewSrSmsToEtc($poMobile, $params);
                                }

                                /*                                 * ***  Service Request Email to Admin  **** */
                                $parameters = [
                                    'customer_name' => $customerName,
                                    'mobile' => $customerMobile,
                                    'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                    'customer_address' => $customerAddress,
                                    'tractor_name' => $tractorName,
                                    'subject' => 'Service Request - Create'
                                ];
                                $this->customEmailsHelper->sendServiceRequestNotification($parameters);
                                /*                                 * ***  Service Request Email to Admin  **** */

                                $response[0]['status'] = 1;
                                $response[0]['message'] = __('Service Request created successfully');
                                return $response;
                            } else {
                                $tractorName = $this->_commonHelper->getTractorNameByTractorId($tractorId);
                                $parameters = [
                                    'customer_name' => $customerName,
                                    'mobile' => $customerMobile,
                                    'customer_address' => $customerAddress,
                                    'tractor_name' => $tractorName,
                                    'date_time' => $this->_timezone->date()->format('Y-m-d H:i:s'),
                                    'subject' => 'Service Request - No Service Dealer Available'
                                ];
                                $this->customEmailsHelper->sendNoSdFoundOnServiceRequestCreate($parameters);

                                $response[0]['status'] = 0;
                                $response[0]['message'] = __('Sorry, we couldn\'t find any Service dealer in your area. Your request has been shared with our agent, we will get back to you soon.');
                                return $response;
                            }
                        } else {
                            $response[0]['status'] = 0;
                            $response[0]['message'] = __('You can\'t create more than one Service Request for same Tractor with in a single day');
                            return $response;
                        }
                    }
                } elseif (!empty($serviceRequest['tractor_id']) &&
                        !empty($serviceRequest['lat']) &&
                        !empty($serviceRequest['long'])
                ) {
                    $lat = $serviceRequest['lat'];
                    $long = $serviceRequest['long'];
                    $tractorId = $serviceRequest['tractor_id'];

                    if ($tractorId) {
                        $serviceRequestCollection = $this->checkServiceRequestByCurrentDate($tractorId);
                        if (!$serviceRequestCollection->getSize()) {
                            $postcode = $this->_commonHelper->getPostCodeByLatLong($lat, $long);
                            // $postcode = '123456';
                            $serviceDealer = $this->_commonHelper->getBlockServiceDealer($postcode);
                            $projectOfficer = $this->_commonHelper->getBlockProjectOfficer($postcode);
                            // echo "<pre>"; print_r($projectOfficer); echo "</pre>"; exit();

                            if ($projectOfficer) {
                                $po = $projectOfficer['id'];
                                $poMobile = $projectOfficer['mobile_number'];
                            } else {
                                $po = 0;
                            }

                            $customerTractorModel = $this->_customerTractorFactory->create()->load($tractorId);

                            if (!empty($customerTractorModel->getOrderId()) && !empty($customerTractorModel->getOrderItemId())) {
                                $serviceNo = $this->getServiceNumberIfOrderExist($customerTractorModel);
                                if ($serviceNo) {
                                    // "<pre>>>>>"; print_r($serviceNo); echo "</pre>";
                                    $service_no = $serviceNo;
                                    $is_free_service = 1;
                                    $service_request_type = SR_TYPE_ROUTINE;
                                } else {
                                    $serviceReqColl = $this->_serviceFactory->create()->getCollection();
                                    $serviceReqColl->addFieldToFilter('tractor_id', ['eq' => $tractorId]);
                                    $serviceReqColl->setOrder('id')->setPageSize(1);

                                    if ($serviceReqColl->getSize() > 0) {
                                        $tractor = $serviceReqColl->getLastItem();
                                        $service_no = $tractor->getServiceNo() + 1;
                                        $is_free_service = 0;
                                        $service_request_type = SR_TYPE_REPAIR;
                                    } else {
                                        $service_no = 1;
                                        $is_free_service = 0;
                                        $service_request_type = SR_TYPE_REPAIR;
                                    }
                                }
                            } else {
                                $service_no = $this->getServiceNumber($tractorId);
                                $service_request_type = SR_TYPE_REPAIR;
                                $is_free_service = 0;
                            }
                            // $serviceDealer = 16;
                            if ($serviceDealer) {
                                $sdName = $this->_commonHelper->getCustomerNameById($serviceDealer);
                                $comment = NULL;
                                if (!empty($serviceRequest['comment'])) {
                                    $comment = $serviceRequest['comment'];
                                }

                                $data = [
                                    'tractor_id' => $tractorId,
                                    'customer_id' => $customerId,
                                    'address_id' => $serviceRequest['address_id'],
                                    'address' => $customerAddress,
                                    'lat' => $lat,
                                    'long' => $long,
                                    'service_request_type' => $service_request_type,
                                    'assigned_to' => $serviceDealer,
                                    'assigned_po' => $po,
                                    'is_free_service' => $is_free_service,
                                    'service_no' => $service_no,
                                    'created_at' => $this->_timezone->date()->format('Y-m-d H:i:s'),
                                    'status' => SR_STATUS_PENDING,
                                    'customer_comment' => $comment
                                ];

                                // echo "<pre>"; print_r($data); echo "</pre>"; exit();
                                $_serviceRequest = $this->_serviceFactory->create();
                                $_serviceRequest->setData($data);
                                $_serviceRequest->save();

                                // Customer Service Request Notification
                                $tractorName = $this->_commonHelper->getTractorNameByTractorId($tractorId);
                                //$customerMobile = '8630233796';
                                $params = [
                                    'name' => $customerName,
                                    'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                    'tractor_name' => $tractorName
                                ];

                                $custsms = $this->_smsHelper->sendSrSmsToCust($customerMobile, $params);
                                //var_dump($custsms);
                                // SD Service Request Notification
                                $params = [
                                    'name' => $sdName,
                                    'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                    'customer_name' => $customerName,
                                    'cusomer_mobile' => $customerMobile,
                                    'cusotomer_address' => $customerAddress,
                                    'tractor_name' => $tractorName
                                ];
                                $sdMobile = $this->_commonHelper->getCustomerMobileByID($serviceDealer);
                                //$sdMobile = '8630233796';
                                $sdsms = $this->_smsHelper->sendNewSrSmsToEtc($sdMobile, $params);
                                //var_dump($sdsms);
                                // PO Service Request Notification
                                if ($projectOfficer) {
                                    $po = $projectOfficer['id'];
                                    $poMobile = $projectOfficer['mobile_number'];
                                    //$poMobile = '8630233796';
                                    $params = [
                                        'name' => $projectOfficer['name'],
                                        'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                        'customer_name' => $customerName,
                                        'cusomer_mobile' => $customerMobile,
                                        'cusotomer_address' => $customerAddress,
                                        'tractor_name' => $tractorName
                                    ];
                                    $posms = $this->_smsHelper->sendNewSrSmsToEtc($poMobile, $params);
                                }

                                /*                                 * ***  Service Request Email to Admin  **** */
                                $parameters = [
                                    'customer_name' => $customerName,
                                    'mobile' => $customerMobile,
                                    'sr_id' => str_pad((string) $_serviceRequest->getId(), 10, '0', STR_PAD_LEFT),
                                    'customer_address' => $customerAddress,
                                    'tractor_name' => $tractorName,
                                    'subject' => 'Service Request - Create'
                                ];
                                $this->customEmailsHelper->sendServiceRequestNotification($parameters);
                                /*                                 * ***  Service Request Email to Admin  **** */

                                $response[0]['status'] = 1;
                                $response[0]['message'] = __('Service Request created successfully');
                                return $response;
                            } else {
                                $tractorName = $this->_commonHelper->getTractorNameByTractorId($tractorId);
                                $parameters = [
                                    'customer_name' => $customerName,
                                    'mobile' => $customerMobile,
                                    'customer_address' => $customerAddress,
                                    'tractor_name' => $tractorName,
                                    'date_time' => $this->_timezone->date()->format('Y-m-d H:i:s'),
                                    'subject' => 'Service Request - No Service Dealer Available'
                                ];
                                $this->customEmailsHelper->sendNoSdFoundOnServiceRequestCreate($parameters);

                                $response[0]['status'] = 0;
                                $response[0]['message'] = __('Sorry, we couldn\'t find any Service dealer in your area. Your request has been shared with our agent, we will get back to you soon.');
                                return $response;
                            }
                        } else {
                            $response[0]['status'] = 0;
                            $response[0]['message'] = __('You can\'t create more than one Service Request for same Tractor with in a single day');
                            return $response;
                        }
                    }
                } else {
                    $response[0]['status'] = 0;
                    $response[0]['message'] = __('We don\'t have sufficient data');
                    return $response;
                }
            }
        } catch (\Exception $e) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __($e->getMessage());
            return $response;
        }
    }

    /**
     * Save Customer Tractor
     * @param int $customerId
     * @param int $makeId
     * @param int $modelId     
     * @param mixed $deliveryDate
     * @return mixed
     */
    public function saveCustomerTractor($customerId, $makeId, $modelId, $registrationNo, $yearOfPurchase, $deliveryDate) {
        $_collections = $this->_customerTractorFactory->create()->getCollection()
                //->addFieldToFilter('customer_id', ['eq' => $customerId])
                //->addFieldToFilter('serial_number', ['eq' => $serialNumber])
                ->addFieldToFilter('registration_no', ['eq' => $registrationNo])
                ->setPageSize(1);

        if ($_collections->getSize()) {
            $tractor = $_collections->getFirstItem();
            if ($tractor->getCustomerId() == $customerId) {
                return $tractor->getTractorId();
            } else {
                return false;
            }
        }

        $_customerTractorModel = $this->_customerTractorFactory->create();
        $_customerTractorModel->setCustomerId($customerId);
        $_customerTractorModel->setMakeId($makeId);
        $_customerTractorModel->setModelId($modelId);
        $_customerTractorModel->setDeliveryDate($deliveryDate);
        //$_customerTractorModel->setSerialNumber($serialNumber);
        $_customerTractorModel->setManufacturingYear($yearOfPurchase);
        $_customerTractorModel->setRegistrationNo($registrationNo);
        $_customerTractorModel->setStatus(1);
        $_customerTractorModel->save();
        return $_customerTractorModel->getTractorId();
    }

    public function checkServiceRequestByCurrentDate($tractorId) {
        $currentDate = $this->_timezone->date()->format('Y-m-d');
        $fromDate = $currentDate . ' 00:00:00';
        $toDate = $currentDate . ' 23:59:59';

        $serviceRequestCollection = $this->_serviceFactory->create()->getCollection();

        $serviceRequestCollection->addFieldToFilter('tractor_id', ['eq' => $tractorId]);
        $serviceRequestCollection->addFieldToFilter('created_at', [
            'from' => $fromDate,
            'to' => $toDate
        ]);
        return $serviceRequestCollection;
    }

    public function getServiceNumber($tractorId) {
        /* $tractorId = 37; */
        try {
            if ($tractorId) {
                $srCollection = $this->_serviceFactory->create()->getCollection();
                $srCollection->addFieldToFilter('tractor_id', ['eq' => $tractorId])
                        ->setOrder('id')->setPageSize(1);

                if ($srCollection->getSize()) {
                    $tractor = $srCollection->getLastItem();
                    // echo "<pre>"; print_r($tractor->getData()); echo "</pre>";
                    $serviceNo = $tractor->getServiceNo() + 1;
                    return $serviceNo;
                } else {
                    return $serviceNo = 1;
                }
            }
        } catch (\Exception $e) {
            echo $e->getMessage();
        }
    }

    public function getServiceNumberIfOrderExist($customerTractorModel) {
        $_product = $this->_productloader->create()->load($customerTractorModel->getOrderItemId());
        $now = $this->_timezone->date()->format('Y-m-d');
        $deliveryDate = $customerTractorModel->getDeliveryDate();

        $diff = date_diff(date_create($now), date_create($deliveryDate));
        $days = $diff->format("%a");
        $itemCollection = $this->_servicePlanItemsFactory->create()->getCollection();
        $itemCollection->addFieldToFilter('setvice_plan_id', ['eq' => $_product->getServicePlan()]);
        // $days = 350;
        $status = false;
        foreach ($itemCollection as $serviceItems) {
            if ($days <= $serviceItems->getDays()) {
                $status = true;
                break;
            }
        }
        if ($status) {
            if ($serviceItems->getTitle() == 'pdi' || $serviceItems->getTitle() == 'installation') {
                $service_no = 1;
            } else {
                $service_no = (int) $serviceItems->getTitle();
            }
        } else {
            $service_no = false;
        }
        return $service_no;
    }

    /**
     * @api add New Tractor API
     */
    public function addNewTractor($customerId, $newTractorRequest) {
        try {
            if (!empty($newTractorRequest['make_id']) &&
                    !empty($newTractorRequest['model_id']) &&
                    !empty($newTractorRequest['manufacturing_year']) &&
                    //!empty($newTractorRequest['serial_number']) &&
                    !empty($newTractorRequest['registration_no'])
            ) {
                $collections = $this->_customerTractorFactory->create()
                        ->getCollection()
                        //->addFieldToFilter('serial_number', ['eq' => $newTractorRequest['serial_number']])
                        ->addFieldToFilter('registration_no', ['eq' => $newTractorRequest['registration_no']])
                        ->setPageSize(1);

                if ($collections->getSize()) {
                    $response[0]['status'] = 0;
                    $response[0]['message'] = __('We already have a tractor with the same Registration Number');
                    return $response;
                } else {
                    $newTractorRequest['delivery_date'] = $newTractorRequest['manufacturing_year'] . '-01-01 00:00:00';
                    $newTractorRequest['customer_id'] = $customerId;
                    $newTractorRequest['created_at'] = $this->_timezone->date()->format('Y-m-d H:i:s');
                    $newTractorRequest['status'] = 1;
                    //print_r($newTractorRequest);
                    $_customerTractor = $this->_customerTractorFactory->create();
                    $_customerTractor->setData($newTractorRequest);
                    $_customerTractor->save();
                    $response[0]['status'] = 1;
                    $response[0]['message'] = __('New Tractor added successfully');
                    return $response;
                }
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('We don\'t have sufficient data');
                return $response;
            }
        } catch (\Exception $e) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __($e->getMessage());
            return $response;
        }
    }

    /**
     * @api Update Tractor by tractor ID
     */
    public function updateTractor($customerId, $requestData) {
        //echo "<pre>";
        //print_r($requestData);
        //echo "</pre>";
        //exit();

        try {
            if (!is_numeric($requestData['make_id']) || !is_numeric($requestData['model_id'])) {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('Wrong Make or Model ID');
                return $response;
            }

            if ($requestData['tractor_id']) {
                $_tractor = $this->_customerTractorFactory->create()->load($requestData['tractor_id']);
                if ($_tractor->getData()) {
                    //if ($requestData['serial_number'] == $_tractor->getSerialNumber()) {
                    if ($requestData['registration_no'] == $_tractor->getRegistrationNo()) {
                        $_tractor->setData($requestData);
                        $_tractor->save();
                        $response[0]['status'] = 1;
                        $response[0]['message'] = __('Tractor updated successfully');
                        return $response;
                    } else {
                        $_tractorColl = $this->_customerTractorFactory->create()
                                ->getCollection()
                                //->addFieldToFilter('serial_number', ['eq' => $requestData['serial_number']])
                                ->addFieldToFilter('registration_no', ['eq' => $requestData['registration_no']]);

                        if (!$_tractorColl->getSize()) {
                            $_tractor->setData($requestData);
                            $_tractor->save();
                            $response[0]['status'] = 1;
                            $response[0]['message'] = __('Tractor updated successfully');
                            return $response;
                        } else {
                            $response[0]['status'] = 0;
                            $response[0]['message'] = __('Registration Number already exist');
                            return $response;
                        }
                    }
                }
            }
        } catch (\Exception $e) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __($e->getMessage());
            return $response;
        }
    }

    /**
     * @api get all tractor list
     */
    public function getAllTractor($customerId) {
        try {
            $_tractor = $this->_customerTractorFactory->create()
                    ->getCollection()
                    ->addFieldToFilter('customer_id', ['eq' => $customerId])
                    ->addFieldToFilter('status', ['eq' => 1])
                    ->setOrder('tractor_id', 'DESC');
            ;
            if ($_tractor->getSize()) {

                $response[0]['status'] = 1;
                $response[0]['message'] = __('Tractor found');

                $i = 0;
                foreach ($_tractor as $tractor) {
                    $name = $this->_commonHelper->getTractorName($tractor->getMakeId(), $tractor->getModelId());

                    $response[0]['tractors'][$i]['tractor_id'] = $tractor->getTractorId();
                    $response[0]['tractors'][$i]['tractor_name'] = $name;

                    if ($tractor->getSerialNumber()) {
                        $response[0]['tractors'][$i]['serial_number'] = $tractor->getSerialNumber();
                    } else {
                        $response[0]['tractors'][$i]['serial_number'] = null;
                    }

                    $response[0]['tractors'][$i]['brand'] = $this->_commonHelper->getTractorBrandName($tractor->getMakeId());
                    $response[0]['tractors'][$i]['make_id'] = $tractor->getMakeId();
                    $response[0]['tractors'][$i]['model_id'] = $tractor->getModelId();
                    $response[0]['tractors'][$i]['model'] = $this->_modelMasterFactory->create()->load($tractor->getModelId())->getModelName();
                    $response[0]['tractors'][$i]['year_of_purchase'] = $tractor->getManufacturingYear();
                    $response[0]['tractors'][$i]['registration_no'] = $tractor->getRegistrationNo();

                    $i++;
                }

                $response[0]['tractor_collection'] = $_tractor->getData();
                return $response;
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('No Tractor found');
                return $response;
            }
        } catch (\Exception $e) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __($e->getMessage());
            return $response;
        }
    }

    /**
     * @api Cancel Service Request
     */
    public function cancelServiceRequest($srCancelData) {
        try {
            $_service = $this->_serviceFactory->create()->load($srCancelData['id']);
            // echo "<pre>"; print_r($_service->getData()); echo "</pre>";
            if ($_service->getId()) {
                $comment = null;
                if (!empty($srCancelData['comment'])) {
                    $comment = $srCancelData['comment'];
                }
                $_service->setCanceledComment($comment);
                $_service->setStatus(SR_STATUS_CANCELLED);
                $_service->setCanceledAt($this->_timezone->date()->format('Y-m-d H:i:s'));
                $_service->save();
                $response[0]['status'] = 1;
                $response[0]['message'] = __('Service Request cancelled successfully');
                return $response;
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('Service request does not exists');
                return $response;
            }
        } catch (\Exception $e) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __($e->getMessage());
            return $response;
        }
    }

    /**
     * Not in Use
     * Get Customer Address By Customer Id
     * @param int $customerId
     * @return mixed
     */
    public function getCustomerAddressByCustomerId($customerId) {
        $response = [];
        $customer = $this->_customerFactory->create()->load($customerId);
        if ($customer->getAddresses()) {
            $customerAddress = [];
            foreach ($customer->getAddresses() as $address) {
                $customerAddress[] = $address->toArray();
            }

            if ($customerAddress) {
                foreach ($customerAddress as $customerAddres) {
                    if (!empty($customerAddres['street'])) {
                        $_customerAddress = $customerAddres['street'];
                    }
                    if (!empty($customerAddres['landmark'])) {
                        $_customerAddress = $_customerAddress . ', ' . $customerAddres['landmark'];
                    }
                    if (!empty($customerAddres['village'])) {
                        $_customerAddress = $_customerAddress . ', ' . $customerAddres['village'];
                    }
                    if (!empty($customerAddres['tehsil'])) {
                        $_customerAddress = $_customerAddress . ', ' . $customerAddres['tehsil'];
                    }
                    if (!empty($customerAddres['city'])) {
                        $_customerAddress = $_customerAddress . ', ' . $customerAddres['city'];
                    }
                    if (!empty($customerAddres['region'])) {
                        $_customerAddress = $_customerAddress . ', ' . $customerAddres['region'];
                    }
                    if (!empty($customerAddres['country'])) {
                        $_customerAddress = $_customerAddress . ', ' . $this->_countryFactory->create()->loadByCode($customerAddres['country_id'])->getName() . '(' . $customerAddres['country_id'] . ')';
                    }
                    if (!empty($customerAddres['postcode'])) {
                        $_customerAddress = $_customerAddress . ', ' . $customerAddres['postcode'];
                    }
                    $response = $_customerAddress;

                    return $response;
                }
            }
        }
        return false;
    }

    public function editTractor($customerId, $tractorId) {
        try {
            $customerTractorModel = $this->_customerTractorFactory->create();
            if ($tractorId) {
                $customerTractor = $customerTractorModel->load($tractorId);
                if (!empty($customerTractor->getData())) {
                    $response[0]['status'] = 1;
                    $response[0]['message'] = __('Tractor Found');
                    $response[0]['tractor'] = $customerTractor->getData();
                } else {
                    $response[0]['status'] = 0;
                    $response[0]['message'] = __('No Tractor Found');
                }
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('Missing Data');
            }
        } catch (\Exception $e) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __($e->getMessage());
        }
        return $response;
    }

    /**
     * Get Service Request Status in string
     * @param int $status
     * @return string
     */
    public function getSrStatusString($status) {
        $statuses = $this->_serviceStatusesFactory->create()
                ->getCollection()
                ->addFieldToFilter('status_id', ['eq' => $status])
                ->setPageSize(1);
        return $statuses->getFirstItem()->getValue();
    }

    /**
     * Get Service Request Type in string
     * @param int $srType
     * @return string
     */
    public function getSrTypeString($srType) {
        $srTypes = $this->_serviceRequestTypeFactory->create()
                ->getCollection()
                ->addFieldToFilter('id', ['eq' => $srType])
                ->setPageSize(1);
        return $srTypes->getFirstItem()->getValue();
    }

}
