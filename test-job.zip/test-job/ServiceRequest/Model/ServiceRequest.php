<?php

/**
 * Escorts
 */

namespace Escorts\ServiceRequest\Model;

use Escorts\ServiceRequest\Api\ServiceRequestInterface;
use Magento\Framework\Phrase;

class ServiceRequest implements ServiceRequestInterface {

    protected $_postFactory;
    protected $_helperData;
    protected $_customer;
    protected $_address;
    protected $_countryFactory;
    protected $_regionFactory;
    protected $_timezone;
    protected $_serviceTypeFactory;
    protected $_serviceIssuesFactory;
    protected $_servicePid;
    protected $_serviceOpsions;
    protected $_jobNoFactory;
    protected $_commonHelper;
    protected $_serviceInstallation;
    protected $_storeManager;
    protected $_customerFactory;
    protected $_smsNotificationHelper;
    protected $_serviceStatusesFactory;
    protected $_serviceRejectReasonsFactory;
    protected $_serviceRequestType;
    protected $_serviceRequestTypeFactory;
    protected $_serviceEscalateReasonsFactory;
    protected $_serviceScheduleFactory;
    protected $_customerTractorFactory;
    protected $_serviceObservationsFactory;
    protected $_serviceJobPartsFactory;
    protected $_sparePartsApiFactory;

    /**
     * @param \Escorts\ServiceRequest\Model\ServiceFactory $postFactory
     * @param \Escorts\ServiceRequest\Helper\Data $helperData
     * @param \Magento\Customer\Model\CustomerFactory $customer
     * @param \Magento\Customer\Model\AddressFactory $address
     * @param \Magento\Directory\Model\CountryFactory $countryFactory
     * @param \Magento\Directory\Model\RegionFactory $regionFactory
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
     * @param \Escorts\ServiceRequest\Model\RequestTypeFactory $serviceTypeFactory
     * @param \Escorts\ServiceRequest\Model\ServiceIssuesFactory $serviceIssuesFactory
     * @param \Escorts\ServiceRequest\Model\ServicePdiFactory $servicePid
     * @param \Escorts\ServiceRequest\Model\ServiceOptionsFactory $serviceOptions
     * @param \Escorts\ServiceRequest\Model\ServiceJobNoFactory $jobNoFactory
     * @param \Escorts\ServiceRequest\Model\ServiceInstallationFactory $serviceInstallation
     * @param \Escorts\Common\Helper\Data $commonHelper
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     * @param \Escorts\SmsNotification\Helper\Data $smsNotificationHelper
     * @param \Escorts\ServiceRequest\Model\ServiceStatusesFactory $serviceStatusesFactory
     * @param \Escorts\ServiceRequest\Model\ServiceRejectReasonsFactory $serviceRejectReasonsFactory
     * @param \Escorts\ServiceRequest\Model\RequestTypeFactory $serviceRequestTypeFactory
     * @param \Escorts\ServiceRequest\Model\ServiceEscalateReasonsFactory $serviceEscalateReasonsFactory
     * @param \Escorts\ServiceRequest\Model\ServiceScheduleFactory $serviceScheduleFactory
     * @param \Escorts\ServiceRequest\Model\CustomerTractorFactory $customerTractorFactory
     * @param \Escorts\ServiceRequest\Model\ServiceObservationsFactory $serviceObservationsFactory
     * @param \Escorts\ServiceRequest\Model\ServiceJobPartsFactory $serviceJobPartsFactory
     * @param \Escorts\SpareParts\Model\SparePartsApiFactory $sparePartsApiFactory
     */
    public function __construct(
    \Escorts\ServiceRequest\Model\ServiceFactory $postFactory, \Escorts\ServiceRequest\Helper\Data $helperData, \Magento\Customer\Model\CustomerFactory $customer, \Magento\Customer\Model\AddressFactory $address, \Magento\Directory\Model\CountryFactory $countryFactory, \Magento\Directory\Model\RegionFactory $regionFactory, \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone, \Escorts\ServiceRequest\Model\RequestTypeFactory $serviceTypeFactory, \Escorts\ServiceRequest\Model\ServiceIssuesFactory $serviceIssuesFactory, \Escorts\ServiceRequest\Model\ServicePdiFactory $servicePid, \Escorts\ServiceRequest\Model\ServiceOptionsFactory $serviceOptions, \Escorts\ServiceRequest\Model\ServiceJobNoFactory $jobNoFactory, \Escorts\ServiceRequest\Model\ServiceInstallationFactory $serviceInstallation, \Escorts\Common\Helper\Data $commonHelper, \Magento\Store\Model\StoreManagerInterface $storeManager, \Magento\Customer\Model\CustomerFactory $customerFactory, \Escorts\SmsNotification\Helper\Data $smsNotificationHelper, \Escorts\ServiceRequest\Model\ServiceStatusesFactory $serviceStatusesFactory, \Escorts\ServiceRequest\Model\ServiceRejectReasonsFactory $serviceRejectReasonsFactory, \Escorts\ServiceRequest\Model\RequestTypeFactory $serviceRequestTypeFactory, \Escorts\ServiceRequest\Model\ServiceEscalateReasonsFactory $serviceEscalateReasonsFactory, \Escorts\ServiceRequest\Model\ServiceScheduleFactory $serviceScheduleFactory, \Escorts\ServiceRequest\Model\CustomerTractorFactory $customerTractorFactory, \Escorts\ServiceRequest\Model\ServiceObservationsFactory $serviceObservationsFactory, \Escorts\ServiceRequest\Model\ServiceJobPartsFactory $serviceJobPartsFactory, \Escorts\SpareParts\Model\SparePartsApiFactory $sparePartsApiFactory
    ) {
        $this->_postFactory = $postFactory;
        $this->_helperData = $helperData;
        $this->_customer = $customer;
        $this->_address = $address;
        $this->_countryFactory = $countryFactory;
        $this->_regionFactory = $regionFactory;
        $this->_timezone = $timezone;
        $this->_serviceTypeFactory = $serviceTypeFactory;
        $this->_serviceIssuesFactory = $serviceIssuesFactory;
        $this->_servicePid = $servicePid;
        $this->_serviceOpsions = $serviceOptions;
        $this->_jobNoFactory = $jobNoFactory;
        $this->_commonHelper = $commonHelper;
        $this->_serviceInstallation = $serviceInstallation;
        $this->_storeManager = $storeManager;
        $this->_customerFactory = $customerFactory;
        $this->_smsNotificationHelper = $smsNotificationHelper;
        $this->_serviceStatusesFactory = $serviceStatusesFactory;
        $this->_serviceRejectReasonsFactory = $serviceRejectReasonsFactory;
        $this->_serviceRequestTypeFactory = $serviceRequestTypeFactory;
        $this->_serviceEscalateReasonsFactory = $serviceEscalateReasonsFactory;
        $this->_serviceScheduleFactory = $serviceScheduleFactory;
        $this->_customerTractorFactory = $customerTractorFactory;
        $this->_serviceObservationsFactory = $serviceObservationsFactory;
        $this->_serviceJobPartsFactory = $serviceJobPartsFactory;
        $this->_sparePartsApiFactory = $sparePartsApiFactory;
    }

    /**
     * @param int $sdid
     * @param int $statusId
     * @param int $curPage
     * @param int $pageSize
     * @return mixed
     */
    public function getServiceRequestList($sdid, $statusId = null, $curPage = 1, $pageSize = 10) {
        $collector = [];
        $collector[0]['status'] = 0;
        $collector[0]['message'] = __('No Service Request Available');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $collector[0]['status'] = 0;
            $collector[0]['message'] = __('You aren\'t authorized user');
            return $collector;
        }

        $tat = $this->_helperData->getGeneralConfig('tat');
        $modelobj = $this->_postFactory->create();
        $collection = $modelobj->getCollection();
        $collection->addFieldToSelect('*');
        $collection->addFieldToFilter('assigned_to', ['eq' => $sdid]);

        if ($statusId >= 0) {
            $collection->addFieldToFilter('status', ['eq' => $statusId]);
        }

        if ($pageSize) {
            $collector[0]['pages'] = ceil($collection->getSize() / $pageSize);
            $collector[0]['total'] = $collection->getSize();
            $collection->setPageSize($pageSize);
        }

        if ($curPage) {
            $collection->setCurPage($curPage);
        }

        $collection->setOrder('id', 'DESC');

        if ($collection->getSize()) {
            foreach ($collection as $key => $item) {
                if ($item->getCustomerId()) {
                    $data['sr_id'] = $item->getId();
                    $data['sr_id_str'] = str_pad((string) $item->getId(), 10, '0', STR_PAD_LEFT);
                    $data['created_at'] = $item->getCreatedAt();
                    $data['status'] = $item->getStatus();
                    $data['status_str'] = $this->getSrStatusString($item->getStatus());
                    $data['accept_status'] = $item->getAcceptStatus();
                    $data['type'] = $item->getServiceRequestType();
                    $data['type_str'] = $this->getSrTypeString($item->getServiceRequestType());

                    if (($data['status'] == SR_STATUS_PENDING) && ($item->getServiceRequestType() != 1)) {
                        if ($item->getParentId()) {
                            $parentSr = $this->_postFactory->create()->load($item->getParentId());
                            $data['left_time'] = $this->_commonHelper->getLeftTime($parentSr->getCreatedAt(), $tat);
                        } else {
                            $data['left_time'] = $this->_commonHelper->getLeftTime($item->getCreatedAt(), $tat);
                        }
                    } else {
                        $data['left_time'] = null;
                    }

                    if ($data['status'] == SR_STATUS_SCHEDULED) {
                        $serviceSchedules = $this->_serviceScheduleFactory->create()
                                ->getCollection()
                                ->addFieldToSelect(['scheduled_for'])
                                ->addFieldToFilter('srid', ['eq' => $item->getId()])
                                ->setPageSize(1)
                                ->setOrder('id', 'DESC');
                        if ($serviceSchedules->getSize()) {
                            $serviceSchedule = $serviceSchedules->getFirstItem();
                            $data['scheduled_for'] = $serviceSchedule->getScheduledFor();
                        }
                    } else {
                        $data['scheduled_for'] = null;
                    }

                    if ($item->getTractorId()) {
                        $tractor = $this->_customerTractorFactory->create()->load($item->getTractorId());
                        $data['product_name'] = $this->_commonHelper->getTractorName($tractor->getMakeId(), $tractor->getModelId());
                    } else {
                        $data['product_name'] = 'Tractor';
                    }

                    $customer = $this->_customer->create()->load($item->getCustomerId());

                    if ($customer) {
                        if ($item->getAddressId()) {
                            $address = $this->_address->create()->load($item->getAddressId());
                        }

                        if (empty($address)) {
                            $address = $this->_address->create()->load($customer->getDefaultShipping());
                        }

                        if ($address->getId()) {
                            //$customerAddress['name'] = $address->getName();
                            $customerAddress['name'] = $customer->getName();
                            $customerAddress['street'] = implode(" ", $address->getStreet());
                            $customerAddress['landmark'] = $address->getLandmark();
                            $customerAddress['village'] = $address->getVillage();
                            $customerAddress['tehsil'] = $address->getTehsil();
                            $customerAddress['district'] = $address->getCity();
                            $customerAddress['country'] = $this->_countryFactory->create()->loadByCode($address->getCountryId())->getName();
                            $customerAddress['postcode'] = $address->getPostcode();
                            //$customerAddress['telephone'] = $address->getTelephone();
                            $customerAddress['telephone'] = $customer->getMobileNumber();

                            $state = $address->getRegionId();
                            if (is_numeric($state)) {
                                $state = $this->_regionFactory->create()->load($state)->getName();
                            }

                            $customerAddress['state'] = $state;
                            $data['customer_address'] = $customerAddress;
                        }

                        /* $data['customer_detail'] = [
                          'name' => $customer->getName(),
                          'mobile_number' => $customer->getMobileNumber()
                          ]; */

                        $collector[0]['requests'][] = $data;
                    }
                }
            }

            $collector[0]['status'] = 1;
            $collector[0]['message'] = $collection->getSize() . __(' Service Request Available');
        }

        $collector[0]['statuses'] = $this->_serviceStatusesFactory->create()->getCollection()->getData();
        $collector[0]['service_request_type'] = $this->_serviceRequestTypeFactory->create()->getCollection()->getData();
        $collector[0]['reject_reasons'] = $this->_serviceRejectReasonsFactory->create()->getCollection()->getData();
        $collector[0]['escalate_reasons'] = $this->_serviceEscalateReasonsFactory->create()->getCollection()->getData();

        return $collector;
    }

    /**
     * Get Service Request Status in string
     * @param int $status
     * @return string
     */
    public function getSrStatusString($status) {
        $statuses = $this->_serviceStatusesFactory->create()
                ->getCollection()
                ->addFieldToFilter('status_id', ['eq' => $status])
                ->setPageSize(1);
        return $statuses->getFirstItem()->getValue();
    }

    /**
     * Get Service Request Type in string
     * @param int $srType
     * @return string
     */
    public function getSrTypeString($srType) {
        $srTypes = $this->_serviceRequestTypeFactory->create()
                ->getCollection()
                ->addFieldToFilter('id', ['eq' => $srType])
                ->setPageSize(1);
        return $srTypes->getFirstItem()->getValue();
    }

    /**
     * Not in use
     * @param int $sdid
     * @param int $srid
     * @return mixed
     */
    public function getServiceRequestCustomer($sdid, $srid) {
        $collector = [];
        //$collector[0]['status'] = 0;
        //$collector[0]['message'] = 'Details not available';

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $collector[0]['status'] = 0;
            $collector[0]['message'] = __('You aren\'t authorized user');
            return $collector;
        }

        $modelobj = $this->_postFactory->create()->load($srid);

        if ($modelobj->getId()) {
            $tat = $this->_helperData->getGeneralConfig('tat');
            $collector[0]['created_at'] = $modelobj->getCreatedAt();
            $collector[0]['status'] = (int) $modelobj->getStatus(); //sr_status
            $collector[0]['accept_status'] = (int) $modelobj->getAcceptStatus();

            if (($modelobj->getStatus() == SR_STATUS_PENDING) && ($modelobj->getServiceRequestType() != 1)) {
                if ($modelobj->getParentId()) {
                    $parentSr = $this->_postFactory->create()->load($modelobj->getParentId());
                    $collector[0]['left_time'] = $this->_commonHelper->getLeftTime($parentSr->getCreatedAt(), $tat);
                } else {
                    $collector[0]['left_time'] = $this->_commonHelper->getLeftTime($modelobj->getCreatedAt(), $tat);
                }
            } else {
                $collector[0]['left_time'] = null;
            }

            if ($modelobj->getStatus() == SR_STATUS_SCHEDULED) {
                $serviceSchedules = $this->_serviceScheduleFactory->create()
                        ->getCollection()
                        ->addFieldToSelect(['scheduled_for'])
                        ->addFieldToFilter('srid', ['eq' => $modelobj->getId()])
                        ->setPageSize(1)
                        ->setOrder('id', 'DESC');
                if ($serviceSchedules->getSize()) {
                    $serviceSchedule = $serviceSchedules->getFirstItem();
                    $collector[0]['scheduled_for'] = $serviceSchedule->getScheduledFor();
                }
            } else {
                $collector[0]['scheduled_for'] = null;
            }

            $collector[0]['type'] = (int) $modelobj->getServiceRequestType();

            if ($modelobj->getTractorId()) {
                $tractor = $this->_customerTractorFactory->create()->load($modelobj->getTractorId());
                $collector[0]['product_name'] = $this->_commonHelper->getTractorName($tractor->getMakeId(), $tractor->getModelId());
            } else {
                $collector[0]['product_name'] = 'Tractor';
            }

            $customer = $this->_customer->create()->load($modelobj->getCustomerId());
            $shippingAddressId = $customer->getDefaultShipping();

            if ($shippingAddressId) {
                $address = $this->_address->create()->load($shippingAddressId);
                //$collector[0]['name'] = $address->getName();
                $collector[0]['name'] = $customer->getName();
                $collector[0]['father_name'] = $customer->getFatherName();
                $collector[0]['street'] = implode(" ", $address->getStreet());
                $collector[0]['landmark'] = $address->getLandmark();
                $collector[0]['village'] = $address->getVillage();
                $collector[0]['tehsil'] = $address->getTehsil();
                $collector[0]['district'] = $address->getCity();
                $collector[0]['country'] = $this->_countryFactory->create()->loadByCode($address->getCountryId())->getName();
                $collector[0]['postcode'] = $address->getPostcode();
                //$collector[0]['telephone'] = $address->getTelephone();
                $collector[0]['telephone'] = $customer->getMobileNumber();
                $state = $address->getRegionId();
                if (is_numeric($state)) {
                    $state = $this->_regionFactory->create()->load($state)->getName();
                }

                $collector[0]['state'] = $state;
            } else {
                $collector[0]['name'] = null;
                $collector[0]['father_name'] = null;
                $collector[0]['street'] = null;
                $collector[0]['landmark'] = null;
                $collector[0]['village'] = null;
                $collector[0]['tehsil'] = null;
                $collector[0]['district'] = null;
                $collector[0]['country'] = null;
                $collector[0]['postcode'] = null;
                $collector[0]['telephone'] = null;
                $collector[0]['state'] = null;
            }

            //$collector[0]['status'] = 1;
            //$collector[0]['message'] = 'Details found';
        } else {
            $collector[0]['status'] = 0;
            $collector[0]['message'] = __('Service request id is wrong');
        }

        $collector[0]['statuses'][] = $this->_serviceStatusesFactory->create()->getCollection()->getData();
        $collector[0]['service_request_type'][] = $this->_serviceRequestTypeFactory->create()->getCollection()->getData();
        $collector[0]['reject_reasons'][] = $this->_serviceRejectReasonsFactory->create()->getCollection()->getData();
        $collector[0]['escalate_reasons'][] = $this->_serviceEscalateReasonsFactory->create()->getCollection()->getData();

        return $collector;
    }

    /**
     * Not in use
     * @param int $sdid
     * @param int $srid
     * @return mixed     
     */
    public function getServiceRequestTractor($sdid, $srid) {
        $collector = [];
        //$collector[0]['status'] = 0;
        //$collector[0]['message'] = 'Details not available';

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $collector[0]['status'] = 0;
            $collector[0]['message'] = __('You aren\'t authorized user');
            return $collector;
        }

        $modelobj = $this->_postFactory->create()->load($srid);

        if ($modelobj->getId()) {
            $collector[0]['created_at'] = $modelobj->getCreatedAt();
            //$collector[$key]['left_time'] = $this->_commonHelper->getLeftTime($modelobj->getCreatedAt(), $tat);            

            $collector[0]['brand'] = null;
            $collector[0]['model'] = null;
            $collector[0]['serial_number'] = null;
            $collector[0]['engine_number'] = null;
            $collector[0]['manufacturing_year'] = null;
            $collector[0]['chassis_number'] = null;
            $collector[0]['delivery_date'] = null;


            if ($modelobj->getTractorId()) {
                $tractor = $this->_customerTractorFactory->create()->load($modelobj->getTractorId());
                $collector[0]['brand'] = $this->_commonHelper->getTractorBrandName($tractor->getMakeId());
                //$collector[0]['model'] = $this->_commonHelper->getTractorName($tractor->getMakeId(), $tractor->getModelId());
                $collector[0]['model'] = $this->_commonHelper->getTractorModelName($tractor->getModelId());
                $collector[0]['serial_number'] = $tractor->getSerialNumber();
                $collector[0]['engine_number'] = $tractor->getEngineNumber();
                $collector[0]['manufacturing_year'] = $tractor->getManufacturingYear();
                $collector[0]['chassis_number'] = $tractor->getChassisNumber();

                if ($modelobj->getServiceRequestType() == SR_TYPE_PDI ||
                        $modelobj->getServiceRequestType() == SR_TYPE_INSTALLATION) {
                    $collector[0]['dispatch_date'] = null;
                    $collector[0]['transporter_name'] = null;
                    $collector[0]['transporter_mobile'] = null;
                    $collector[0]['transporter_alt_mobile'] = null;
                    $order = $this->_commonHelper->getOrderObject($tractor->getOrderId());
                    if ($order) {
                        if ($order->getShipmentsCollection()) {
                            foreach ($order->getShipmentsCollection() as $shipment) {
                                $collector[0]['dispatch_date'] = $shipment->getCreatedAt();
                                break;
                            }
                        }

                        $collector[0]['transporter_name'] = $order->getTransportalName();
                        $collector[0]['transporter_mobile'] = $order->getTransportalMobile();
                        $collector[0]['transporter_alt_mobile'] = $order->getTransportalAltMobile();
                    }
                } else {
                    $collector[0]['delivery_date'] = $tractor->getDeliveryDate();
                }
            }

            //$collector[0]['status'] = 1;
            //$collector[0]['message'] = 'Details found';
        } else {
            $collector[0]['status'] = 0;
            $collector[0]['message'] = __('Service request id is wrong');
        }

        return $collector;
    }

    /**
     * Not in use
     * @param int $sdid
     * @param int $srid
     * @return type
     */
    public function getServiceRequestServiceDetail($sdid, $srid) {
        $collector = [];
        //$collector[0]['status'] = 0;
        //$collector[0]['message'] = 'Details not available';

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $collector[0]['status'] = 0;
            $collector[0]['message'] = __('You aren\'t authorized user');
            return $collector;
        }

        $issuesArray = [];
        $serviceTypeArray = [];
        $i = 0;
        $j = 0;

        $serviceIssuesCollection = $this->_serviceIssuesFactory->create()->getCollection();
        foreach ($serviceIssuesCollection as $item) {
            $issuesArray[$i]['id'] = $item->getId();
            $issuesArray[$i]['value'] = $item->getValue();
            $i++;
        }

        $serviceTypeCollection = $this->_serviceTypeFactory->create()->getCollection();

        foreach ($serviceTypeCollection as $item) {
            $serviceTypeArray[$j]['id'] = $item->getId();
            $serviceTypeArray[$j]['value'] = $item->getValue();
            $j++;
        }

        //$tat = $this->_helperData->getGeneralConfig('tat');
        $modelobj = $this->_postFactory->create()->load($srid);

        if ($modelobj->getId()) {
            $collector[0]['created_at'] = $modelobj->getCreatedAt();
            $collector[0]['type'] = $modelobj->getServiceRequestType();
            $collector[0]['type_str'] = $this->getSrTypeString($modelobj->getServiceRequestType());
            $collector[0]['coupon_code'] = $modelobj->getCouponCode() ?: '';
            //$collector[0]['issues'] = $modelobj->getIssuesId();
            $collector[0]['customer_comment'] = $modelobj->getCustomerComment();
            $collector[0]['status'] = $modelobj->getStatus();  //sr_status
            //if ($modelobj->getParentId()) {
            //    $collector[0]['escalated_by'] = 'Rakesh Chand (16)';
            //    $collector[0]['escalated_at'] = '2018-06-29 17:28:58';
            //    $collector[0]['escalated_reason'] = '1,4';
            //    $collector[0]['escalated_comment'] = 'not feeling well';
            //    $collector[0]['escalated_reason_list'] = [
            //        ['id' => 0, 'value' => 'Reason 1'],
            //        ['id' => 1, 'value' => 'Reason 2'],
            //        ['id' => 2, 'value' => 'Reason 3'],
            //        ['id' => 3, 'value' => 'Reason 4'],
            //        ['id' => 4, 'value' => 'Reason 5'],
            //        ['id' => 5, 'value' => 'Reason 6']
            //    ];
            //}
            //$collector[0]['issue_list'] = $issuesArray;
            //$collector[0]['service_type_list'] = $serviceTypeArray;
            //$collector[0]['status'] = 1;
            //$collector[0]['message'] = 'Details found';
        } else {
            $collector[0]['status'] = 0;
            $collector[0]['message'] = __('Service request id is wrong');
        }

        return $collector;
    }

    /**
     * Get service request detail
     * @param int $sdid
     * @param int $srid
     * @return mixed
     */
    public function getServiceRequestDetail($sdid, $srid) {
        $collector = [];
        $collector[0]['status'] = 0;
        $collector[0]['message'] = __('Something went wrong. Please try again later');

        try {
            if (!$this->_commonHelper->isEtcPermissons($sdid)) {
                $collector[0]['message'] = __('You aren\'t authorized user');
                return $collector;
            }

            $modelobj = $this->_postFactory->create()->load($srid);

            if ($modelobj->getId()) {
                $customerDetail = [];
                $tractorDetail = [];
                $serviceDetail = [];

                $collector[0]['scheduled_for'] = null;
                $collector[0]['left_time'] = null;
                $tractorDetail['dispatch_date'] = null;
                $tractorDetail['transporter_name'] = null;
                $tractorDetail['transporter_mobile'] = null;
                $tractorDetail['transporter_alt_mobile'] = null;
                $tractorDetail['delivery_date'] = null;

                $tat = $this->_helperData->getGeneralConfig('tat');

                $customer = $this->_customer->create()->load($modelobj->getCustomerId());

                if ($modelobj->getAddressId()) {
                    $shippingAddressId = $modelobj->getAddressId();
                } else {
                    $shippingAddressId = $customer->getDefaultShipping();
                }

                if ($shippingAddressId) {
                    $address = $this->_address->create()->load($shippingAddressId);
                    //$collector[0]['name'] = $address->getName();
                    $customerDetail['name'] = $customer->getName();
                    $customerDetail['father_name'] = $customer->getFatherName();
                    $customerDetail['street'] = implode(" ", $address->getStreet());
                    $customerDetail['landmark'] = $address->getLandmark();
                    $customerDetail['village'] = $address->getVillage();
                    $customerDetail['tehsil'] = $address->getTehsil();
                    $customerDetail['district'] = $address->getCity();
                    $customerDetail['country'] = $this->_countryFactory->create()->loadByCode($address->getCountryId())->getName();
                    $customerDetail['postcode'] = $address->getPostcode();
                    //$customerDetail['telephone'] = $address->getTelephone();
                    $customerDetail['telephone'] = $customer->getMobileNumber();
                    $state = $address->getRegionId();
                    if (is_numeric($state)) {
                        $state = $this->_regionFactory->create()->load($state)->getName();
                    }

                    $customerDetail['state'] = $state;
                }

                if ($modelobj->getTractorId()) {
                    $tractor = $this->_customerTractorFactory->create()->load($modelobj->getTractorId());
                    $tractorDetail['serial_number'] = $tractor->getSerialNumber();
                    $tractorDetail['engine_number'] = $tractor->getEngineNumber();
                    $tractorDetail['chassis_number'] = $tractor->getChassisNumber();
                    $tractorDetail['manufacturing_year'] = $tractor->getManufacturingYear();
                    $tractorDetail['brand'] = $this->_commonHelper->getTractorBrandName($tractor->getMakeId());
                    $tractorDetail['model'] = $this->_commonHelper->getTractorModelName($tractor->getModelId());

                    if ($modelobj->getServiceRequestType() == SR_TYPE_PDI ||
                            $modelobj->getServiceRequestType() == SR_TYPE_INSTALLATION) {

                        $order = $this->_commonHelper->getOrderObject($tractor->getOrderId());
                        if ($order) {
                            if ($order->getShipmentsCollection()) {
                                foreach ($order->getShipmentsCollection() as $shipment) {
                                    $tractorDetail['dispatch_date'] = $shipment->getCreatedAt();
                                    break;
                                }
                            }

                            $tractorDetail['transporter_name'] = $order->getTransportalName();
                            $tractorDetail['transporter_mobile'] = $order->getTransportalMobile();
                            $tractorDetail['transporter_alt_mobile'] = $order->getTransportalAltMobile();
                        }
                    } else {
                        $tractorDetail['delivery_date'] = $tractor->getDeliveryDate();
                    }
                }

                $collector[0]['created_at'] = $modelobj->getCreatedAt();
                $collector[0]['sr_status'] = $modelobj->getStatus();
                $collector[0]['sr_status_str'] = $this->getSrStatusString($modelobj->getStatus());
                $collector[0]['accept_status'] = $modelobj->getAcceptStatus();

                if (($modelobj->getStatus() == SR_STATUS_PENDING) && ($modelobj->getServiceRequestType() != 1)) {
                    if ($modelobj->getParentId()) {
                        $parentSr = $this->_postFactory->create()->load($modelobj->getParentId());
                        $collector[0]['left_time'] = $this->_commonHelper->getLeftTime($parentSr->getCreatedAt(), $tat);
                    } else {
                        $collector[0]['left_time'] = $this->_commonHelper->getLeftTime($modelobj->getCreatedAt(), $tat);
                    }
                }

                if ($modelobj->getStatus() == SR_STATUS_SCHEDULED) {
                    $serviceSchedules = $this->_serviceScheduleFactory->create()
                            ->getCollection()
                            ->addFieldToSelect(['scheduled_for'])
                            ->addFieldToFilter('srid', ['eq' => $modelobj->getId()])
                            ->setPageSize(1)
                            ->setOrder('id', 'DESC');
                    if ($serviceSchedules->getSize()) {
                        $serviceSchedule = $serviceSchedules->getFirstItem();
                        $collector[0]['scheduled_for'] = $serviceSchedule->getScheduledFor();
                    }
                }

                $serviceDetail['type'] = $modelobj->getServiceRequestType();
                $serviceDetail['type_str'] = $this->getSrTypeString($modelobj->getServiceRequestType());
                $serviceDetail['coupon_code'] = $modelobj->getCouponCode();
                $serviceDetail['customer_comment'] = $modelobj->getCustomerComment();
                $serviceDetail['lat'] = $modelobj->getLat();
                $serviceDetail['lang'] = $modelobj->getlong();

                $collector[0]['customer_detail'] = $customerDetail;
                $collector[0]['tractor_detail'] = $tractorDetail;
                $collector[0]['service_detail'] = $serviceDetail;

                $collector[0]['status'] = 1;
                $collector[0]['message'] = __('Service request detail');
            } else {
                $collector[0]['status'] = 0;
                $collector[0]['message'] = __('Service request ID is wrong');
            }

            //$collector[0]['statuses'][] = $this->_serviceStatusesFactory->create()->getCollection()->getData();
            //$collector[0]['service_request_type'][] = $this->_serviceRequestTypeFactory->create()->getCollection()->getData();
            //$collector[0]['reject_reasons'][] = $this->_serviceRejectReasonsFactory->create()->getCollection()->getData();
            //$collector[0]['escalate_reasons'][] = $this->_serviceEscalateReasonsFactory->create()->getCollection()->getData();
        } catch (Exception $ex) {
            
        }

        return $collector;
    }

    /**
     * @param int $sdid
     * @param int $serviceRequestType
     * @param int $srid
     * @param mixed $lat
     * @param mixed $long
     * @return mixed
     */
    public function getServiceRequestJobNo($sdid, $serviceRequestType, $srid, $lat = null, $long = null) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        if (($serviceRequestType != SR_TYPE_PDI) && ($serviceRequestType != SR_TYPE_INSTALLATION)) {
            return $response;
        }

        $serviceModelObj = $this->_postFactory->create()->load($srid);

        if ($serviceModelObj->getId() && ($serviceModelObj->getServiceRequestType() == $serviceRequestType)) {
            $jobmodel = $this->_jobNoFactory->create();
            $collection = $jobmodel->getCollection();
            $collection->addFieldToSelect(['id']);
            $collection->addFieldToFilter('srid', ['eq' => $srid]);
            $collection->addFieldToFilter('service_request_type', ['eq' => $serviceRequestType]);
            $response = $collection->getData();

            if (!$response) {
                $jobmodel->setServiceRequestType($serviceRequestType);
                $jobmodel->setSrid($srid);
                $jobmodel->setCreatedAt($this->_timezone->date()->format('Y-m-d H:i:s'));
                $jobmodel->setLatOpen($lat);
                $jobmodel->setLongOpen($long);
                $jobmodel->setStatus(0);
                $jobmodel->save();
                $response[0]['id'] = $jobmodel->getId();
            }

            $response[0]['job_id_str'] = str_pad((string) $response[0]['id'], 10, '0', STR_PAD_LEFT);
            $jobNo = $response[0]['id'];

            $response[0]['dealer_code'] = $serviceModelObj->getAssignedTo();
            $response[0]['dealer_name'] = $this->_commonHelper->getCustomerNameById($serviceModelObj->getAssignedTo());


            $jobmodel = $this->_jobNoFactory->create()->load($response[0]['id']);
            //$response[0]['current_time'] = $this->_timezone->date()->format('Y-m-d H:i:s');
            $response[0]['current_time'] = $jobmodel->getCreatedAt();

            if ($serviceRequestType == SR_TYPE_PDI) {
                $tractor = $this->_customerTractorFactory->create()->load($serviceModelObj->getTractorId());

                $jobParts['item'] = [];
                $response[0]['engine_number'] = $tractor->getEngineNumber();
                $response[0]['serial_number'] = $tractor->getSerialNumber();
                $response[0]['model'] = $this->_commonHelper->getTractorName($tractor->getMakleId(), $tractor->getModelId());

                if ($jobmodel->getServiceFormId()) {
                    $response[0]['pdi_data'] = $this->_servicePid->create()
                            ->load($jobmodel->getServiceFormId())
                            ->getData();
                } /* else {
                  $response[0]['pdi_data'] = (object) [];
                  } */
                $observations = $this->_serviceObservationsFactory->create()
                        ->getCollection()
                        ->addFieldToSelect(['id', 'observe', 'action'])
                        ->addFieldToFilter('job_no', ['eq' => $response[0]['id']])
                        ->getData();
                if ($observations) {
                    $response[0]['observations'] = $observations;
                }

                //$response[0]['job_parts'] = [];
                //$response[0]['cart_detail'] = [];
                $amounts = $this->getSparePartsTotal($jobNo);
                $serviceJobParts = $this->_serviceJobPartsFactory->create()
                        ->getCollection()
                        ->addFieldToSelect(['part_id', 'qty', 'price', 'cgst', 'sgst', 'igst', 'sub_total'])
                        ->addFieldToFilter('job_no', ['eq' => $jobNo]);

                $serviceJobParts->getSelect()
                        ->joinLeft(['secondTable' => $serviceJobParts->getTable('escorts_spare_parts')], 'main_table.part_id = secondTable.id', ['part_number', 'part_image', 'part_name', 'price_mrp', 'price_dnp', 'cgst AS cgst_rate', 'sgst AS sgst_rate', 'igst AS igst_rate']);

                if ($serviceJobParts->getSize()) {
                    $mediaUrl = $this->_commonHelper->getMediaPath();

                    foreach ($serviceJobParts as $serviceJobPart) {
                        $jobPart = $serviceJobPart->getData();

                        if (!empty($jobPart['part_image'])) {
                            $jobPart['part_image'] = $mediaUrl . $jobPart['part_image'];
                        } else {
                            $jobPart['part_image'] = $mediaUrl . 'wysiwyg/spare_parts/default.jpeg';
                        }

                        $jobPart['price'] = number_format($jobPart['price'], 2, '.', '');
                        $jobPart['cgst'] = number_format($jobPart['cgst'], 2, '.', '');
                        $jobPart['sgst'] = number_format($jobPart['sgst'], 2, '.', '');
                        $jobPart['igst'] = number_format($jobPart['igst'], 2, '.', '');
                        $jobPart['sub_total'] = number_format($jobPart['sub_total'], 2, '.', '');
                        $jobPart['price_mrp'] = number_format($jobPart['price_mrp'], 2, '.', '');
                        $jobPart['price_dnp'] = number_format($jobPart['price_dnp'], 2, '.', '');
                        $jobPart['cgst_rate'] = number_format($jobPart['cgst_rate'], 2, '.', '');
                        $jobPart['sgst_rate'] = number_format($jobPart['sgst_rate'], 2, '.', '');
                        $jobPart['igst_rate'] = number_format($jobPart['igst_rate'], 2, '.', '');
                        $jobParts['item'][] = $jobPart;
                    }

                    $response[0]['job_parts'] = $jobParts;

                    if ($jobmodel->getId()) {
                        $response[0]['job_parts']['others'] = [
                            'total' => number_format($amounts['sub_total'], 2, '.', ''),
                            'cgst' => number_format($amounts['cgst'], 2, '.', ''),
                            'sgst' => number_format($amounts['sgst'], 2, '.', ''),
                            'labour_charge' => number_format((float) $jobmodel->getLabourCharge(), 2, '.', ''),
                            'labour_charge_comment' => $jobmodel->getLabourChargeComment(),
                            'misc_charge' => number_format((float) $jobmodel->getMiscCharge(), 2, '.', ''),
                            'misc_charge_comment' => $jobmodel->getMiscChargeComment(),
                            'misc_charge_type' => $jobmodel->getMiscChargeType(),
                            'grand_total' => number_format((float) $jobmodel->getGrandTotal(), 2, '.', ''),
                            'time_to_fix' => $jobmodel->getTimeToFix()
                        ];
                    }
                }

                $cartDetail = $this->_sparePartsApiFactory->create()->getCartDetail($sdid, $jobNo);

                if (isset($cartDetail[0]['cart_items'])) {
                    $response[0]['cart_detail'] = $cartDetail[0];
                }
            }

            if ($serviceRequestType == SR_TYPE_INSTALLATION) {
                $tractor = $this->_customerTractorFactory->create()->load($serviceModelObj->getTractorId());
                $response[0]['customer_name'] = $this->_commonHelper->getCustomerNameById($tractor->getCustomerId());
                $response[0]['model'] = $this->_commonHelper->getTractorName($tractor->getMakleId(), $tractor->getModelId());
                $response[0]['serial_number'] = $tractor->getSerialNumber();
                $response[0]['engine_number'] = $tractor->getEngineNumber();
                $response[0]['chassis_number'] = $tractor->getChassisNumber();

                $response[0]['fip_no'] = null;
                $response[0]['alternator_make_and_no'] = null;
                $response[0]['battery_make_and_no'] = null;
                $response[0]['tyre_make_n_no'] = null;
                $response[0]['front_l'] = null;
                $response[0]['front_r'] = null;
                $response[0]['rear_l'] = null;
                $response[0]['rear_r'] = null;

                $pdiServices = $this->_postFactory->create()
                        ->getCollection()
                        ->addFieldToSelect([])
                        ->addFieldToFilter('tractor_id', $serviceModelObj->getTractorId())
                        ->addFieldToFilter('service_request_type', ['eq' => 1])
                        ->setPageSize(1);

                if ($pdiServices->getSize()) {
                    $pdiServiceId = $pdiServices->getFirstItem()->getId();

                    $pdiJobs = $this->_jobNoFactory->create()->load($pdiServiceId, 'srid');
                    if ($pdiJobs->getServiceFormId()) {
                        $pdiModel = $this->_servicePid->create()->load($pdiJobs->getServiceFormId());
                        $response[0]['fip_no'] = $pdiModel->getFipNo();
                        $response[0]['alternator_make_and_no'] = $pdiModel->getAlternatorMakeAndNo();
                        $response[0]['battery_make_and_no'] = $pdiModel->getBatteryMakeAndNo();
                        $response[0]['tyre_make_n_no'] = $pdiModel->getTyreMakeNNo();
                        $response[0]['front_l'] = $pdiModel->getFrontL();
                        $response[0]['front_r'] = $pdiModel->getFrontR();
                        $response[0]['rear_l'] = $pdiModel->getRearL();
                        $response[0]['rear_r'] = $pdiModel->getRearR();
                    }
                }

                $response[0]['schedules'] = $this->getServiceRequestSchedules($srid);

                //if ($jobmodel->getServiceFormId()) {
                //    $response[0]['installation_data'] = $this->_serviceInstallation->create()->load($jobmodel->getServiceFormId())->getData();
                //}
            }

            $response[0]['status'] = 1;
            $response[0]['message'] = __('Service Job Number');
        } else {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Wrong service request ID');
        }

        return $response;
    }

    /**
     * @param int $sdid
     * @param int $srid
     * @return mixed
     */
    public function getJobNo($srid) {
        $jobNo = 0;

        $jobModelCollection = $this->_jobNoFactory->create()
                ->getCollection()
                ->addFieldToSelect(['id'])
                ->addFieldToFilter('srid', ['eq' => $srid])
                //->addFieldToFilter('service_request_type', ['eq' => $srType])
                ->setPageSize(1);

        if ($jobModelCollection->getSize()) {
            $jobNo = $jobModelCollection->getFirstItem()->getId();
        }

        return $jobNo;
    }

    /**
     * 
     * @param int $sdid
     * @param int $srid
     * @param mixed $pdiData
     * @param mixed $observations
     * @param mixed $partsData
     * @return mixed
     */
    public function createServiceRequestPdi($sdid, $srid, $pdiData = null, $observations = null, $partsData = null) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong');
        $unavailableParts = [];

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        $serviceModel = $this->_postFactory->create()->load($srid);
        if ($serviceModel->getId()) {
            //$srType = $serviceModel->getServiceRequestType();
            $jobNo = $this->getJobNo($srid);

            if (empty($jobNo)) {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('Job number does not exists');
                return $response;
            }

            $serviceModel->setStatus(SR_STATUS_IN_PROGRESS);
            $jobModel = $this->_jobNoFactory->create()->load($jobNo);

            try {
                if ($jobModel->getStatus()) {
                    $response[0]['status'] = 0;
                    $response[0]['message'] = __('This PDI already created');
                } else {
                    if (!empty($pdiData)) {
                        if ($jobModel->getServiceFormId()) {
                            $modelpdi = $this->_servicePid->create()->load($jobModel->getServiceFormId());
                            $pdiData['id'] = $jobModel->getServiceFormId();
                        } else {
                            $modelpdi = $this->_servicePid->create();
                        }

                        $pdiData['srid'] = $srid;
                        $modelpdi->setData($pdiData);
                        $modelpdi->save();

                        if ($modelpdi->getId()) {
                            //$jobModel = $this->_jobNoFactory->create()->load($jobNo);
                            $jobModel->setServiceFormId($modelpdi->getId());

                            if (!$jobModel->getId()) {
                                $response[0]['status'] = 0;
                                $response[0]['message'] = __('Service request does\'t update job number');
                            } else {
                                $response[0]['status'] = 1;
                                $response[0]['message'] = __('PDI data saved successfully');
                            }
                        }
                    }

                    if (!empty($observations)) {
                        if (count($observations['observation'])) {

                            /* Remove observation */
                            $dataObservationIds = [];
                            foreach ($observations['observation'] as $observation) {
                                if (!empty($observation['id'])) {
                                    $dataObservationIds[] = $observation['id'];
                                }
                            }

                            if (!empty($jobNo)) {
                                $serviceObservation = $this->_serviceObservationsFactory->create()
                                        ->getCollection()
                                        ->addFieldToSelect(['id'])
                                        ->addFieldToFilter('job_no', ['eq' => $jobNo]);

                                if ($serviceObservation->getSize()) {
                                    foreach ($serviceObservation as $observationData) {
                                        $obsId = $observationData->getId();
                                        if (!in_array($obsId, $dataObservationIds)) {
                                            try {
                                                $oservationModel = $this->_serviceObservationsFactory->create()->load($obsId);
                                                if ($oservationModel->getId()) {
                                                    $oservationModel->delete();
                                                }
                                            } catch (Exception $e) {
                                                
                                            }
                                        }
                                    }
                                }
                            }
                            /* Remove observation */


                            foreach ($observations['observation'] as $observation) {
                                if (empty($observation['observe']) || empty($observation['action'])) {
                                    continue;
                                }

                                $serviceObservation = null;
                                $observation['job_no'] = $jobNo;

                                if (!empty($observation['id'])) {
                                    $serviceObservation = $this->_serviceObservationsFactory->create()->load($observation['id']);
                                }

                                if (is_null($serviceObservation)) {
                                    $observation['id'] = null;
                                    $serviceObservation = $this->_serviceObservationsFactory->create();
                                }

                                $serviceObservation->setData($observation);
                                $serviceObservation->save();
                            }

                            $response[0]['status'] = 1;
                            $response[0]['message'] = __('PDI observations saved successfully');
                            $response[0]['observations'] = $this->_serviceObservationsFactory->create()
                                            ->getCollection()
                                            ->addFieldToSelect(['id', 'observe', 'action'])
                                            ->addFieldToFilter('job_no', ['eq' => $jobNo])->getData();
                        }

                        if (!empty($observations['need_replace'])) {
                            //RMA
                            //$serviceModel->setStatus(SR_STATUS_COMPLETED);
                            //$jobModel->setClosedAt($this->_timezone->date()->format('Y-m-d H:i:s'));
                            //$jobModel->setStatus(1);
                            $response[0]['status'] = 1;
                            $response[0]['message'] = __('PDI closed successfully');
                        }
                    }

                    if (!empty($partsData)) {
                        $grandTotal = 0.00;
                        $jobParts['item'] = [];

                        if (!empty($partsData['parts'])) {
                            foreach ($partsData['parts'] as $part) {
                                $netStock = 0;
                                $quantity = 0;

                                if (empty($part['qty'])) {
                                    $part['qty'] = 1;
                                }

                                if (empty($part['part_number'])) {
                                    $response[0]['status'] = 0;
                                    $response[0]['message'] = __('Part Number is missing');
                                    return $response;
                                }

                                $partDetail = $this->_commonHelper->getPartDetailByPartNumber($part['part_number']);

                                if (!$partDetail) {
                                    $unavailableParts[] = $part['part_number'];
                                    continue;
                                }

                                unset($part['part_number']);
                                $part['part_id'] = $partDetail['id'];

                                //Check ETC stock
                                $stock = $this->_sparePartsApiFactory->create()->getEtcPartStock($sdid, $part['part_id']);
                                $bookedQty = $this->_commonHelper->getBookedQuantity($sdid, $jobNo, $part['part_id']);

                                $netStock = $stock - $bookedQty['reserved'];
                                if ($netStock > 0) {
                                    $quantity = $part['qty'] - $netStock;
                                } else {
                                    $quantity = $part['qty'];
                                }

                                $quantity -= $bookedQty['ordered'];

                                if ($quantity > 0) {
                                    $this->_sparePartsApiFactory->create()->addToCartSparePart($sdid, $part['part_id'], $quantity, $jobNo);
                                } else {
                                    $this->_sparePartsApiFactory->create()->removePartFromCart($sdid, $part['part_id'], $jobNo);
                                }

                                if ($partDetail) {
                                    $part['job_no'] = $jobNo;
                                    $part['price'] = $partDetail['price_mrp'];
                                    $part['cgst'] = $this->_commonHelper->getTaxAmount($partDetail['price_mrp'], $partDetail['cgst']);
                                    $part['sgst'] = $this->_commonHelper->getTaxAmount($partDetail['price_mrp'], $partDetail['sgst']);
                                    //$part['igst'] = $this->_commonHelper->getTaxAmount($partDetail['price_mrp'], $partDetail['igst']);
                                    $part['sub_total'] = $part['price'] * $part['qty'];

                                    $serviceJobParts = $this->_serviceJobPartsFactory->create()
                                            ->getCollection()
                                            ->addFieldToFilter('job_no', ['eq' => $jobNo])
                                            ->addFieldToFilter('part_id', ['eq' => $part['part_id']])
                                            ->setPageSize(1);

                                    if ($serviceJobParts->getSize()) {
                                        $part['id'] = $serviceJobParts->getFirstItem()->getId();
                                        $serviceJobPart = $this->_serviceJobPartsFactory->create()->load($part['id']);
                                    } else {
                                        $serviceJobPart = $this->_serviceJobPartsFactory->create();
                                    }

                                    $serviceJobPart->setData($part);
                                    $serviceJobPart->save();
                                }
                            }
                        }

                        //Get Spare Parts amounts
                        $amounts = $this->getSparePartsTotal($jobNo);
                        $grandTotal += $amounts['sub_total'] + $amounts['cgst'] + $amounts['sgst'];

                        if (isset($partsData['labour_charge'])) {
                            $jobModel->setLabourCharge($partsData['labour_charge']);
                        }

                        if ($jobModel->getLabourCharge()) {
                            $grandTotal += $jobModel->getLabourCharge();
                        }

                        if (isset($partsData['misc_charge'])) {
                            $jobModel->setMiscCharge($partsData['misc_charge']);
                        }

                        if (isset($partsData['misc_charge_comment'])) {
                            $jobModel->setMiscChargeComment($partsData['misc_charge_comment']);
                        }

                        if (isset($partsData['misc_charge_type'])) {
                            $jobModel->setMiscChargeType($partsData['misc_charge_type']);
                        }

                        if ($jobModel->getMiscCharge()) {
                            $grandTotal += $jobModel->getMiscCharge();
                        }

                        if (isset($partsData['time_to_fix'])) {
                            $jobModel->setTimeToFix($partsData['time_to_fix']);
                        }

                        $jobModel->setGrandTotal($grandTotal);

                        $response[0]['status'] = 1;

                        if (isset($partsData['status']) && $partsData['status'] > 0) {
                            if ($jobModel->getServiceFormId()) {
                                $serviceModel->setStatus(SR_STATUS_COMPLETED);
                                $jobModel->setClosedAt($this->_timezone->date()->format('Y-m-d H:i:s'));

                                if (isset($partsData['lat'])) {
                                    $jobModel->setLatClose($partsData['lat']);
                                }

                                if (isset($partsData['long'])) {
                                    $jobModel->setLongClose($partsData['long']);
                                }

                                $jobModel->setStatus($partsData['status']);
                                $this->_commonHelper->inactiveJobCart($sdid, $jobNo);

                                switch ($partsData['status']) {
                                    case 1:
                                        $response[0]['message'] = __('PDI closed successfully');
                                        /* Temporary code for testing Start */
                                        $customerId = $serviceModel->getCustomerId();
                                        $tractorId = $serviceModel->getTractorId();
                                        $assignedTo = $serviceModel->getAssignedTo();
                                        $assignedPo = $serviceModel->getAssignedPo();
                                        $this->_commonHelper->createInstallationServieRequest(
                                                $customerId, $tractorId, $assignedTo, $assignedPo
                                        );

                                        /* Create Invoice Payable by Escorts to Service Dealer */


                                        /* -------------------------- ------------------------- */
                                        break;
                                    case 2:
                                        $response[0]['message'] = __('PDI cancelled successfully');
                                        break;
                                }
                            } else {
                                $response[0]['status'] = 0;
                                $response[0]['message'] = __('Please fill PDI form required details first');
                            }
                        } else {
                            $response[0]['message'] = __('Saved successfully');
                        }

                        $serviceJobParts = $this->_serviceJobPartsFactory->create()
                                ->getCollection()
                                ->addFieldToSelect(['part_id', 'qty', 'price', 'cgst', 'sgst', 'igst', 'sub_total'])
                                ->addFieldToFilter('job_no', ['eq' => $jobNo]);

                        $serviceJobParts->getSelect()
                                ->joinLeft(['secondTable' => $serviceJobParts->getTable('escorts_spare_parts')], 'main_table.part_id = secondTable.id', ['part_number', 'part_name', 'part_image', 'price_mrp', 'price_dnp', 'cgst AS cgst_rate', 'sgst AS sgst_rate', 'igst AS igst_rate']);

                        if ($serviceJobParts->getSize()) {
                            $media_url = $this->_commonHelper->getMediaPath();

                            foreach ($serviceJobParts as $serviceJobPart) {
                                $temp = $serviceJobPart->getData();

                                if (!empty($temp['part_image'])) {
                                    $temp['part_image'] = $media_url . $temp['part_image'];
                                } else {
                                    $temp['part_image'] = $media_url . 'wysiwyg/spare_parts/default.jpeg';
                                }

                                $temp['price'] = number_format($temp['price'], 2, '.', '');
                                $temp['cgst'] = number_format($temp['cgst'], 2, '.', '');
                                $temp['sgst'] = number_format($temp['sgst'], 2, '.', '');
                                $temp['igst'] = number_format($temp['igst'], 2, '.', '');
                                $temp['sub_total'] = number_format($temp['sub_total'], 2, '.', '');
                                $temp['price_mrp'] = number_format($temp['price_mrp'], 2, '.', '');
                                $temp['price_dnp'] = number_format($temp['price_dnp'], 2, '.', '');
                                $temp['cgst_rate'] = number_format($temp['cgst_rate'], 2, '.', '');
                                $temp['sgst_rate'] = number_format($temp['sgst_rate'], 2, '.', '');
                                $temp['igst_rate'] = number_format($temp['igst_rate'], 2, '.', '');
                                $jobParts['item'][] = $temp;
                            }

                            $response[0]['job_parts'] = $jobParts;

                            //$jobModel = $this->_jobNoFactory->create()->load($jobNo);
                            if ($jobModel->getId()) {
                                $response[0]['job_parts']['others'] = [
                                    'total' => number_format($amounts['sub_total'], 2, '.', ''),
                                    'cgst' => number_format($amounts['cgst'], 2, '.', ''),
                                    'sgst' => number_format($amounts['sgst'], 2, '.', ''),
                                    'labour_charge' => number_format((float) $jobModel->getLabourCharge(), 2, '.', ''),
                                    'labour_charge_comment' => $jobModel->getLabourChargeComment(),
                                    'misc_charge' => number_format((float) $jobModel->getMiscCharge(), 2, '.', ''),
                                    'misc_charge_comment' => $jobModel->getMiscChargeComment(),
                                    'misc_charge_type' => $jobModel->getMiscChargeType(),
                                    'grand_total' => number_format((float) $jobModel->getGrandTotal(), 2, '.', ''),
                                    'time_to_fix' => $jobModel->getTimeToFix()
                                ];
                            }
                        }

                        $cartDetail = $this->_sparePartsApiFactory->create()->getCartDetail($sdid, $jobNo);
                        //print_r($cartDetail);die;

                        if (isset($cartDetail[0]['cart_items'])) {
                            $response[0]['cart_detail'] = $cartDetail[0];
                        }
                    }

                    $serviceModel->save();
                    $jobModel->save();
                }
            } catch (Exception $ex) {
                
            }
        } else {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Service request does not exists');
        }

        if (count($unavailableParts)) {
            $response[0]['error'] = implode(', ', $unavailableParts) . ' part is not available';
        }

        return $response;
    }

    /**
     * Not in Use
     * Remove PDI observation
     * @param int $sdid
     * @param int $observationId
     * @return mixed
     */
    public function removeObservation($sdid, $observationId) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        try {
            $serviceObservation = $this->_serviceObservationsFactory->create()->load($observationId);

            if ($serviceObservation->getId()) {
                $serviceObservation->delete();
                $response[0]['status'] = 1;
                $response[0]['message'] = __('PDI observation removed successfully');
            } else {
                $response[0]['message'] = __('This PDI observation does not exists');
            }
        } catch (Exception $ex) {
            
        }

        return $response;
    }

    /**
     * @param int $jobNo
     * @return mixed
     */
    public function getSparePartsTotal($jobNo) {
        $response = [
            'sub_total' => 0.00,
            'cgst' => 0.00,
            'sgst' => 0.00
        ];

        try {
            $serviceJobParts = $this->_serviceJobPartsFactory->create()
                    ->getCollection()
                    ->addFieldToSelect(['qty', 'price', 'cgst', 'sgst', 'sub_total'])
                    ->addFieldToFilter('job_no', ['eq' => $jobNo]);
            //->addExpressionFieldToSelect('total', 'SUM({{sub_total}})', 'sub_total')
            //->setPageSize(1);

            if ($serviceJobParts->getSize()) {
                $cgst = 0.00;
                $sgst = 0.00;
                $subTotal = 0.00;

                foreach ($serviceJobParts as $serviceJobPart) {
                    $cgst += $serviceJobPart->getQty() * $serviceJobPart->getCgst();
                    $sgst += $serviceJobPart->getQty() * $serviceJobPart->getSgst();
                    $subTotal += $serviceJobPart->getSubTotal();
                }

                $response = [
                    'sub_total' => $subTotal,
                    'cgst' => $cgst,
                    'sgst' => $sgst
                ];
            }
        } catch (Exception $ex) {
            
        }

        return $response;
    }

    /**
     * @param int $sdid
     * @param int $srid
     * @param int $jobPartId
     * @return mixed
     */
    public function removeJobPart($sdid, $srid, $jobPartId) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        try {
            $jobNo = $this->getJobNo($srid);

            if ($jobNo) {
                $serviceRequest = $this->_postFactory->create()->load($srid);
                if ($serviceRequest) {
                    $serviceRequest->setOtpVerified(0);
                    $response[0]['otp_verified'] = $serviceRequest->getOtpVerified();
                    $serviceRequest->save();
                }

                $jobParts['item'] = [];
                $jobModel = $this->_jobNoFactory->create()->load($jobNo);
                $serviceJobPart = $this->_serviceJobPartsFactory->create()->load($jobPartId);

                if ($serviceJobPart->getId()) {
                    $grandTotal = 0.00;

                    $partId = $serviceJobPart->getPartId();
                    $this->_sparePartsApiFactory->create()
                            ->removePartFromCart($sdid, $partId, $jobNo);
                    $serviceJobPart->delete();

                    //Get Spare Parts amounts
                    $amounts = $this->getSparePartsTotal($jobNo);
                    $grandTotal += $amounts['sub_total'] + $amounts['cgst'] + $amounts['sgst'];

                    if ($jobModel->getId()) {
                        $grandTotal += $jobModel->getLabourCharge();
                        $grandTotal += $jobModel->getMiscCharge();
                    }

                    $jobModel->setGrandTotal($grandTotal);
                    $jobModel->save();

                    $response[0]['status'] = 1;
                    $response[0]['message'] = __('Spare part removed successfully');
                } else {
                    $response[0]['status'] = 0;
                    $response[0]['message'] = __('Spare part item does not exists');
                }

                //$response[0]['job_parts'] = [];
                //$response[0]['cart_detail'] = [];
                $amounts = $this->getSparePartsTotal($jobNo);
                $serviceJobParts = $this->_serviceJobPartsFactory->create()
                        ->getCollection()
                        ->addFieldToSelect(['part_name', 'part_id', 'qty', 'price', 'cgst', 'sgst', 'igst', 'sub_total', 'in_warranty', 'warranty_by', 'is_editable'])
                        ->addFieldToFilter('job_no', ['eq' => $jobNo]);

                $serviceJobParts->getSelect()
                        ->joinLeft(['secondTable' => $serviceJobParts->getTable('escorts_spare_parts')], 'main_table.part_id = secondTable.id', ['part_number', 'part_image', 'price_mrp', 'price_dnp', 'cgst AS cgst_rate', 'sgst AS sgst_rate', 'igst AS igst_rate']);

                if ($serviceJobParts->getSize()) {
                    $mediaUrl = $this->_commonHelper->getMediaPath();

                    foreach ($serviceJobParts as $serviceJobPart) {
                        $temp = $serviceJobPart->getData();

                        if (!empty($temp['part_image'])) {
                            $temp['part_image'] = $mediaUrl . $temp['part_image'];
                        } else {
                            $temp['part_image'] = $mediaUrl . 'wysiwyg/spare_parts/default.jpeg';
                        }

                        $temp['price'] = number_format($temp['price'], 2, '.', '');
                        $temp['cgst'] = number_format($temp['cgst'], 2, '.', '');
                        $temp['sgst'] = number_format($temp['sgst'], 2, '.', '');
                        $temp['igst'] = number_format($temp['igst'], 2, '.', '');
                        $temp['sub_total'] = number_format($temp['sub_total'], 2, '.', '');
                        $temp['price_mrp'] = number_format($temp['price_mrp'], 2, '.', '');
                        $temp['price_dnp'] = number_format($temp['price_dnp'], 2, '.', '');
                        $temp['cgst_rate'] = number_format($temp['cgst_rate'], 2, '.', '');
                        $temp['sgst_rate'] = number_format($temp['sgst_rate'], 2, '.', '');
                        $temp['igst_rate'] = number_format($temp['igst_rate'], 2, '.', '');
                        $jobParts['item'][] = $temp;
                    }

                    $response[0]['job_parts'] = $jobParts;

                    if ($jobModel->getId()) {
                        $response[0]['job_parts']['others'] = [
                            'total' => number_format($amounts['sub_total'], 2, '.', ''),
                            'cgst' => number_format($amounts['cgst'], 2, '.', ''),
                            'sgst' => number_format($amounts['sgst'], 2, '.', ''),
                            'labour_charge' => number_format((float) $jobModel->getLabourCharge(), 2, '.', ''),
                            'labour_charge_comment' => $jobModel->getLabourChargeComment(),
                            'misc_charge' => number_format((float) $jobModel->getMiscCharge(), 2, '.', ''),
                            'misc_charge_comment' => $jobModel->getMiscChargeComment(),
                            'misc_charge_type' => $jobModel->getMiscChargeType(),
                            'grand_total' => number_format($jobModel->getGrandTotal(), 2, '.', ''),
                            'time_to_fix' => $jobModel->getTimeToFix()
                        ];
                    }
                } else {
                    $jobModel->setLabourCharge('');
                    $jobModel->setLabourChargeComment('');
                    $jobModel->setMiscCharge('');
                    $jobModel->setMiscChargeComment('');
                    $jobModel->setMiscChargeType('');
                    $jobModel->setTimeToFix('');
                }

                $jobModel->save();

                $cartDetail = $this->_sparePartsApiFactory->create()->getCartDetail($sdid, $jobNo);

                if (isset($cartDetail[0]['cart_items'])) {
                    $response[0]['cart_detail'] = $cartDetail[0];
                }
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('Job card does not exists');
            }
        } catch (Exception $ex) {
            
        }

        return $response;
    }

    /**
     * @param int $sdid
     * @param int $srid
     * @return mixed     
     */
    public function getServiceRequestPdi($sdid, $srid) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        $serviceModelObj = $this->_postFactory->create()->load($srid);

        if ($serviceModelObj->getServiceRequestType() != SR_TYPE_PDI) {
            $response[0]['message'] = __('Wrong service request type');
            return $response;
        }

        $jobServiceFormId = null;
        $jobCartno = $this->getServiceRequestJobNo($sdid, $serviceModelObj->getServiceRequestType(), $srid);

        if (!empty($jobCartno[0]['id'])) {
            $jobCheck = $this->_jobNoFactory->create()->load($jobCartno[0]['id']);
            $jobServiceFormId = $jobCheck->getServiceFormId();
        }

        if (empty($jobServiceFormId)) {
            $response[0]['message'] = __('PDI isn\'t created');
        } else {
            $modelpdi = $this->_servicePid->create()->load($jobServiceFormId);

            $data[0] = $modelpdi->getData();
            $data[0]['job_card_no'] = $jobCartno[0]['id'];
            $data[0]['dealer_code'] = $serviceModelObj->getAssignedTo();
            $data[0]['dealer_name'] = $this->_commonHelper->getCustomerNameById($serviceModelObj->getAssignedTo());

            if ($serviceModelObj->getTractorId()) {
                $tractor = $this->_customerTractorFactory->create()->load($serviceModelObj->getTractorId());
                if ($tractor) {
                    $data[0]['model'] = $this->_commonHelper->getTractorName($tractor->getMakeId(), $tractor->getModelId());
                    $data[0]['serial_number'] = $tractor->getSerialNumber();
                    $data[0]['engine_number'] = $tractor->getEngineNumber();
                } else {
                    $data[0]['model'] = null;
                    $data[0]['serial_number'] = null;
                    $data[0]['engine_number'] = null;
                }
            } else {
                $data[0]['model'] = null;
                $data[0]['serial_number'] = null;
                $data[0]['engine_number'] = null;
            }

            $response[0]['pdi_data'] = $data;
            $response[0]['observations'] = $this->_serviceObservationsFactory->create()
                    ->getCollection()
                    ->addFieldToSelect(['id', 'observe', 'action'])
                    ->addFieldToFilter('job_no', ['eq' => $jobCartno[0]['id']])
                    ->getData();

            $response[0]['job_parts'] = [];
            $response[0]['cart_detail'] = [];

            $serviceJobParts = $this->_serviceJobPartsFactory->create()
                    ->getCollection()
                    ->addFieldToSelect(['part_id', 'qty', 'price', 'cgst', 'sgst', 'igst', 'sub_total'])
                    ->addFieldToFilter('job_no', ['eq' => $jobCartno[0]['id']]);

            $serviceJobParts->getSelect()
                    ->joinLeft(['secondTable' => $serviceJobParts->getTable('escorts_spare_parts')], 'main_table.part_id = secondTable.id', ['part_number', 'part_name', 'price_mrp', 'price_dnp', 'cgst AS cgst_rate', 'sgst AS sgst_rate', 'igst AS igst_rate']);

            if ($serviceJobParts->getSize()) {
                $jobParts['item'] = [];
                $amounts = $this->getSparePartsTotal($jobCartno[0]['id']);

                foreach ($serviceJobParts as $serviceJobPart) {
                    $jobParts['item'][] = $serviceJobPart->getData();
                }

                $response[0]['job_parts'] = $jobParts;

                if ($jobCheck->getId()) {
                    $response[0]['job_parts']['others'] = [
                        'total' => number_format($amounts['sub_total'], 2, '.', ''),
                        'cgst' => number_format($amounts['cgst'], 2, '.', ''),
                        'sgst' => number_format($amounts['sgst'], 2, '.', ''),
                        'labour_charge' => number_format((float) $jobCheck->getLabourCharge(), 2, '.', ''),
                        'labour_charge_comment' => $jobCheck->getLabourChargeComment(),
                        'misc_charge' => number_format((float) $jobCheck->getMiscCharge(), 2, '.', ''),
                        'misc_charge_comment' => $jobCheck->getMiscChargeComment(),
                        'misc_charge_type' => $jobCheck->getMiscChargeType(),
                        'grand_total' => number_format($jobCheck->getGrandTotal(), 2, '.', ''),
                        'time_to_fix' => $jobCheck->getTimeToFix()
                    ];
                }
            }

            $cartDetail = $this->_sparePartsApiFactory->create()->getCartDetail($sdid, $jobCartno[0]['id']);

            if (isset($cartDetail[0]['cart_items'])) {
                $response[0]['cart_detail'] = $cartDetail[0];
            }

            $response[0]['status'] = 1;
            $response[0]['message'] = __('View PDI data');
        }

        return $response;
    }

    /**
     * @param int $sdid
     * @param int $srid
     * @return mixed
     */
    public function sendInstallationOtp($sdid, $srid) {
        $response = [];
        $response[0] = ['status' => 0];
        $response[0]['message'] = __('Something went wrong please try again later');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        $serviceRequest = $this->_postFactory->create()->load($srid);

        if ($serviceRequest->getId() && !in_array($serviceRequest->getStatus(), [SR_STATUS_COMPLETED, SR_STATUS_REJECTED, SR_STATUS_CANCELLED])) {
            if ($serviceRequest->getServiceRequestType() != SR_TYPE_INSTALLATION) {
                return $response;
            }

            $customer_data = $this->_customerFactory->create()
                    ->setWebsiteId($this->_storeManager->getStore()->getWebsiteId())
                    ->load($serviceRequest->getCustomerId());

            if (!empty($customer_data->getId())) {
                $mobileNumber = $customer_data->getMobileNumber();
                $otp = $this->_commonHelper->generateOtp();

                try {
                    $serviceRequest->setOtpValue($otp);
                    $serviceRequest->setOtpCreatedAt($this->_timezone->scopeTimeStamp());
                    $serviceRequest->save();

                    $tat = $this->_smsNotificationHelper->getInstallationCloseTat();
                    $params = [
                        'otp' => $otp,
                        'tat' => $tat
                    ];
                    $this->_smsNotificationHelper->sendInstallationCloseOtp($mobileNumber, $params);

                    $response[0]['status'] = 1;
                    $response[0]['message'] = __('We have sent an OTP on Customer registered mobile number');
                } catch (Exception $ex) {
                    $response[0]['status'] = 0;
                    $response[0]['message'] = __('Something went wrong');
                }
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('Customer details not available');
            }
        } else {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Can not generate OTP for this Service Request');
        }

        return $response;
    }

    /**
     * @param int $sdid
     * @param int $srid
     * @param string $otp
     * @return mixed
     */
    public function verifyInstallationOtp($sdid, $srid, $otp) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong please try again later');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        $serviceRequest = $this->_postFactory->create()->load($srid);

        if ($serviceRequest->getCustomerId()) {
            if ($serviceRequest->getServiceRequestType() != SR_TYPE_INSTALLATION) {
                return $response;
            }

            $systemOtp = is_null($serviceRequest->getOtpValue()) ? '' : $serviceRequest->getOtpValue();
            $time = is_null($serviceRequest->getOtpCreatedAt()) ? '' : $serviceRequest->getOtpCreatedAt();
            $diff = round(abs($this->_timezone->scopeTimeStamp() - $time) / 60);
            $tat = $this->_smsNotificationHelper->getInstallationCloseTat();

            if ($time && $systemOtp) {
                if ($diff <= $tat) {
                    if ($systemOtp === trim($otp)) {
                        try {
                            $serviceRequest->setOtpValue('');
                            $serviceRequest->setOtpCreatedAt('');
                            $serviceRequest->setOtpVerified(1);
                            $serviceRequest->save();
                            $response[0]['status'] = 1;
                            $response[0]['message'] = __('Verified');
                        } catch (Exception $ex) {
                            $response[0]['status'] = 0;
                            $response[0]['message'] = __('Something went wrong');
                        }
                    } else {
                        $response[0]['status'] = 0;
                        $response[0]['message'] = __('OTP is Wrong');
                    }
                } else {
                    $response[0]['status'] = 0;
                    $response[0]['message'] = __('OTP has been expired');
                }
            }
        }


        return $response;
    }

    /**
     * @param int $sdid
     * @param int $serviceRequestInstallation
     * @return mixed
     */
    public function createServiceRequestInstallation($sdid, $serviceRequestInstallation) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong please try again later');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        $srIdValue = null;
        $jobNoValue = null;


        $srId = array_key_exists('srid', $serviceRequestInstallation);
        if ($srId) {
            $srIdValue = $serviceRequestInstallation['srid'];
        }

        if ($srIdValue) {
            //check otp verified status of Service Request
            $serviceRequest = $this->_postFactory->create()->load($srIdValue);
            if (!$serviceRequest->getOtpVerified()) {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('OTP is not Verified');
                goto out;
            }

            $jobNoValue = $this->getJobNo($srIdValue);

            if (!$jobNoValue) {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('Job Number is required');
                goto out;
            }

            //$jobcheckServiceFormId = $jobCheck->getServiceFormId();
            $jobmodel = $this->_jobNoFactory->create()->load($jobNoValue);

            //$jobcheckServiceFormId = $jobmodel->getServiceFormId();
            //if ($jobcheckServiceFormId) {
            if ($jobmodel->getStatus()) {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('Installation already created');
                goto out;
            }

            $imageFirstIndex = array_key_exists('image_first', $serviceRequestInstallation);
            if ($imageFirstIndex) {
                $imageName = $this->_commonHelper->saveImage("/customer/etc-{$sdid}/", "installation", $serviceRequestInstallation['image_first'], $sdid, 'first-' . $srId);
                $serviceRequestInstallation['image_first'] = "customer/etc-{$sdid}/installation/{$imageName}";
            }

            $imageSecondIndex = array_key_exists('image_second', $serviceRequestInstallation);
            if ($imageSecondIndex) {
                $imageName = $this->_commonHelper->saveImage("/customer/etc-{$sdid}/", "installation", $serviceRequestInstallation['image_second'], $sdid, 'second-' . $srId);
                $serviceRequestInstallation['image_second'] = "customer/etc-{$sdid}/installation/{$imageName}";
            }

            try {
                $modelInstallation = $this->_serviceInstallation->create()->load($srIdValue, 'srid');

                if (empty($modelInstallation)) {
                    $modelInstallation = $this->_serviceInstallation->create();
                }

                $modelInstallation->setData($serviceRequestInstallation);
                $modelInstallation->setCreatedAt($this->_timezone->date()->format('Y-m-d H:i:s'));
                $modelInstallation->save();

                if ($modelInstallation->getId()) {
                    $model = $this->_postFactory->create()->load($serviceRequestInstallation['srid']);
                    $model->setStatus(SR_STATUS_COMPLETED);
                    $model->save();

                    if (!$model->getId()) {
                        $response[0]['status'] = 0;
                        $response[0]['message'] = __('Service request does\'t update status');
                        goto out;
                    }

                    $jobmodel->setServiceFormId($modelInstallation->getId());
                    $jobmodel->setClosedAt($this->_timezone->date()->format('Y-m-d H:i:s'));
                    $jobmodel->setLatClose($serviceRequestInstallation['lat']);
                    $jobmodel->setLongClose($serviceRequestInstallation['long']);
                    $jobmodel->setStatus(1);
                    $jobmodel->save();

                    if (!$jobmodel->getId()) {
                        $response[0]['status'] = 0;
                        $response[0]['message'] = __('Service request does\'t update job number');
                        goto out;
                    }

                    $tractor = $this->_customerTractorFactory->create()->load($serviceRequest->getTractorId());
                    if ($tractor->getId()) {
                        $tractor->setStatus(1);
                        $tractor->setDeliveryDate($this->_timezone->date()->format('Y-m-d H:i:s'));
                        $tractor->save();
                    }

                    $mobileNumber = $this->_commonHelper->getCustomerMobileByID($serviceRequest->getCustomerId());
                    $params = [
                        'name' => $this->_commonHelper->getCustomerNameById($serviceRequest->getCustomerId())
                    ];

                    $this->_smsNotificationHelper->sendInstallationCompleteSms($mobileNumber, $params);

                    $response[0]['status'] = 1;
                    $response[0]['message'] = __('Installation certificate successfully saved');
                }
            } catch (Exception $ex) {
                
            }
        } else {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Service request ID is required');
        }

        out:
        return $response;
    }

    /**
     * @param int $sdid
     * @param int $serviceRequestType
     * @param int $srid
     * @return mixed
     */
    public function getServiceRequestInstallation($sdid, $serviceRequestType, $srid) {
        $data = [];
        $data[0]['status'] = 0;
        $data[0]['message'] = __('Something went wrong please try again later');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $data[0]['status'] = 0;
            $data[0]['message'] = __('You aren\'t authorized user');
            return $data;
        }

        $jobServiceFormId = null;
        $jobCartno = $this->getServiceRequestJobNo($sdid, $serviceRequestType, $srid);

        if (!empty($jobCartno[0]['id'])) {
            $jobCheck = $this->_jobNoFactory->create()->load($jobCartno[0]['id']);
            $jobServiceFormId = $jobCheck->getServiceFormId();
        }

        if (!$jobServiceFormId) {
            $data[0]['status'] = 0;
            $data[0]['message'] = __('Installation isn\'t created');
        } else {
            $modelpdi = $this->_serviceInstallation->create()->load($jobServiceFormId);
            $serviceModelObj = $this->_postFactory->create()->load($srid);

            $data[0] = $modelpdi->getData();
            $data[0]['job_card_no'] = $jobCartno[0]['id'];

            $data[0]['fip_no'] = null;
            $data[0]['alternator_make_and_no'] = null;
            $data[0]['battery_make_and_no'] = null;
            $data[0]['tyre_make_n_no'] = null;
            $data[0]['front_l'] = null;
            $data[0]['front_r'] = null;
            $data[0]['rear_l'] = null;
            $data[0]['rear_r'] = null;

            $pdiServices = $this->_postFactory->create()
                    ->getCollection()
                    ->addFieldToSelect([])
                    ->addFieldToFilter('tractor_id', $serviceModelObj->getTractorId())
                    ->addFieldToFilter('service_request_type', ['eq' => 1])
                    ->setPageSize(1);

            if ($pdiServices->getSize()) {
                $pdiServiceId = $pdiServices->getFirstItem()->getId();

                $pdiJobs = $this->_jobNoFactory->create()->load($pdiServiceId, 'srid');
                if ($pdiJobs->getServiceFormId()) {
                    $pdiModel = $this->_servicePid->create()->load($pdiJobs->getServiceFormId());
                    $data[0]['fip_no'] = $pdiModel->getFipNo();
                    $data[0]['alternator_make_and_no'] = $pdiModel->getAlternatorMakeAndNo();
                    $data[0]['battery_make_and_no'] = $pdiModel->getBatteryMakeAndNo();
                    $data[0]['tyre_make_n_no'] = $pdiModel->getTyreMakeNNo();
                    $data[0]['front_l'] = $pdiModel->getFrontL();
                    $data[0]['front_r'] = $pdiModel->getFrontR();
                    $data[0]['rear_l'] = $pdiModel->getRearL();
                    $data[0]['rear_r'] = $pdiModel->getRearR();
                }
            }

            if (!empty($jobCartno[0]['schedules'])) {
                $data[0]['schedules'] = $jobCartno[0]['schedules'];
            }

            $data[0]['customer_name'] = $this->_commonHelper->getCustomerNameById($serviceModelObj->getCustomerId());
            $data[0]['media_url'] = $this->_commonHelper->getMediaPath();

            if ($serviceModelObj->getTractorId()) {
                $tractor = $this->_customerTractorFactory->create()->load($serviceModelObj->getTractorId());
                if ($tractor) {
                    $data[0]['model'] = $this->_commonHelper->getTractorName($tractor->getMakeId(), $tractor->getModelId());
                    $data[0]['serial_number'] = $tractor->getSerialNumber();
                    $data[0]['engine_number'] = $tractor->getEngineNumber();
                    $data[0]['chasis_number'] = $tractor->getChassisNumber();
                } else {
                    $data[0]['model'] = null;
                    $data[0]['serial_number'] = null;
                    $data[0]['engine_number'] = null;
                    $data[0]['chasis_number'] = null;
                }
            } else {
                $data[0]['model'] = null;
                $data[0]['serial_number'] = null;
                $data[0]['engine_number'] = null;
                $data[0]['chasis_number'] = null;
            }

            $data[0]['status'] = 1;
            $data[0]['message'] = __('View Installation');
        }

        return $data;
    }

    /**
     * Service Request Escalate
     * @param int $sdid
     * @param int $srid
     * @param string $reasons
     * @param string $comment
     * @return mixed
     */
    public function serviceRequestEscalate($sdid, $srid, $reasons, $comment) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong please try again later');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        $serviceRequest = $this->_postFactory->create()->load($srid);

        if ($serviceRequest->getId()) {
            if ($serviceRequest->getAssignedTo() != $sdid) {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('You aren\'t authorized user');
                return $response;
            }

            if ($this->_helperData->doServiceRequestEscalation($serviceRequest, false, $reasons, $comment)) {
                $response[0]['status'] = 1;
                $response[0]['message'] = __('Successfully escalated');
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('You can not escalate this Service Request');
            }
        } else {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Service Request does not exists');
        }
        return $response;
    }

    /**
     * Service Request Accept
     * @param int $sdid
     * @param int $srid
     * @return mixed     
     */
    public function serviceRequestAccept($sdid, $srid) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong please try again later');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        $serviceRequest = $this->_postFactory->create()->load($srid);
        if ($serviceRequest->getId()) {
            if ($serviceRequest->getAssignedTo() != $sdid) {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('You aren\'t authorized user');
                return $response;
            }

            $serviceRequest->setAcceptedAt($this->_timezone->date()->format('Y-m-d H:i:s'));
            $serviceRequest->setAcceptStatus(1);
            $serviceRequest->setStatus(SR_STATUS_IN_PROGRESS);
            $serviceRequest->save();

            $response[0]['status'] = 1;
            $response[0]['message'] = __('Service request accepted successfully');
        } else {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Service request does not exists');
        }

        return $response;
    }

    /**
     * @param int $sdid
     * @param int $srid
     * @param string $reasons
     * @param string $comment
     * @return mixed
     */
    public function serviceRequestReject($sdid, $srid, $reasons, $comment = null) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong please try again later');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        $serviceRequest = $this->_postFactory->create()->load($srid);
        if ($serviceRequest->getId()) {
            if ($serviceRequest->getAssignedTo() != $sdid) {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('You aren\'t authorized user');
                return $response;
            }

            if ($this->_helperData->doServiceRequestReject($serviceRequest, $reasons, $comment)) {
                $response[0]['status'] = 1;
                $response[0]['message'] = __('Service request rejected successfully');
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('You can not reject this Service Request');
            }
        } else {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Service request does not exists');
        }

        return $response;
    }

    /**
     * @param int $sdid
     * @param int $srid
     * @param string $datetime
     * @param string $comment
     * @return mixed
     */
    public function serviceRequestSchedule($sdid, $srid, $datetime, $comment = null) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong please try again later');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        try {
            $serviceRequest = $this->_postFactory->create()->load($srid);
            if ($serviceRequest->getId()) {
                if ($serviceRequest->getAssignedTo() != $sdid) {
                    $response[0]['status'] = 0;
                    $response[0]['message'] = __('You aren\'t authorized user');
                    return $response;
                }

                $serviceSchedule = $this->_serviceScheduleFactory->create();
                $serviceSchedule->setSrid($srid);
                $serviceSchedule->setScheduledFor($datetime);
                $serviceSchedule->setScheduledAt($this->_timezone->date()->format('Y-m-d H:i:s'));

                if ($comment) {
                    $serviceSchedule->setComment($comment);
                }

                $serviceSchedule->save();
                $serviceRequest->setStatus(SR_STATUS_SCHEDULED);
                $serviceRequest->save();

                $response[0]['status'] = 1;
                $response[0]['message'] = __('Service request scheduled successfully');
                $response[0]['schedules'] = $this->getServiceRequestSchedules($srid);
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('Service request does not exists');
            }
        } catch (Exception $ex) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Something went wrong');
        }

        return $response;
    }

    /**
     * @param int $sdid
     * @param int $srid
     * @return mixed
     */
    public function serviceRequestSchedules($sdid, $srid) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong please try again later');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        try {
            $serviceRequest = $this->_postFactory->create()->load($srid);
            if ($serviceRequest->getId()) {
                if ($serviceRequest->getAssignedTo() != $sdid) {
                    $response[0]['status'] = 0;
                    $response[0]['message'] = __('You aren\'t authorized user');
                    return $response;
                }

                $response[0]['status'] = 1;
                $response[0]['message'] = __('Service request schedules list');
                $response[0]['schedules'] = $this->getServiceRequestSchedules($srid);
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('Service request does not exists');
            }
        } catch (Exception $ex) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Something went wrong');
        }

        return $response;
    }

    /**
     * @param int $srid
     * @return mixed
     */
    public function getServiceRequestSchedules($srid) {
        $response = [];
        $serviceSchedules = $this->_serviceScheduleFactory->create()
                ->getCollection()
                ->addFieldToFilter('srid', ['eq' => $srid])
                ->setOrder('id', 'DESC');
        if ($serviceSchedules->getSize()) {
            foreach ($serviceSchedules as $serviceSchedule) {
                $response[] = [
                    'id' => $serviceSchedule->getId(),
                    'scheduled_at' => $serviceSchedule->getScheduledAt(),
                    'scheduled_for' => $serviceSchedule->getScheduledFor(),
                    'comment' => $serviceSchedule->getComment()
                ];
            }
        }
        return $response;
    }

    /**
     * @param int $sdid
     * @return mixed
     * @throws \Magento\Framework\Webapi\Exception
     */
    public function getServiceRequestOptions($sdid) {
        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }

        $serviceOptionsCollection = $this->_serviceOpsions->create()->getCollection();
        $collect = [];
        foreach ($serviceOptionsCollection as $key => $item) {
            $collect[$key]['id'] = $item->getId();
            $collect[$key]['value'] = $item->getValue();
        }

        return $collect;
    }

    /**
     * @param int $sdid
     * @return mixed
     * @throws \Magento\Framework\Webapi\Exception
     */
    public function getServiceRequestServiceType($sdid) {
        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }

        $serviceTypeCollection = $this->_serviceTypeFactory->create()->getCollection();

        $collect = [];
        foreach ($serviceTypeCollection as $key => $item) {
            $collect[$key]['id'] = $item->getId();
            $collect[$key]['value'] = $item->getValue();
        }
        return $collect;
    }

    /**
     * @param int $sdid
     * @return mixed
     * @throws \Magento\Framework\Webapi\Exception
     */
    public function getServiceRequestServiceIssues($sdid) {
        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }

        $serviceIssuesCollection = $this->_serviceIssuesFactory->create()->getCollection();

        $collect = [];
        foreach ($serviceIssuesCollection as $key => $item) {
            $collect[$key]['id'] = $item->getId();
            $collect[$key]['value'] = $item->getValue();
        }
        return $collect;
    }

}
