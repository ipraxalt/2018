<?php

namespace Escorts\ServiceRequest\Model\Plugin;

use Magento\Authorization\Model\UserContextInterface;
use Magento\Sales\Model\Order;

class Authorization extends \Magento\Sales\Model\ResourceModel\Order\Plugin\Authorization {

    protected $_commonHelper;
    protected $_request;

    /**
     * @param UserContextInterface $userContext
     */
    public function __construct(
    UserContextInterface $userContext, \Escorts\Common\Helper\Data $commonHelper, \Magento\Framework\App\RequestInterface $request
    ) {
        $this->userContext = $userContext;
        $this->_commonHelper = $commonHelper;
        $this->_request = $request;
        parent::__construct($userContext);
    }

    /**
     * Checks if order is allowed for current customer
     *
     * @param \Magento\Sales\Model\Order $order
     * @return bool
     */
    protected function isAllowed(Order $order) {

        if ($this->_commonHelper->isEtcToken($this->_request->getHeader('Authorization'))) {
            return true;
        }

        return $this->userContext->getUserType() == UserContextInterface::USER_TYPE_CUSTOMER ? $order->getCustomerId() == $this->userContext->getUserId() : true;
    }

}
