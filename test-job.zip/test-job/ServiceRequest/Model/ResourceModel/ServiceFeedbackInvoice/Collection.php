<?php

/*
 * Escorts
 */

namespace Escorts\ServiceRequest\Model\ResourceModel\ServiceFeedbackInvoice;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection {

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct() {
        $this->_init('Escorts\ServiceRequest\Model\ServiceFeedbackInvoice', 'Escorts\ServiceRequest\Model\ResourceModel\ServiceFeedbackInvoice');
    }

}
