<?php

namespace Escorts\ServiceRequest\Model\ResourceModel\ServicePdi;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Escorts\ServiceRequest\Model\ServicePdi', 'Escorts\ServiceRequest\Model\ResourceModel\ServicePdi');
    }
}
