<?php

/*
 * Escorts
 */

namespace Escorts\ServiceRequest\Model\ResourceModel;

class ServiceJobNo extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb {

    /**
     * Model Initialization
     *
     * @return void
     */
    protected function _construct() {
        $this->_init('escorts_service_job_no', 'id');
    }

}
