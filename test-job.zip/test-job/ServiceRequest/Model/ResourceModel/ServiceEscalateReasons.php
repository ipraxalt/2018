<?php

/*
 * Escorts
 */

namespace Escorts\ServiceRequest\Model\ResourceModel;

class ServiceEscalateReasons extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb {

    /**
     * Model Initialization
     *
     * @return void
     */
    protected function _construct() {
        $this->_init('escorts_sr_escalate_reasons', 'id');
    }

}
