<?php
/**
 * Copyright © 2015 Escorts. All rights reserved.
 */
namespace Escorts\ServiceRequest\Model\ResourceModel;

/**
 * CustomerTractor resource
 */
class CustomerTractor extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('escorts_customer_tractor', 'tractor_id');
    }

  
}
