<?php

/*
 * Escorts
 */

namespace Escorts\ServiceRequest\Model\ResourceModel\ServiceJobParts;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection {

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct() {
        $this->_init('Escorts\ServiceRequest\Model\ServiceJobParts', 'Escorts\ServiceRequest\Model\ResourceModel\ServiceJobParts');
    }

}
