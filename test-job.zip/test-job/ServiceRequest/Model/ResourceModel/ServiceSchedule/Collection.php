<?php

/*
 * Escorts
 */

namespace Escorts\ServiceRequest\Model\ResourceModel\ServiceSchedule;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection {

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct() {
        $this->_init('Escorts\ServiceRequest\Model\ServiceSchedule', 'Escorts\ServiceRequest\Model\ResourceModel\ServiceSchedule');
    }

}
