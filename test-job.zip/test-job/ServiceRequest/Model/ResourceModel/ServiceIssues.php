<?php

namespace Escorts\ServiceRequest\Model\ResourceModel;

class ServiceIssues extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Model Initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('escorts_service_issues', 'id');
    }
}
