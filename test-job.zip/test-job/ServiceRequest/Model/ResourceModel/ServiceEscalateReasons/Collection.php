<?php

/*
 * Escorts
 */

namespace Escorts\ServiceRequest\Model\ResourceModel\ServiceEscalateReasons;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection {

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct() {
        $this->_init('Escorts\ServiceRequest\Model\ServiceEscalateReasons', 'Escorts\ServiceRequest\Model\ResourceModel\ServiceEscalateReasons');
    }

}
