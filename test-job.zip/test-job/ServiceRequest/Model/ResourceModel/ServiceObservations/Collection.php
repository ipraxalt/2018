<?php

/*
 * Escorts
 */

namespace Escorts\ServiceRequest\Model\ResourceModel\ServiceObservations;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection {

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct() {
        $this->_init('Escorts\ServiceRequest\Model\ServiceObservations', 'Escorts\ServiceRequest\Model\ResourceModel\ServiceObservations');
    }

}
