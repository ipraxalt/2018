<?php

/*
 * Escorts
 */

namespace Escorts\ServiceRequest\Model;

class ServiceRejectReasons extends \Magento\Framework\Model\AbstractModel {

    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct() {
        parent::_construct();
        $this->_init('Escorts\ServiceRequest\Model\ResourceModel\ServiceRejectReasons');
    }

}
