<?php

/*
 * Escorts
 */

namespace Escorts\ServiceRequest\Model;

class ServiceObservations extends \Magento\Framework\Model\AbstractModel {

    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct() {
        parent::_construct();
        $this->_init('Escorts\ServiceRequest\Model\ResourceModel\ServiceObservations');
    }

}
