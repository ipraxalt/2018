var config = {
    paths: {
        "jquery.inputmask": "Escorts_ServiceRequest/js/jquery.inputmask.bundle.min"
    },

    shim: {
        'jquery.inputmask': {
            'deps': ['jquery']
        }
    }
};