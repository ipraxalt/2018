define([
    'ko',
    'jquery',
    'uiComponent',
    'mage/url',
    'mage/storage',
    'mage/translate',
    'jquery.inputmask'
], function (ko, $, Component, urlBuilder, storage, $t, inputmask) {
    'use strict';
    //var id=1;

    return Component.extend({
        brandOptions: ko.observableArray([]),
        selectedBrand: ko.observable([]),
        manufactureYear: ko.observableArray([]),
        selectedYear: ko.observableArray([]),
        modelOption: ko.observableArray([]),
        selectedModel: ko.observableArray([]),
        serial_number: ko.observableArray([]),
        registration_no: ko.observableArray([]),

        initialize: function () {
            this._super();
            var self = this;
            $('#add-new-div .loading-mask').show();
            var token = $('#ctxtkn').val();

            /****************************************/
            var brands;
            var serviceUrl = 'rest/V1/escorts/get-all-make';
            var url = urlBuilder.build(serviceUrl);

            $.ajax({
                showLoader: true,
                type: 'GET',
                url: url,
                dataType: 'json',
                headers: {'Authorization': 'Bearer ' + token},
                async: false,
            }).done(function (response) {
                brands = response[0].make_master;

            }).fail(function (response) {
                console.log(response);
            });
            this.brandOptions = brands;

            /*****************************************/
            var responseyears;
            var url = urlBuilder.build('tractorexchange/year/index');
            jQuery.ajax({
                showLoader: true,
                type: 'post',
                dataType: 'json',
                url: url,
                async: false,
                success: function (data) {
                    responseyears = data;
                }
            });

            this.manufactureYear = responseyears;
            setTimeout(function () {
                $('#add-new-div .loading-mask').hide();
            }, 1500);

            /****************************************/
            return this;
        },

        changeBrand: function () {
            var self = this;
            $('#add-new-div .loading-mask').show();
            if (self.selectedBrand != undefined) {
                var modelurl = urlBuilder.build('servicerequest/tractor/model');

                $.ajax({
                    showLoader: true,
                    type: 'post',
                    data: {data: this.selectedBrand},
                    dataType: 'json',
                    url: modelurl,
                    async: false,
                    success: function (data) {
                        setTimeout(function () {
                            $('#add-new-div .loading-mask').hide();
                        }, 1500);
                        $('#model option').remove();
                        $.each(data, function (i, value) {
                            $('#model').append($('<option>').text(value.model_name).attr('value', value.model_master_id));
                        });
                    }
                });
            } else {
                setTimeout(function () {
                    $('#add-new-div .loading-mask').hide();
                }, 1500);
                $('#model option').remove();
            }
        },

        addTractor: function () {
            var token = $('#ctxtkn').val();
            var serviceUrl = urlBuilder.build('rest/V1/escorts/addnew-tractor');
            $('#add-new-div .loading-mask').show();

            var ajaxValue = {
                "new_tractor_request": {
                    "make_id": $('#brand').val(),
                    "model_id": $('#model').val(),
                    "manufacturing_year": $('#year').val(),
                    "serial_number": $('#serial_number').val(),
                    "registration_no": $('#registration_no').val()
                }
            };

            $.ajax({
                /*showLoader: true,*/
                type: 'POST',
                url: serviceUrl,
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify(ajaxValue),
                headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token},
                async: false,
                cache: false
            }).done(function (response) {
                setTimeout(function () {
                    $('#add-new-div .loading-mask').hide();
                }, 1500);
                console.log(response[0].message);
                console.log(response[0].status);
                $('#edit_tractor_msg .messages').remove();
                if (response[0].status == 1) {
                    $('#edit_tractor_msg').show();
                    $("#edit_tractor_msg").append("<div class=\"messages\"><div class=\"message message-success success\"><div data-ui-id=\"messages-message-success\">" + response[0].message + "</div></div></div>");
                    setTimeout(function () {
                        $("#edit_tractor_msg").hide();
                    }, 3000);
                }
                if (response[0].status == 0) {
                    $('#edit_tractor_msg').show();
                    $("#edit_tractor_msg").append("<div class=\"messages\"><div class=\"message message-error error\"><div data-ui-id=\"messages-message-error\">" + response[0].message + "</div></div></div>");
                    setTimeout(function () {
                        $("#edit_tractor_msg").hide();
                    }, 3000);
                }
            }).fail(function (response) {
                console.log('fail');
                setTimeout(function () {
                    $('#add-new-div .loading-mask').hide();
                }, 1500);
            });
        },

    });
});