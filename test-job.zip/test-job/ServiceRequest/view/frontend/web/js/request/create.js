define([
    'ko',
    'jquery',
    'uiComponent',
    'mage/url',
    'mage/storage',
    'mage/translate',
    'mage/validation',
    'jquery.inputmask'
], function (ko, $, Component, urlBuilder, storage, $t, inputmask) {
    'use strict';

    return Component.extend({
        brandOptions: ko.observableArray([]),
        selectedBrand: ko.observable([]),
        manufactureYear: ko.observableArray([]),
        selectedYear: ko.observableArray([]),
        modelOption: ko.observableArray([]),
        selectedModel: ko.observableArray([]),
        serial_number: ko.observableArray([]),
        registration_no: ko.observableArray([]),
        radioValue: ko.observable('my_tractor'),
        notractor: ko.observable('display:none;color: #E71319;'),
        tractorList: ko.observableArray([]),
        addressList: ko.observableArray([]),
        comment: ko.observableArray([]),

        initialize: function () {
            this._super();
            var self = this;
            var token = $('#ctxtkn').val();

            /****************************************/
            var url = urlBuilder.build('rest/V1/escorts/customer-tractors');
            // var editUrl = urlBuilder.build('servicerequest/tractor/edit/tractor_id/');

            $.ajax({
                showLoader: true,
                type: 'GET',
                url: url,
                dataType: 'json',
                //headers: {'Authorization': 'Bearer ' + token},
            }).done(function (response) {
                if (response[0].status) {
                    if (response[0].tractors) {
                        for (var i = 0; i < response[0].tractors.length; i++) {
                            self.tractorList.push(response[0].tractors[i]);
                        }
                    } else {
                        self.notractor = 'display:block;color: #E71319;';
                    }

                    if (response[0].address) {
                        for (var i = 0; i < response[0].address.length; i++) {
                            //console.log(response[0].address[i]);
                            self.addressList.push(response[0].address[i]);
                        }
                    }
                } else if (response[0].address) {
                    for (var i = 0; i < response[0].address.length; i++) {
                        //console.log(response[0].address[i]);
                        self.addressList.push(response[0].address[i]);
                    }
                } else {
                    $('#list-div').html(response[0].message);
                }
            }).fail(function (response) {

            });
            /********************************************/

            $("#createRequest .loading-mask").show();
            var brands;
            var url = urlBuilder.build('rest/V1/escorts/get-all-make');

            $.ajax({
                // showLoader: true,
                type: 'GET',
                url: url,
                dataType: 'json',
                //headers: {'Authorization': 'Bearer ' + token},
                async: false
            }).done(function (response) {
                brands = response[0].make_master;
                setTimeout(function () {
                    $("#createRequest .loading-mask").hide();
                }, 1500);
            }).fail(function (response) {
                //console.log(response);
                setTimeout(function () {
                    $("#createRequest .loading-mask").hide();
                }, 1500);
            });
            this.brandOptions = brands;

            /*****************************************/
            $("#createRequest .loading-mask").show();
            var responseyears;
            var url = urlBuilder.build('tractorexchange/year/index');
            jQuery.ajax({
                // showLoader: true,
                type: 'POST',
                dataType: 'json',
                url: url,
                async: false,
                success: function (data) {
                    responseyears = data;
                    setTimeout(function () {
                        $("#createRequest .loading-mask").hide();
                    }, 1500);
                }
            });

            this.manufactureYear = responseyears;

            /****************************************/
            return this;
        },

        changeBrand: function () {
            var self = this;
            if (self.selectedBrand != undefined) {
                $("#createRequest .loading-mask").show();
                var modelurl = urlBuilder.build('servicerequest/tractor/model');

                $.ajax({
                    // showLoader: true,
                    url: modelurl,
                    type: 'post',
                    data: {data: self.selectedBrand},
                    dataType: 'json',
                    async: false,
                    success: function (data) {
                        $('#model option').remove();
                        $.each(data, function (i, value) {
                            $('#model').append($('<option>').text(value.model_name).attr('value', value.model_master_id));
                        });
                        setTimeout(function () {
                            $("#createRequest .loading-mask").hide();
                        }, 1500);
                    }
                });
            } else {
                $('#create_request').remove();

            }
        }, validateForm: function (form) {
            return $(form).validation() && $(form).validation('isValid');
        },

        addRequest: function () {
            if (!this.validateForm('#create_request')) {
                return;
            }
            var token = $('#ctxtkn').val();

            // $('#loading-mask').show();
            $("#createRequest .loading-mask").show();

            var requestParam = {};
            var formData = $('#create_request').serializeArray();
            var formDataNew = formData;
            // console.log(formData);

            $.each(formData, function (k, v) {
                if (v.name == 'tractor') {
                    if (v.value == 'my_tractor') {
                        requestParam['make_id'] = '';
                        requestParam['model_id'] = '';
                        requestParam['year_of_purchase'] = '';
                        requestParam['serial_number'] = '';
                        requestParam['registration_no'] = '';
                        $.each(formDataNew, function (key, val) {
                            if (val.name == 'tractor_name') {
                                requestParam['tractor_id'] = val.value;
                            }
                            if (val.name == 'address_id') {
                                requestParam['address_id'] = val.value;
                            }
                            if (val.name == 'comment') {
                                requestParam['comment'] = val.value;
                            }
                        });
                    } else if (v.value == 'other_tractor') {
                        requestParam['tractor_id'] = '';
                        $.each(formDataNew, function (key, val) {
                            if (val.name == 'brand_id') {
                                requestParam['make_id'] = val.value;
                            }
                            if (val.name == 'model_id') {
                                requestParam['model_id'] = val.value;
                            }
                            if (val.name == 'year_id') {
                                requestParam['year_of_purchase'] = val.value;
                            }
                            if (val.name == 'serial_number') {
                                requestParam['serial_number'] = val.value;
                            }
                            if (val.name == 'registration_no') {
                                requestParam['registration_no'] = val.value;
                            }
                            if (val.name == 'address_id') {
                                requestParam['address_id'] = val.value;
                            }
                            if (val.name == 'comment') {
                                requestParam['comment'] = val.value;
                            }
                        });
                    }

                    requestParam['lat'] = '';
                    requestParam['long'] = '';
                }
            });

            var ajaxValue = {
                "service_request": requestParam
            };

            var serviceUrl = 'rest/V1/create-service-request';
            var url = urlBuilder.build(serviceUrl);

            $.ajax({
                /*showLoader: true,*/
                type: 'POST',
                url: url,
                data: JSON.stringify(ajaxValue),
                dataType: 'json',
                headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token},
                async: false,
            }).done(function (response) {
                //console.log(response[0].message);
                //console.log(response[0].status);
                $('#add_sr_msg .messages').remove();
                if (response[0].status == 1) {
                    $('#add_sr_msg').show();
                    setTimeout(function () {
                        $("#createRequest .loading-mask").hide();
                        $('#create_request')[0].reset();
                    }, 2000);
                    $("#add_sr_msg").append("<div class=\"messages\"><div class=\"message message-success success\"><div data-ui-id=\"messages-message-success\">" + response[0].message + "</div></div></div>");
                    setTimeout(function () {
                        $("#add_sr_msg").hide();
                    }, 6000);
                }
                if (response[0].status == 0) {
                    $('#add_sr_msg').show();
                    setTimeout(function () {
                        $("#createRequest .loading-mask").hide();
                    }, 2000);
                    $("#add_sr_msg").append("<div class=\"messages\"><div class=\"message message-error error\"><div data-ui-id=\"messages-message-error\">" + response[0].message + "</div></div></div>");
                    setTimeout(function () {
                        $("#add_sr_msg").hide();
                    }, 6000);
                }
            }).fail(function (response) {
                setTimeout(function () {
                    $("#createRequest .loading-mask").hide();
                }, 2000);
                //console.log(response);
            });


        },

        radioFunction: function (data, event) {
            if (event.target.value == 'my_tractor') {
                $('#tractorListDiv').slideDown(700);
                $('#otherTractorDiv').hide();
            } else if (event.target.value == 'other_tractor') {
                $('#otherTractorDiv').slideDown(700);
                $('#tractorListDiv').hide();
                // $('input[name="tractor_name"]:radio').removeAttr('checked');
                // $(this).attr('previousValue', false);
            } else {
                $('#tractorListDiv').hide();
                $('#otherTractorDiv').hide();
            }
        }

    });
});