define([
    'ko',
    'jquery',
    'uiComponent',
    'mage/url',
    'mage/storage',
    'mage/translate',
], function (ko, $, Component, urlBuilder, storage, $t) {
    'use strict';
    //var id=1;

    return Component.extend({
        tractorList: ko.observableArray([]),

        initialize: function () {
            this._super();
            var self = this;
            var token = $('#ctxtkn').val();
            //alert(token);

            $t('Please Enter Your Mobile Number');
            $t('Please enter numerical value');
            $t('Please enter 4 digit OTP');
            $t('OTP number Missing');
            $t('Please enter 10 digit mobile number');
            $t('We have sent an OTP on your mobile number');
            $t('SMS not sent');
            $t('Get Your Free Demo Now');
            $t('Resend OTP');
            $t('Book Demo');
            $t('Please Enter Your OTP Number');
            $t('Get our Application in your Mobile');

            var serviceUrl = 'rest/V1/escorts/get-all-tractor';
            var url = urlBuilder.build(serviceUrl);
            var editUrl = urlBuilder.build('servicerequest/tractor/edit/tractor_id/');
            $.ajax({
                showLoader: true,
                type: 'GET',
                url: url,
                dataType: 'json',
                headers: {'Authorization': 'Bearer ' + token},
            }).done(function (response) {
                if (response[0].status) {
                    for (var i = 0; i < response[0].tractors.length; i++) {
                        //console.log(response[0].tractors[i]);
                        response[0].tractors[i].url = editUrl + response[0].tractors[i].tractor_id;
                        self.tractorList.push(response[0].tractors[i]);
                    }
                } else {
                    $('#list-div').html(response[0].message);
                }
            }).fail(function (response) {
                /*alert({
                 content: $t('There was error during loading data')
                 });*/
            });
            return this;
        },
    });
});