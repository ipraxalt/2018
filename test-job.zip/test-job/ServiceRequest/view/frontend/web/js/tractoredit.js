define([
   'ko',
   'jquery',
   'uiComponent',
   'mage/url',
   'mage/storage',
   'mage/translate',
   'mage/validation',
   'jquery.inputmask'
], function (ko, $, Component, urlBuilder, storage, $t, inputmask) {
   'use strict';

    return Component.extend({
        brandOptions: ko.observableArray([]),
        selectedBrand : ko.observable([]),
        manufactureYear: ko.observableArray([]),
        selectedYear: ko.observableArray([]),
        modelOption: ko.observableArray([]),
        selectedModel: ko.observableArray([]),
        serial_number: ko.observableArray([]),
        registration_no: ko.observableArray([]),

        initialize: function () {
            this._super();
            var self = this;
            var token = $('#ctxtkn').val();
            $("#edit-tractor .loading-mask").show();
            //alert(token);
            var brands;
            var serviceUrl = 'rest/V1/escorts/get-all-make';
            var url = urlBuilder.build(serviceUrl);
            
            $.ajax({
                showLoader: true,
                type: 'GET',
                url: url,
                dataType: 'json',
                headers: {'Authorization': 'Bearer '+token},
                async: false,
            }).done(function (response) {
                setTimeout(function(){ $("#edit-tractor .loading-mask").hide(); }, 1500);
                brands = response[0].make_master;
            }).fail(function (response) {
                setTimeout(function(){ $("#edit-tractor .loading-mask").hide(); }, 1500);
                //console.log(response);
            });
            this.brandOptions = brands;

            /**********************************************************/
            $("#edit-tractor .loading-mask").show();
            var responseyears;
            var url = urlBuilder.build('tractorexchange/year/index');
            jQuery.ajax({
                //showLoader: true,
                type: 'post',
                dataType: 'json',
                url:url,
                async: false,
                success: function(data){
                    setTimeout(function(){ $("#edit-tractor .loading-mask").hide(); }, 1500);
                    responseyears = data;
                }
            });
            
            this.manufactureYear = responseyears;

            /*****************************************************/
            $("#edit-tractor .loading-mask").show();
            var tractorId = $('#tractor_id').val();
            var serviceUrl = 'rest/V1/escorts/edit-tractor/'+tractorId;
            var url1 = urlBuilder.build(serviceUrl);
            var brandId;
            var year;
            var modelId;
            $.ajax({
                //showLoader: true,
                type: 'POST',
                url: url1,
                dataType: 'json',
                headers: {'Authorization': 'Bearer '+token},
                async: false,
            }).done(function (response) {
                setTimeout(function(){ $("#edit-tractor .loading-mask").hide(); }, 1500);
                brandId = response[0]['tractor'].make_id;
                year = response[0]['tractor'].manufacturing_year;
                modelId = response[0]['tractor'].model_id;
                self.serial_number.push(response[0]['tractor'].serial_number);
                self.registration_no.push(response[0]['tractor'].registration_no);
            }).fail(function (response) {
                setTimeout(function(){ $("#edit-tractor .loading-mask").hide(); }, 1500);
                /*alert({
                    content: $t('There was error during loading data')
                });*/
            });

            /**********************************************************/
            $("#edit-tractor .loading-mask").show();
            var model;
            var modelurl = urlBuilder.build('servicerequest/tractor/model');
            jQuery.ajax({
                //showLoader: true,
                type: 'post',
                data: {data:brandId},
                dataType: 'json',
                url:modelurl,
                async: false,
                success: function(data){
                    // console.log(data);
                    setTimeout(function(){ $("#edit-tractor .loading-mask").hide(); }, 1500);
                    model = data;
                }
            });

            this.modelOption = model;
            this.selectedBrand = brandId;
            this.selectedYear = year;
            this.selectedModel = modelId;

            return this;
        },

        changeBrand: function () {
            var self = this;
            if (self.selectedBrand != undefined) {
                $("#edit-tractor .loading-mask").show();
                var modelurl = urlBuilder.build('servicerequest/tractor/model');

                $.ajax({
                    /*showLoader: true,*/
                    type: 'post',
                    data: {data:this.selectedBrand},
                    dataType: 'json',
                    url:modelurl,
                    async: false,
                    success: function(data){
                        setTimeout(function(){ $("#edit-tractor .loading-mask").hide(); }, 1500);
                        $('#model option').remove();
                        $.each(data, function(i, value) {
                            $('#model').append($('<option>').text(value.model_name).attr('value', value.model_master_id));
                        });
                    }
                });
            }else{
                $('#model option').remove();
            }
        },

        validateForm: function (form) {
            return $(form).validation() && $(form).validation('isValid');
        },

        updateTractor: function () {
            var token = $('#ctxtkn').val();
            //alert(token);
            var serviceUrl = urlBuilder.build('rest/V1/escorts/update-tractor');

            $("#edit-tractor .loading-mask").show();

            var ajaxValue = {
                "requestData":{
                    "tractor_id":$('#tractor_id').val(),
                    "make_id":$('#brand').val(),
                    "model_id":$('#model').val(),
                    "serial_number": $('#serial_number').val(),
                    "registration_no": $('#registration_no').val()
                }
            };

            $.ajax({
                showLoader: true,
                type: 'POST',
                url: serviceUrl,
                contentType: 'application/json',
                dataType: 'json',
                data : JSON.stringify(ajaxValue),
                headers: {'Content-Type': 'application/json','Authorization': 'Bearer '+token},
                async: false,
                cache: false
            }).done(function (response) {
                //console.log(response[0].message);
                //console.log(response[0].status);
                if (response[0].status == 1) {
                    setTimeout(function(){ $("#edit-tractor .loading-mask").hide(); }, 1500);
                    $('#edit_tractor_msg .messages').remove();
                    $('#edit_tractor_msg').show();
                    $("#edit_tractor_msg").append("<div class=\"messages\"><div class=\"message message-success success\"><div data-ui-id=\"messages-message-success\">"+response[0].message+"</div></div></div>");
                    setTimeout(function(){ $("#edit_tractor_msg").hide(); }, 3000);
                }
                if (response[0].status == 0) {
                    setTimeout(function(){ $("#edit-tractor .loading-mask").hide(); }, 1500);
                    $('#edit_tractor_msg').show();
                    $("#edit_tractor_msg").append("<div class=\"messages\"><div class=\"message message-error error\"><div data-ui-id=\"messages-message-error\">"+response[0].message+"</div></div></div>");
                    setTimeout(function(){ $("#edit_tractor_msg").hide(); }, 3000);
                }
            }).fail(function (response) {
                setTimeout(function(){ $("#edit-tractor .loading-mask").hide(); }, 1500);
                //console.log('fail');
            });
        },

   });
});