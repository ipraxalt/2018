<?php

namespace Escorts\JobCard\Api;

interface JobCardApiInterface {

    /**
     * @api
     * @param int $customerId
     * @param int $jobStatus
     * @param int $curPage
     * @param int $pageSize
     * @return JSON
     */
    public function getJobCardList($customerId, $jobStatus, $curPage, $pageSize);

    /**
     * @api
     * @param int $customerId
     * @param int $srId
     * @param int $lat
     * @param int $long
     * @return JSON
     */
    public function getJobCardMain($customerId, $srId, $lat, $long);

    /**
     * @api
     * @param int $customerId
     * @param mixed $data
     * @return JSON
     */
    public function updateJobCardMain($customerId, $data);

    /**
     * @api
     * @param int $customerId
     * @param int $srId
     * @return JSON
     */
    public function getOpenJobCard($customerId, $srId);

    /**
     * @api
     * @param int $customerId
     * @param mixed $data
     * @return JSON
     */
    public function updateOpenJobCard($customerId, $data);

    /**
     * @api
     * @param int $customerId
     * @param int $srId
     * @return JSON
     */
    public function getCloseJobCard($customerId, $srId);

    /**
     * @api
     * @param int $customerId
     * @param mixed $data
     * @return JSON
     */
    public function updateCloseJobCard($customerId, $data);

    /**
     * @api
     * @param int $customerId
     * @param int $srId
     * @return JSON
     */
    public function viewJobCardMain($customerId, $srId);

    /**
     * @api
     * @param int $customerId
     * @param int $srId
     * @return mixed
     */
    public function shareHappyCode($customerId, $srId);

    /**
     * @api
     * @param int $customerId
     * @param int $srId
     * @param int $otp
     * @return mixed
     */
    public function verifyHappyCode($customerId, $srId, $otp);
}
