<?php

namespace Escorts\JobCard\Api;

interface JobCardInvoiceApiInterface {

   
    /**
     * @api
     * @param int $customerId
     * @param int $invoiceId
     * @return JSON
     */
     public function createFeedbackInvoice($customerId, $invoiceId);
     
}
