<?php
/*
 * Escorts
*/
namespace Escorts\JobCard\Model;
use Escorts\JobCard\Api\JobCardInvoiceApiInterface;
use Magento\Framework\Phrase;

class JobCardInvoiceApi implements JobCardInvoiceApiInterface {  

    protected $_commonHelper;
    protected $_serviceFeedbackInvoiceFactory;

    /**
     * @param \Escorts\Common\Helper\Data $commonHelper
     */
    public function __construct(
    \Escorts\Common\Helper\Data $commonHelper, \Escorts\JobCard\Helper\Data $jobcardHelper,
    \Escorts\ServiceRequest\Model\ServiceFeedbackInvoiceFactory $serviceFeedbackInvoiceFactory
    ) {
        $this->_commonHelper = $commonHelper;
        $this->_serviceFeedbackInvoiceFactory = $serviceFeedbackInvoiceFactory;
        
    }

  
    /**
     * Create Feedback Invoice PDF
     * @param int $customerId
     * @param int $invoiceId
     * @return mixed
     */
    public function createFeedbackInvoice($customerId, $invoiceId) {

       /* Note: Get jobno by serviceFeedbackInvoice invoice_id
       get  SD by Job No.
       CustomerId must be same as jobcart servicerequest Servicedealer(assigned_to)*/

        echo "test";die;

        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Detail not found for Open Job Card');

        if (!$this->_commonHelper->isEtcPermissons($customerId)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        try {               
        
        } catch (Exception $ex) {
          
        }

        return $response;
    }

   
}
