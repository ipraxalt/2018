<?php

namespace Escorts\JobCard\Model\ResourceModel;

class ServiceJobCard extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Model Initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('escorts_service_job_card', 'id');
    }
}
