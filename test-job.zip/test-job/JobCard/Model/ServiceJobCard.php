<?php

namespace Escorts\JobCard\Model;

class ServiceJobCard extends \Magento\Framework\Model\AbstractModel {

    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct() {
        parent::_construct();
        $this->_init('Escorts\JobCard\Model\ResourceModel\ServiceJobCard');
    }

}
