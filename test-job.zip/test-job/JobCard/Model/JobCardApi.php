<?php

/*
 * Escorts
 */

namespace Escorts\JobCard\Model;

use Escorts\JobCard\Api\JobCardApiInterface;
use Magento\Framework\Phrase;

class JobCardApi implements JobCardApiInterface {
    /* const RELATIONSHIPS = [
      ['id' => 0, 'value' => 'Self'],
      ['id' => 1, 'value' => 'Brother'],
      ['id' => 2, 'value' => 'Dummy 1'],
      ['id' => 3, 'value' => 'Dummy 2'],
      ['id' => 4, 'value' => 'Dummy 3']
      ]; */

    protected $_commonHelper;
    protected $_jobNoFactory;
    protected $_customerTractorFactory;
    protected $_serviceFactory;
    protected $_modelMasterFactory;
    protected $_regionFactory;
    protected $_addressModel;
    protected $_customerFactory;
    protected $_countryFactory;
    protected $jobcardHelper;
    protected $addressRepository;
    protected $_customerRepository;
    protected $serviceJobCardFactory;
    protected $_timezone;
    protected $_serviceJobPartsFactory;
    protected $_sparePartsApiFactory;
    protected $_warrantyHelper;
    protected $_serviceRequestTypeFactory;
    protected $_storeManager;
    protected $_smsNotificationHelper;
    protected $_bitlyHelper;
    protected $_emailNotify;

    /**
     * 
     * @param \Escorts\Common\Helper\Data $commonHelper
     * @param \Escorts\JobCard\Helper\Data $jobcardHelper
     * @param \Escorts\ServiceRequest\Model\ServiceJobNoFactory $jobNoFactory
     * @param \Escorts\ServiceRequest\Model\CustomerTractorFactory $_customerTractorFactory
     * @param \Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory
     * @param \Escorts\ModelMaster\Model\ModelMasterFactory $modelMasterFactory
     * @param \Magento\Directory\Model\RegionFactory $regionFactory
     * @param \Magento\Customer\Model\Address $addressModel
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     * @param \Magento\Directory\Model\CountryFactory $countryFactory
     * @param \Magento\Customer\Api\AddressRepositoryInterface $addressRepository
     * @param \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository
     * @param \Escorts\JobCard\Model\ServiceJobCardFactory $serviceJobCardFactory
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
     * @param \Escorts\ServiceRequest\Model\ServiceJobPartsFactory $serviceJobPartsFactory
     * @param \Escorts\SpareParts\Model\SparePartsApiFactory $sparePartsApiFactory
     * @param \Escorts\Warrantyplan\Helper\Data $warrantyHelper
     * @param \Escorts\ServiceRequest\Model\RequestTypeFactory $serviceRequestTypeFactory
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Escorts\SmsNotification\Helper\Data $smsNotificationHelper
     */
    public function __construct(
    \Escorts\Common\Helper\Data $commonHelper, \Escorts\JobCard\Helper\Data $jobcardHelper, \Escorts\ServiceRequest\Model\ServiceJobNoFactory $jobNoFactory, \Escorts\ServiceRequest\Model\CustomerTractorFactory $_customerTractorFactory, \Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory, \Escorts\ModelMaster\Model\ModelMasterFactory $modelMasterFactory, \Magento\Directory\Model\RegionFactory $regionFactory, \Magento\Customer\Model\Address $addressModel, \Magento\Customer\Model\CustomerFactory $customerFactory, \Magento\Directory\Model\CountryFactory $countryFactory, \Magento\Customer\Api\AddressRepositoryInterface $addressRepository, \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository, \Escorts\JobCard\Model\ServiceJobCardFactory $serviceJobCardFactory, \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone, \Escorts\ServiceRequest\Model\ServiceJobPartsFactory $serviceJobPartsFactory, \Escorts\SpareParts\Model\SparePartsApiFactory $sparePartsApiFactory, \Escorts\Warrantyplan\Helper\Data $warrantyHelper, \Escorts\ServiceRequest\Model\RequestTypeFactory $serviceRequestTypeFactory, \Magento\Store\Model\StoreManagerInterface $storeManager, \Escorts\SmsNotification\Helper\Data $smsNotificationHelper, \Escorts\Common\Helper\Bitly $_bitlyHelper, \Escorts\CustomEmails\Helper\EmailNotification $_emailNotify
    ) {
        $this->_commonHelper = $commonHelper;
        $this->_jobNoFactory = $jobNoFactory;
        $this->_customerTractorFactory = $_customerTractorFactory;
        $this->_serviceFactory = $serviceFactory;
        $this->_modelMasterFactory = $modelMasterFactory;
        $this->_regionFactory = $regionFactory;
        $this->_addressModel = $addressModel;
        $this->_customerFactory = $customerFactory;
        $this->_countryFactory = $countryFactory;
        $this->jobcardHelper = $jobcardHelper;
        $this->addressRepository = $addressRepository;
        $this->_customerRepository = $customerRepository;
        $this->serviceJobCardFactory = $serviceJobCardFactory;
        $this->_timezone = $timezone;
        $this->_serviceJobPartsFactory = $serviceJobPartsFactory;
        $this->_sparePartsApiFactory = $sparePartsApiFactory;
        $this->_warrantyHelper = $warrantyHelper;
        $this->_serviceRequestTypeFactory = $serviceRequestTypeFactory;
        $this->_storeManager = $storeManager;
        $this->_smsNotificationHelper = $smsNotificationHelper;
        $this->_bitlyHelper = $_bitlyHelper;
        $this->_emailNotify = $_emailNotify;
    }

    /**
     * Get job cards list
     * @param int $dealerId
     * @param int $jobStatus
     * @param int $curPage
     * @param int $pageSize
     * @return mixed
     */
    public function getJobCardList($dealerId, $jobStatus, $curPage, $pageSize) {
        $response = [];

        if (!$this->_commonHelper->isEtcPermissons($dealerId)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        try {
            $joblistCollection = $this->_jobNoFactory->create()->getCollection();
            $joblistCollection->addFieldToSelect(['id', 'srid', 'created_at', 'status']);

            if ($jobStatus >= 0) {
                $joblistCollection->addFieldToFilter('main_table.status', ['eq' => $jobStatus]);
            }

            $joblistCollection->getSelect()
                    ->join(['srTable' => $joblistCollection->getTable('escorts_service_request')], "main_table.srid= srTable.id", ['service_request_type'])
                    ->join(['tractorTable' => $joblistCollection->getTable('escorts_customer_tractor')], "tractorTable.tractor_id=srTable.tractor_id", ['make_id', 'model_id'])
                    ->where('srTable.assigned_to=' . $dealerId);

            if ($joblistCollection->getSize()) {
                $response[0]['status'] = 1;
                $response[0]['message'] = $joblistCollection->getSize() . __(' Job Cards found');

                if ($pageSize) {
                    $response[0]['pages'] = ceil($joblistCollection->getSize() / $pageSize);
                    $response[0]['total'] = $joblistCollection->getSize();
                    $joblistCollection->setPageSize($pageSize);
                }

                if ($curPage) {
                    $joblistCollection->setCurPage($curPage);
                }

                $joblistCollection->setOrder('id', 'DESC');

                $tat = $this->jobcardHelper->getJobCardTat();
                foreach ($joblistCollection as $jobCart) {
                    $tractorName = $this->_commonHelper->getTractorName($jobCart->getMakeId(), $jobCart->getModelId());
                    $jobData = [
                        'job_no' => $jobCart->getId(),
                        'job_no_str' => str_pad((string) $jobCart->getId(), 10, '0', STR_PAD_LEFT),
                        'sr_id' => $jobCart->getSrid(),
                        'sr_id_str' => str_pad((string) $jobCart->getSrid(), 10, '0', STR_PAD_LEFT),
                        'service_request_type' => $jobCart->getServiceRequestType(),
                        'service_request_type_str' => $this->getSrTypeString($jobCart->getServiceRequestType()),
                        'product_name' => $tractorName,
                        'created_at' => $jobCart->getCreatedAt(),
                        'job_status' => $jobCart->getStatus(),
                        'job_status_str' => $this->getJobStatusStr($jobCart->getStatus())
                    ];

                    $jobData['left_time'] = $this->_commonHelper::CONST_NULL;
                    if ($jobCart->getStatus() == 0) {
                        $jobData['left_time'] = $this->_commonHelper->getLeftTime($jobCart->getCreatedAt(), $tat);
                    }

                    $response[0]['jobs'][] = $jobData;
                }
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('No Job Card found');
            }

            $response[0]['statuses'] = $this->_commonHelper::JOB_STATUSES;
        } catch (Exception $ex) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Something went wrong');
        }
        return $response;
    }

    /**
     * Get Service Request Job Number
     * @param int $srType
     * @param int $srid
     * @return mixed
     */
    public function getServiceRequestJobNo($srid, $lat = null, $long = null) {
        $jobNo = 0;
        $srType = 0;
        $serviceModel = $this->_serviceFactory->create()->load($srid);

        if ($serviceModel->getId()) {
            $srType = $serviceModel->getServiceRequestType();

            if (in_array($srType, [SR_TYPE_ROUTINE, SR_TYPE_REPAIR])) {
                $jobModel = $this->_jobNoFactory->create()
                        ->getCollection()
                        ->addFieldToSelect(['id'])
                        ->addFieldToFilter('srid', ['eq' => $srid])
                        ->addFieldToFilter('service_request_type', ['eq' => $srType])
                        ->setPageSize(1);

                if ($jobModel->getSize()) {
                    $jobNo = $jobModel->getFirstItem()->getId();
                } else {
                    $jobModel = $this->_jobNoFactory->create();
                    $jobModel->setServiceRequestType($srType);
                    $jobModel->setSrid($srid);
                    $jobModel->setCreatedAt($this->_timezone->date()->format('Y-m-d H:i:s'));

                    if ($lat)
                        $jobModel->setLatOpen($lat);

                    if ($long)
                        $jobModel->setLongOpen($long);

                    $jobModel->setStatus(0);
                    $jobModel->save();
                    $jobNo = $jobModel->getId();
                }
            }
        }

        return [
            'job_no' => $jobNo,
            'sr_type' => $srType
        ];
    }

    /**
     * Get job card main detail
     * @param int $dealerId
     * @param int $srId
     * @param int $lat
     * @param int $long
     * @return mixed
     */
    public function getJobCardMain($dealerId, $srId, $lat, $long) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong');

        if (!$this->_commonHelper->isEtcPermissons($dealerId)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }
        /* $arr = [
          'dealerId' => $dealerId,
          'srId' => $srId
          ];

          $this->_commonHelper->writeFile(json_encode($arr)); */

        try {
            $jobData = $this->getServiceRequestJobNo($srId, $lat, $long);
            if (!empty($jobData['job_no'])) {
                $srType = $jobData['sr_type'];
            } else {
                $response[0]['message'] = __('Job Number not generated for service request');
                return $response;
            }

            $joblistCollection = $this->_jobNoFactory->create()->getCollection();
            $joblistCollection->addFieldToSelect(['id', 'created_at']);
            $joblistCollection->addFieldToFilter('main_table.srid', ['eq' => $srId]);
            $joblistCollection->addFieldToFilter('main_table.service_request_type', ['eq' => $srType]);
            $joblistCollection->addFieldToFilter('main_table.service_request_type', ['nin' => ['1', '2']]);
            $joblistCollection->getSelect()
                    ->join(['srTable' => $joblistCollection->getTable('escorts_service_request')], "main_table.srid= srTable.id", ['service_request_type', 'status', 'created_at AS sr_created_at'])
                    ->join(['tractorTable' => $joblistCollection->getTable('escorts_customer_tractor')], "tractorTable.tractor_id=srTable.tractor_id", ['serial_number', 'engine_number', 'delivery_date', 'model_id', 'registration_no', 'customer_id', 'tractor_id'])
                    ->where('srTable.assigned_to=' . $dealerId);

            if ($joblistCollection->getSize()) {
                $jobCart = $joblistCollection->getData();
                $response[0]['job_no'] = $jobCart[0]['id'];
                $response[0]['job_no_str'] = str_pad((string) $jobCart[0]['id'], 10, '0', STR_PAD_LEFT);

                $modelName = $this->_modelMasterFactory->create()->load($jobCart[0]['model_id'])->getModelName();
                $installationDate = $this->_commonHelper::CONST_NULL;

                if (!empty($this->jobcardHelper->getinstallationDate($jobCart[0]['tractor_id']))) {
                    $installationDate = $this->jobcardHelper->getinstallationDate($jobCart[0]['tractor_id']);
                    if ($installationDate == "0000-00-00 00:00:00" || empty($installationDate)) {
                        $installationDate = $this->_commonHelper::CONST_NULL;
                    } else {
                        $installationDate = date("Y-m-d", strtotime($installationDate));
                    }
                }

                $tat = $this->jobcardHelper->getJobCardTat();
                $response[0]['left_time'] = $this->_commonHelper::CONST_NULL;
                if ($jobCart[0]['status'] == 0) {
                    $response[0]['left_time'] = $this->_commonHelper->getLeftTime($jobCart[0]['created_at'], $tat);
                }

                $response[0]['created_at'] = $jobCart[0]['created_at'];

                $response[0]['tractor_detail'] = [
                    'registration_no' => $jobCart[0]['registration_no'],
                    'serial_number' => $jobCart[0]['serial_number'],
                    'engine_number' => $jobCart[0]['engine_number'],
                    'warranty_upto' => $this->_commonHelper::CONST_NULL,
                    'model' => $modelName,
                    'delivery_date' => date("Y-m-d", strtotime($jobCart[0]['delivery_date'])),
                    'installation_date' => $installationDate
                ];

                //Customer default shipping address
                $customer = $this->_customerFactory->create()->load($jobCart[0]['customer_id']);
                $shippingAddressId = $customer->getDefaultShipping();
                $address = $this->_addressModel->load($shippingAddressId);

                if ($address) {
                    $streetAaddress = $address->getStreet();
                    if (!empty($streetAaddress)) {
                        $streetAaddress = implode(',', $streetAaddress);
                    }

                    $state = $address->getRegionId();
                    if (is_numeric($state)) {
                        $state = $this->_regionFactory->create()->load($state)->getName();
                    }

                    $response[0]['customer_detail'] = [
                        'customer_id' => $customer->getEntityId(),
                        'address_id' => $shippingAddressId,
                        'mobile_number' => $address->getTelephone(),
                        'customer_name' => $customer->getName(),
                        'father_name' => $customer->getFatherName(),
                        'alternative_mobile' => $address->getAltMobileNumber(),
                        'dob' => $customer->getDob(),
                        'email_id' => $customer->getEmail(),
                        'state' => $state,
                        'district' => $address->getCity(),
                        'tehsil' => $address->getTehsil(),
                        'village' => $address->getVillage(),
                        'address' => $streetAaddress,
                        'post_code' => $address->getPostcode()
                    ];
                }

                $response[0]['status'] = 1;
                $response[0]['message'] = __('Job card detail');
                //$response[0]['relationships'] = self::RELATIONSHIPS;
            }
        } catch (Exception $ex) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Something went wrong');
        }
        return $response;
    }

    /**
     * Update job card main detail
     * @param int $dealerId
     * @param mixed $data
     * @return mixed
     */
    public function updateJobCardMain($dealerId, $data) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong');

        if (!$this->_commonHelper->isEtcPermissons($dealerId)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        try {
            if (empty($data['sr_id'])) {
                return $response;
            }

            $srId = $data['sr_id'];
            $srCollection = $this->_serviceFactory->create()
                    ->getCollection()
                    ->addFieldToSelect('tractor_id')
                    // ->addFieldToFilter('id', ['eq' => $srId]);
                    ->addFieldToFilter('assigned_to', ['eq' => $dealerId]);
            $srCollection->getSelect()
                    ->join(['jobnoTable' => $srCollection->getTable('escorts_service_job_no')], "main_table.id= jobnoTable.srid")
                    ->where('main_table.id=' . $srId);

            if (!empty($srCollection->getSize())) {
                $tractorId = $srCollection->getData();
                $tractorObj = $this->_customerTractorFactory->create()->load($tractorId[0]['tractor_id']);
                $customer_Id = $tractorObj->getCustomerId();

                if (!empty($data['registration_number'])) {
                    $tractorObj->setRegistrationNo($data['registration_number']);
                }
                if (!empty($data['serial_number'])) {
                    $tractorObj->setSerialNumber($data['serial_number']);
                }
                if (!empty($data['engine_number'])) {
                    $tractorObj->setEngineNumber($data['engine_number']);
                }

                $tractorObj->save();

                if (!empty($data['customer_detail'])) {
                    //Update customer address details                    
                    $customerModel = $this->_customerFactory->create()->load($customer_Id);
                    $shippingAddressId = $customerModel->getDefaultShipping();
                    if ($shippingAddressId) {
                        $address = $this->_addressModel->load($shippingAddressId);
                        $address->setRegionId($data['customer_detail']['state_id']); // Update region 
                        $address->setCity($data['customer_detail']['district']); // Update District or city 
                        $address->setTehsil($data['customer_detail']['tehsil']);
                        $address->setVillage($data['customer_detail']['village']);
                        $address->setStreet($data['customer_detail']['address']);   // Update city                  
                        $address->setPostcode($data['customer_detail']['post_code']);
                        $altMobile = $data['customer_detail']['alternative_mobile'];
                        $address->setAltMobileNumber($altMobile);
                        $address->save();
                    }

                    $customer = $this->_customerRepository->getById($customer_Id);
                    $customer->setData('dob', $data['customer_detail']['dob']);

                    /* email is not exist then update */
                    if (empty($this->_commonHelper->checkCustomerEmailExist($data['customer_detail']['email_id']))) {
                        $customer->setData('email', $data['customer_detail']['email_id']);
                    }

                    $customer = $this->_customerRepository->save($customer);
                }

                $response[0]['status'] = 1;
                $response[0]['message'] = __('Updated successfully');
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('No job cart exist for given service request id');
            }
        } catch (Exception $ex) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Something went wrong. Please try again later');
        }

        return $response;
    }

    /**
     * Get job card detail
     * @param int $dealerId
     * @param int $srId
     * @return mixed
     */
    public function getOpenJobCard($dealerId, $srId) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Detail not found for Open Job Card');

        if (!$this->_commonHelper->isEtcPermissons($dealerId)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        try {
            $jobData = $this->getServiceRequestJobNo($srId);
            if (empty($jobData['job_no'])) {
                $response[0]['message'] = __('Job Number not generated for service request');
                return $response;
            } else {
                $jobNo = $jobData['job_no'];
            }

            $serviceRequest = $this->_serviceFactory->create()->load($srId);
            if ($serviceRequest) {
                $response[0]['otp_verified'] = $serviceRequest->getOtpVerified();
            }

            $jobModel = $this->_jobNoFactory->create()->load($jobNo);

            $meterReading = $this->_commonHelper::CONST_NULL;
            $lastMeterReading = $this->_commonHelper::CONST_NULL;
            $fuelLevelVal = $this->_commonHelper::CONST_NULL;

            $joblistCollection = $this->_jobNoFactory->create()
                    ->getCollection()
                    ->addFieldToSelect(['id', 'created_at', 'service_request_type']);

            $joblistCollection->getSelect()
                    ->join(['srTable' => $joblistCollection->getTable('escorts_service_request')], "main_table.srid= srTable.id", ['customer_id', 'service_request_type', 'service_no', 'coupon_code'])
                    ->where('main_table.id=' . $jobNo);

            if ($joblistCollection->getSize()) {
                $jobCard = $joblistCollection->getData();

                $customerId = $jobCard[0]['customer_id'];
                $srCollection = $this->_serviceFactory->create()->getCollection()
                        ->addFieldToSelect([])
                        ->addFieldToFilter('customer_id', ['eq' => $customerId])
                        ->setOrder('id', 'DESC')
                        ->setPageSize('1');

                $srCollection->getSelect()
                        ->joinLeft(['secondTable' => $srCollection->getTable('escorts_service_job_no')], 'main_table.id = secondTable.srid', ['srid'])
                        ->joinLeft(['thirdTable' => $srCollection->getTable('escorts_service_job_card')], 'secondTable.id = thirdTable.job_no', ['meter_reading'])
                        ->where('secondTable.id<>' . $jobNo);

                //print_r($srCollection->getFirstItem()->getData());
                //die;
                $lastMeterReading = $srCollection->getFirstItem()->getMeterReading();

                $date = date("Y-m-d", strtotime($jobCard[0]['created_at']));

                $jobCardObject = $this->serviceJobCardFactory->create()->load($jobNo, 'job_no');
                if (!empty($jobCardObject->getId())) {
                    $meterReading = $jobCardObject->getMeterReading();
                    $fuelLevelVal = $jobCardObject->getFuelLevel();
                }

                $response[0]['jobcard_detail'] = [
                    'job_card_date' => $date,
                    'service_request_type' => $jobCard[0]['service_request_type'],
                    'service_request_type_str' => $this->getSrTypeString($jobCard[0]['service_request_type']),
                    'service_no' => $jobCard[0]['service_no'],
                    'coupon_number' => $jobCard[0]['coupon_code'],
                    'meter_reading' => $meterReading,
                    'last_meter_reading' => $lastMeterReading,
                    'fuel_level' => $fuelLevelVal
                ];

                /* Job Parts & Auto Order Cart detail */
                $jobParts['item'] = [];

                //Get Spare Parts amounts
                $amounts = $this->getSparePartsTotal($jobNo);

                $serviceJobParts = $this->_serviceJobPartsFactory->create()
                        ->getCollection()
                        ->addFieldToSelect(['part_name', 'part_id', 'qty', 'price', 'cgst', 'sgst', 'igst', 'sub_total', 'in_warranty', 'warranty_by', 'is_editable'])
                        ->addFieldToFilter('job_no', ['eq' => $jobNo]);

                $serviceJobParts->getSelect()
                        ->joinLeft(['secondTable' => $serviceJobParts->getTable('escorts_spare_parts')], 'main_table.part_id = secondTable.id', ['part_number', 'price_mrp', 'price_dnp', 'cgst AS cgst_rate', 'sgst AS sgst_rate', 'igst AS igst_rate']);

                if ($serviceJobParts->getSize()) {
                    $media_url = $this->_commonHelper->getMediaPath();

                    foreach ($serviceJobParts as $serviceJobPart) {
                        $temp = $serviceJobPart->getData();

                        if (!empty($temp['part_image'])) {
                            $temp['part_image'] = $media_url . $temp['part_image'];
                        } else {
                            $temp['part_image'] = $media_url . 'wysiwyg/spare_parts/default.jpeg';
                        }

                        $temp['price'] = number_format((float) $temp['price'], 2, '.', '');
                        $temp['cgst'] = number_format((float) $temp['cgst'], 2, '.', '');
                        $temp['sgst'] = number_format((float) $temp['sgst'], 2, '.', '');
                        $temp['igst'] = number_format((float) $temp['igst'], 2, '.', '');
                        $temp['sub_total'] = number_format((float) $temp['sub_total'], 2, '.', '');
                        $temp['price_mrp'] = number_format((float) $temp['price_mrp'], 2, '.', '');
                        $temp['price_dnp'] = number_format((float) $temp['price_dnp'], 2, '.', '');
                        $jobParts['item'][] = $temp;
                    }

                    $response[0]['job_parts'] = $jobParts;
                    $response[0]['job_parts']['others'] = [
                        'total' => number_format((float) $amounts['sub_total'], 2, '.', ''),
                        'cgst' => number_format((float) $amounts['cgst'], 2, '.', ''),
                        'sgst' => number_format((float) $amounts['sgst'], 2, '.', ''),
                        'labour_charge' => number_format((float) $jobModel->getLabourCharge(), 2, '.', ''),
                        'labour_charge_comment' => $jobModel->getLabourChargeComment(),
                        'misc_charge' => number_format((float) $jobModel->getMiscCharge(), 2, '.', ''),
                        'misc_charge_comment' => $jobModel->getMiscChargeComment(),
                        'misc_charge_type' => $jobModel->getMiscChargeType(),
                        'grand_total' => number_format((float) $jobModel->getGrandTotal(), 2, '.', ''),
                        'time_to_fix' => $jobModel->getTimeToFix()
                    ];
                }

                $cartDetail = $this->_sparePartsApiFactory->create()->getCartDetail($dealerId, $jobNo);
                //print_r($cartDetail);die;

                if (isset($cartDetail[0]['cart_items'])) {
                    $response[0]['cart_detail'] = $cartDetail[0];
                }

                $response[0]['status'] = 1;
                $response[0]['message'] = __('Open Job Card detail');
            }
        } catch (Exception $ex) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Something went wrong. Please try again later');
        }

        return $response;
    }

    /**
     * Update job card detail
     * @param int $dealerId
     * @param mixed $data
     * @return mixed     
     */
    public function updateOpenJobCard($dealerId, $data) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong');
        $unavailableParts = [];

        if (!$this->_commonHelper->isEtcPermissons($dealerId)) {
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        if (empty($data['sr_id'])) {
            $response[0]['message'] = __('Service request number is empty');
            return $response;
        } else {
            $jobData = $this->getServiceRequestJobNo($data['sr_id']);
            if (!empty($jobData['job_no'])) {
                $jobNo = $jobData['job_no'];
            } else {
                $response[0]['message'] = __('Job number not generated for service request');
                return $response;
            }
        }

        if (!isset($data['jobcard']['fuel_level'])) {
            $response[0]['message'] = __('Please enter valid fuel level');
            return $response;
        }

        try {
            /* JOb number existence check */
            $jobModel = $this->_jobNoFactory->create()->load($jobNo);

            if ($jobModel->getServiceFormId()) {
                $response[0]['message'] = __('Job card already closed');
                return $response;
            }

            if (empty($jobModel->getId())) {
                $response[0]['message'] = __('Job number is wrong');
                return $response;
            }

            $serviceModel = $this->_serviceFactory->create()->load($jobModel->getSrid());

            if ($serviceModel) {
                $serviceModel->setOtpVerified(0);
                $serviceModel->save();
                $response[0]['otp_verified'] = $serviceModel->getOtpVerified();
            }

            /* Update Job card for given job no */
            $jobCardObject = $this->serviceJobCardFactory->create()->load($jobNo, 'job_no');
            if (!empty($jobCardObject->getId())) {
                if (!empty($data['jobcard']['meter_reading'])) {
                    $jobCardObject->setMeterReading($data['jobcard']['meter_reading']);
                }
                if (!empty($data['jobcard']['fuel_level'])) {
                    $jobCardObject->setFuelLevel($data['jobcard']['fuel_level']);
                }
                $jobCardObject->save();
            } else {
                /* insert Job card for given job no */
                $data['jobcard']['job_no'] = $jobNo;
                $jobCardObject->setData($data['jobcard']);
                $jobCardObject->save();
            }

            if (!empty($data['parts_data'])) {
                $partsData = $data['parts_data'];

                if (!empty($partsData['parts'])) {
                    foreach ($partsData['parts'] as $part) {
                        $netStock = 0;
                        $quantity = 0;

                        if (empty($part['qty'])) {
                            $part['qty'] = 1;
                        }

                        $partDetail = $this->_commonHelper->getPartDetailByPartNumber($part['part_number']);

                        if (!$partDetail) {
                            $unavailableParts[] = $part['part_number'];
                            continue;
                        }

                        if ($partDetail['category_id'] != OTHER_SPARE_PART_CAT) {
                            //Check ETC stock
                            $stock = $this->_sparePartsApiFactory->create()->getEtcPartStock($dealerId, $partDetail['id']);
                            $bookedQty = $this->_commonHelper->getBookedQuantity($dealerId, $jobNo, $partDetail['id']);

                            $netStock = $stock - $bookedQty['reserved'];
                            if ($netStock > 0) {
                                $quantity = $part['qty'] - $netStock;
                            } else {
                                $quantity = $part['qty'];
                            }

                            $quantity -= $bookedQty['ordered'];
                            if ($quantity > 0) {
                                $this->_sparePartsApiFactory->create()->addToCartSparePart($dealerId, $partDetail['id'], $quantity, $jobNo);
                            } else {
                                $this->_sparePartsApiFactory->create()->removePartFromCart($dealerId, $partDetail['id'], $jobNo);
                            }
                        } else {
                            $part['is_editable'] = 1;
                        }

                        if ($partDetail) {
                            if (empty($part['part_name'])) {
                                $part['part_name'] = $partDetail['part_name'];
                            }

                            if (empty($part['price'])) {
                                $part['price'] = $partDetail['price_mrp'];
                            }

                            $part['job_no'] = $jobNo;
                            //$part['price'] = $partDetail['price_mrp'];
                            $part['cgst'] = $this->_commonHelper->getTaxAmount($part['price'], $partDetail['cgst']);
                            $part['sgst'] = $this->_commonHelper->getTaxAmount($part['price'], $partDetail['sgst']);
                            //$part['igst'] = $this->_commonHelper->getTaxAmount($partDetail['price_mrp'], $partDetail['igst']);
                            $part['sub_total'] = $part['price'] * $part['qty'];

                            $serviceJobParts = $this->_serviceJobPartsFactory->create()
                                    ->getCollection()
                                    ->addFieldToFilter('job_no', ['eq' => $jobNo])
                                    ->addFieldToFilter('part_id', ['eq' => $partDetail['id']])
                                    ->setPageSize(1);

                            if ($serviceJobParts->getSize()) {
                                $part['id'] = $serviceJobParts->getFirstItem()->getId();
                                $serviceJobPart = $this->_serviceJobPartsFactory->create()->load($partDetail['id']);
                            } else {
                                $serviceJobPart = $this->_serviceJobPartsFactory->create();
                            }

                            unset($part['part_number']);
                            $part['part_id'] = $partDetail['id'];

                            $serviceJobPart->setData($part);
                            $serviceJobPart->save();
                        }
                    }
                }
            }

            $grandTotal = 0.00;
            $jobParts['item'] = [];

            //Get Spare Parts amounts
            $amounts = $this->getSparePartsTotal($jobNo);
            $grandTotal += $amounts['sub_total'] + $amounts['cgst'] + $amounts['sgst'];

            if (isset($partsData['labour_charge'])) {
                $jobModel->setLabourCharge($partsData['labour_charge']);
                $grandTotal += (float) $partsData['labour_charge'];
            }

            if (isset($partsData['labour_charge_comment'])) {
                $jobModel->setLabourChargeComment($partsData['labour_charge_comment']);
            }

            if (isset($partsData['misc_charge'])) {
                $jobModel->setMiscCharge($partsData['misc_charge']);
                $grandTotal += (float) $partsData['misc_charge'];
            }

            if (isset($partsData['misc_charge_comment'])) {
                $jobModel->setMiscChargeComment($partsData['misc_charge_comment']);
            }

            if (isset($partsData['misc_charge_type'])) {
                $jobModel->setMiscChargeType($partsData['misc_charge_type']);
            }

            if (isset($partsData['time_to_fix'])) {
                $jobModel->setTimeToFix($partsData['time_to_fix']);
            }

            $jobModel->setGrandTotal($grandTotal);

            /*
              if (isset($partsData['status']) && $partsData['status'] > 0) {
              $serviceModel->setStatus(SR_STATUS_COMPLETED);
              $jobModel->setClosedAt($this->_timezone->date()->format('Y-m-d H:i:s'));
              $jobModel->setStatus($partsData['status']);
              $this->_commonHelper->inactiveJobCart($dealerId, $jobNo);

              switch ($partsData['status']) {
              case 1:
              $response[0]['message'] = __('Job card closed successfully');
              break;
              case 2:
              $response[0]['message'] = __('Job card successfully');
              break;
              }
              } else {
              $response[0]['message'] = __('Saved successfully');
              }
             */

            $serviceJobParts = $this->_serviceJobPartsFactory->create()
                    ->getCollection()
                    ->addFieldToSelect(['part_name', 'part_id', 'qty', 'price', 'cgst', 'sgst', 'igst', 'sub_total', 'is_editable'])
                    ->addFieldToFilter('job_no', ['eq' => $jobNo]);

            $serviceJobParts->getSelect()
                    ->joinLeft(['secondTable' => $serviceJobParts->getTable('escorts_spare_parts')], 'main_table.part_id = secondTable.id', ['part_number', 'part_image', 'price_mrp', 'price_dnp', 'cgst AS cgst_rate', 'sgst AS sgst_rate', 'igst AS igst_rate']);

            $srid = $data['sr_id'];
            $tractorId = "";
            $serviceModel = $this->_serviceFactory->create()->load($srid);
            if ($serviceModel->getId()) {
                $tractorId = $serviceModel->getTractorId();
            }

            if ($serviceJobParts->getSize()) {
                $media_url = $this->_commonHelper->getMediaPath();

                foreach ($serviceJobParts as $serviceJobPart) {
                    $item = $serviceJobPart->getData();
                    $item['in_warranty'] = 0;
                    $item['warranty_by'] = 0;

                    $warrantyResult = $this->_warrantyHelper->isInWarranty($tractorId, $item['part_id']);
                    if ($warrantyResult) {
                        $item['in_warranty'] = $warrantyResult['in_warranty'];
                        $item['warranty_by'] = $warrantyResult['warranty_by'];
                        /* Update warranty details in table */
                        $serviceJobParts = $this->_serviceJobPartsFactory->create()->load($item['id']);
                        if ($serviceJobParts->getId()) {
                            $serviceJobParts->setInWarranty($warrantyResult['in_warranty']);
                            $serviceJobParts->setWarrantyBy($warrantyResult['warranty_by']);
                            $serviceJobParts->save();
                        }
                    }

                    if (!empty($item['part_image'])) {
                        $item['part_image'] = $media_url . $item['part_image'];
                    } else {
                        $item['part_image'] = $media_url . 'wysiwyg/spare_parts/default.jpeg';
                    }

                    $item['price'] = number_format((float) $item['price'], 2, '.', '');
                    $item['cgst'] = number_format((float) $item['cgst'], 2, '.', '');
                    $item['sgst'] = number_format((float) $item['sgst'], 2, '.', '');
                    $item['igst'] = number_format((float) $item['igst'], 2, '.', '');
                    $item['sub_total'] = number_format((float) $item['sub_total'], 2, '.', '');
                    $item['price_mrp'] = number_format((float) $item['price_mrp'], 2, '.', '');
                    $item['price_dnp'] = number_format((float) $item['price_dnp'], 2, '.', '');
                    $jobParts['item'][] = $item;
                }

                $response[0]['job_parts'] = $jobParts;

                if ($jobModel->getId()) {
                    $response[0]['job_parts']['others'] = [
                        'total' => number_format((float) $amounts['sub_total'], 2, '.', ''),
                        'cgst' => number_format((float) $amounts['cgst'], 2, '.', ''),
                        'sgst' => number_format((float) $amounts['sgst'], 2, '.', ''),
                        'labour_charge' => number_format((float) $jobModel->getLabourCharge(), 2, '.', ''),
                        'labour_charge_comment' => $jobModel->getLabourChargeComment(),
                        'misc_charge' => number_format((float) $jobModel->getMiscCharge(), 2, '.', ''),
                        'misc_charge_comment' => $jobModel->getMiscChargeComment(),
                        'misc_charge_type' => $jobModel->getMiscChargeType(),
                        'grand_total' => number_format((float) $jobModel->getGrandTotal(), 2, '.', ''),
                        'time_to_fix' => $jobModel->getTimeToFix()
                    ];
                }
            } else {
                $jobModel->setLabourCharge('');
                $jobModel->setLabourChargeComment('');
                $jobModel->setMiscCharge('');
                $jobModel->setMiscChargeComment('');
                $jobModel->setMiscChargeType('');
                $jobModel->setTimeToFix('');
            }

            $cartDetail = $this->_sparePartsApiFactory->create()->getCartDetail($dealerId, $jobNo);
            //print_r($cartDetail);die;

            if (isset($cartDetail[0]['cart_items'])) {
                $response[0]['cart_detail'] = $cartDetail[0];
            }

            $jobModel->save();
            $serviceModel->save();

            $response[0]['status'] = 1;
            $response[0]['message'] = __('Job card details updated');
        } catch (Exception $ex) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Something went wrong. Please try again later');
        }

        if (count($unavailableParts)) {
            $response[0]['error'] = implode(', ', $unavailableParts) . ' part is not available';
        }

        return $response;
    }

    /**
     * @param int $jobNo
     * @return mixed
     */
    public function getSparePartsTotal($jobNo) {
        $response = [
            'sub_total' => 0.00,
            'cgst' => 0.00,
            'sgst' => 0.00
        ];

        try {
            $serviceJobParts = $this->_serviceJobPartsFactory->create()
                    ->getCollection()
                    ->addFieldToSelect(['qty', 'price', 'cgst', 'sgst', 'sub_total'])
                    ->addFieldToFilter('job_no', ['eq' => $jobNo]);
            //->addExpressionFieldToSelect('total', 'SUM({{sub_total}})', 'sub_total')
            //->setPageSize(1);

            if ($serviceJobParts->getSize()) {
                $cgst = 0.00;
                $sgst = 0.00;
                $subTotal = 0.00;

                foreach ($serviceJobParts as $serviceJobPart) {
                    $cgst += $serviceJobPart->getQty() * $serviceJobPart->getCgst();
                    $sgst += $serviceJobPart->getQty() * $serviceJobPart->getSgst();
                    $subTotal += $serviceJobPart->getSubTotal();
                }

                $response = [
                    'sub_total' => $subTotal,
                    'cgst' => $cgst,
                    'sgst' => $sgst
                ];
            }
        } catch (Exception $ex) {
            
        }

        return $response;
    }

    /**
     * Get Close Job Card Detail
     * @param int $dealerId
     * @param int $srId
     * @return mixed
     */
    public function getCloseJobCard($dealerId, $srId) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong');

        if (!$this->_commonHelper->isEtcPermissons($dealerId)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        if (empty($srId)) {
            $response[0]['message'] = __('Service request number is empty');
            return $response;
        } else {
            $jobData = $this->getServiceRequestJobNo($srId);
            if (!empty($jobData['job_no'])) {
                $jobNo = $jobData['job_no'];
            } else {
                $response[0]['message'] = __('Job number not generated for service request');
                return $response;
            }
        }

        $jobModel = $this->_jobNoFactory->create()->load($jobNo);
        if (empty($jobModel->getId())) {
            $response[0]['message'] = __('Please enter valid Job No');
            return $response;
        }

        $etcRemark = $this->_commonHelper::CONST_NULL;
        $nextJobs = $this->_commonHelper::CONST_NULL;
        if ($jobModel->getId()) {
            $serviceModel = $this->_serviceFactory->create()->load($jobModel->getSrid());
            $jobCardModel = $this->serviceJobCardFactory->create()->load($jobNo, 'job_no');

            if ($jobCardModel->getId()) {
                $etcRemark = $jobCardModel->getEtcRemark();
                $nextJobs = $jobCardModel->getNextJobs();
            }

            $grandTotal = 0.00;
            $amounts = $this->getSparePartsTotal($jobNo);
            $grandTotal += (float) $amounts['sub_total'] + $amounts['cgst'] + $amounts['sgst'];
            $grandTotal += (float) $jobModel->getLabourCharge();
            $grandTotal += (float) $jobModel->getMiscCharge();

            $response[0]['details'] = [
                'total' => number_format((float) $amounts['sub_total'], 2, '.', ''),
                'cgst' => number_format((float) $amounts['cgst'], 2, '.', ''),
                'sgst' => number_format((float) $amounts['sgst'], 2, '.', ''),
                'labour_charge' => number_format((float) $jobModel->getLabourCharge(), 2, '.', ''),
                'labour_charge_comment' => $jobModel->getLabourChargeComment(),
                'misc_charge' => number_format((float) $jobModel->getMiscCharge(), 2, '.', ''),
                'misc_charge_comment' => $jobModel->getMiscChargeComment(),
                'misc_charge_type' => $jobModel->getMiscChargeType(),
                'grand_total' => number_format((float) $grandTotal, 2, '.', ''),
                'workshop_bill_no' => $this->_commonHelper::CONST_NULL,
                'warranty_claim_no' => $this->_commonHelper::CONST_NULL,
                'status' => $jobModel->getStatus(),
                'job_closure_time' => $this->_commonHelper::CONST_NULL,
                'customer_remark' => $serviceModel->getCustomerComment(),
                'etc_remark' => $etcRemark,
                'next_jobs' => $nextJobs
            ];

            $response[0]['status'] = 1;
            $response[0]['message'] = __('Job details');
        }

        return $response;
    }

    /**
     * Update Close Job Card Detil
     * @param int $dealerId
     * @param mixed $data
     * @return mixed
     */
    public function updateCloseJobCard($dealerId, $data) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong');

        if (!$this->_commonHelper->isEtcPermissons($dealerId)) {
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        if (empty($data['sr_id'])) {
            $response[0]['message'] = __('Service request number is empty');
            return $response;
        } else {
            $jobData = $this->getServiceRequestJobNo($data['sr_id']);
            if (!empty($jobData['job_no'])) {
                $data['job_no'] = $jobData['job_no'];
            } else {
                $response[0]['message'] = __('Job number not generated for service request');
                return $response;
            }
        }

        try {
            $jobModel = $this->_jobNoFactory->create()->load($data['job_no']);

            if ($jobModel->getServiceFormId()) {
                $response[0]['message'] = __('Job card already closed');
                return $response;
            }

            if (empty($jobModel->getId())) {
                $response[0]['message'] = __('Job number is not valid');
                return $response;
            }

            if ($jobModel->getId()) {
                $serviceModel = $this->_serviceFactory->create()->load($jobModel->getSrid());

                $jobCardModel = $this->serviceJobCardFactory->create()->load($data['job_no'], 'job_no');

                if (isset($data['labour_charge'])) {
                    if (is_float((float) $data['labour_charge'])) {
                        $jobModel->setLabourCharge($data['labour_charge']);
                    }
                }

                if (isset($data['labour_charge_comment'])) {
                    $jobModel->setLabourChargeComment($data['labour_charge_comment']);
                }

                if (isset($data['misc_charge'])) {
                    if (is_float((float) $data['misc_charge'])) {
                        $jobModel->setMiscCharge($data['misc_charge']);
                    }
                }

                if (isset($data['misc_charge_comment'])) {
                    $jobModel->setMiscChargeComment($data['misc_charge_comment']);
                }

                if (isset($data['misc_charge_type'])) {
                    $jobModel->setMiscChargeType($data['misc_charge_type']);
                }

                if (empty($jobCardModel->getId())) {
                    $jobCardModel->setJobNo($data['job_no']);
                }

                if (isset($data['etc_remark'])) {
                    $jobCardModel->setEtcRemark($data['etc_remark']);
                }

                if (isset($data['next_jobs'])) {
                    $jobCardModel->setNextJobs($data['next_jobs']);
                }

                if (isset($data['status']) && $data['status'] > 0) {
                    $jobModel->setClosedAt($this->_timezone->date()->format('Y-m-d H:i:s'));

                    if (isset($data['lat'])) {
                        $jobModel->setLatClose($data['lat']);
                    }

                    if (isset($data['long'])) {
                        $jobModel->setLongClose($data['long']);
                    }

                    $jobModel->setStatus($data['status']);
                    $this->_commonHelper->inactiveJobCart($dealerId, $data['job_no']);

                    $serviceModel->save();
                    $jobCardModel->save();

                    $grandTotal = 0.00;
                    $amounts = $this->getSparePartsTotal($data['job_no']);
                    $grandTotal += (float) $amounts['sub_total'] + $amounts['cgst'] + $amounts['sgst'];
                    $grandTotal += (float) $jobModel->getLabourCharge();
                    $grandTotal += (float) $jobModel->getMiscCharge();

                    switch ($data['status']) {
                        case 1:
                            $serviceModel->setStatus(SR_STATUS_COMPLETED);
                            $response[0]['message'] = __('Job card closed successfully');

                            /* SMS to customer for Service Request Completion with Feedback link */

                            $encodedKey = base64_encode($serviceModel->getCustomerId() . '+' . $serviceModel->getId());
                            $longUrl = $this->_storeManager->getStore()->getUrl('servicerequest/feedback/index', ['key' => $encodedKey]);
                            $responseUrl = $this->_bitlyHelper->getFeedbackShortUrl($longUrl);
                            $responseUrl = !empty($responseUrl) ? $responseUrl : $longUrl;
                            $jobId = str_pad($data['job_no'], 10, '0', STR_PAD_LEFT);
                            $_srid = str_pad($serviceModel->getId(), 10, '0', STR_PAD_LEFT);

                            $mobileNumber = $this->_commonHelper->getCustomerMobileByID($serviceModel->getCustomerId());
                            //$mobileNumber = '8285922161';
                            $params = [
                                'jobid' => $jobId,
                                'srid' => $_srid,
                                'url' => $responseUrl
                            ];
                            $this->_smsNotificationHelper->jobCardCompleteNotificationToCustomer($mobileNumber, $params);

                            /* Email to Digitrac Admin for Service Request Completion with Payment Details */
                            $sdName = $this->_commonHelper->getCustomerNameById($serviceModel->getAssignedTo());
                            $sdMobile = $this->_commonHelper->getCustomerMobileByID($serviceModel->getAssignedTo());
                            $parameters = [
                                'sr_id' => '#' . $_srid,
                                'sr_created_at' => $serviceModel->getCreatedAt(),
                                'sd_name' => $sdName,
                                'sd_mobile' => $sdMobile,
                                'job_id' => '#' . $jobId,
                                'opened_at' => $jobModel->getCreatedAt(),
                                'closed_at' => $jobModel->getClosedAt(),
                                'sub_total' => $this->_commonHelper->getFormattedPrice($amounts['sub_total']),
                                'cgst' => $this->_commonHelper->getFormattedPrice($amounts['cgst']),
                                'sgst' => $this->_commonHelper->getFormattedPrice($amounts['sgst']),
                                'labour_charge' => $this->_commonHelper->getFormattedPrice($jobModel->getLabourCharge()),
                                'labour_comment' => $jobModel->getLabourChargeComment(),
                                'misc_charge' => $this->_commonHelper->getFormattedPrice($jobModel->getMiscCharge()),
                                'misc_charge_type' => $jobModel->getMiscChargeComment(),
                                'grand_total' => $this->_commonHelper->getFormattedPrice($grandTotal)
                            ];
                            $this->_emailNotify->sendJobCardCloseNotification($parameters, $data['job_no']);
                            //echo "<pre>"; print_r($parameters); echo "</pre>";
                            break;
                        case 2:

                            $serviceModel->setStatus(SR_STATUS_CANCELLED);
                            $response[0]['message'] = __('Job card cancelled successfully');

                            /* SMS to customer for Service Request Cancellation */
                            $jobId = str_pad($data['job_no'], 10, '0', STR_PAD_LEFT);
                            $_srid = str_pad($serviceModel->getId(), 10, '0', STR_PAD_LEFT);
                            $mobileNumber = $this->_commonHelper->getCustomerMobileByID($serviceModel->getCustomerId());
                            //$mobileNumber = '8285922161';
                            $params = [
                                'jobid' => $jobId,
                                'srid' => $_srid
                            ];
                            $this->_smsNotificationHelper->jobCardCancelNotificationToCustomer($mobileNumber, $params);

                            /* Email to Digitrac Admin for Service Request Cancellation */

                            $sdName = $this->_commonHelper->getCustomerNameById($serviceModel->getAssignedTo());
                            $sdMobile = $this->_commonHelper->getCustomerMobileByID($serviceModel->getAssignedTo());
                            $parameters = [
                                'sr_id' => '#' . $_srid,
                                'sr_created_at' => $serviceModel->getCreatedAt(),
                                'sd_name' => $sdName,
                                'sd_mobile' => $sdMobile,
                                'job_id' => '#' . $jobId,
                                'opened_at' => $jobModel->getCreatedAt(),
                                'cancelled_at' => $jobModel->getClosedAt(),
                                'sub_total' => $this->_commonHelper->getFormattedPrice($amounts['sub_total']),
                                'cgst' => $this->_commonHelper->getFormattedPrice($amounts['cgst']),
                                'sgst' => $this->_commonHelper->getFormattedPrice($amounts['sgst']),
                                'labour_charge' => $this->_commonHelper->getFormattedPrice($jobModel->getLabourCharge()),
                                'labour_comment' => $jobModel->getLabourChargeComment(),
                                'misc_charge' => $this->_commonHelper->getFormattedPrice($jobModel->getMiscCharge()),
                                'misc_charge_type' => $jobModel->getMiscChargeComment(),
                                'grand_total' => $this->_commonHelper->getFormattedPrice($grandTotal)
                            ];
                            $this->_emailNotify->sendJobCardCancelNotification($parameters, $data['job_no']);
                            //echo "<pre>"; print_r($parameters); echo "</pre>";
                            break;
                    }
                    /* Generate Service Dealer Invoice as Applicable */
                    $sdMobile = $this->_commonHelper->getCustomerMobileByID($serviceModel->getAssignedTo());
                    $poMobile = $this->_commonHelper->getCustomerMobileByID($serviceModel->getAssignedPo());
                    /*$sdMobile = '8285922161';
                    $poMobile = '8630233796';*/
                    $jobId = '#'.str_pad($data['job_no'], 10, '0', STR_PAD_LEFT);
                    $_srid = '#'.str_pad($data['sr_id'], 10, '0', STR_PAD_LEFT);
                    $params = ['jobid' => $jobId, 'srid' => $_srid];
                    if (!empty($sdMobile)) {
                        $this->_smsNotificationHelper->jobCardCloseNotificationToSd($sdMobile, $params);
                    }
                    if (!empty($poMobile)) {
                        $this->_smsNotificationHelper->jobCardCloseNotificationToPo($sdMobile, $params);
                    }

                    $jobModel->setServiceFormId($jobCardModel->getId());
                } else {
                    $response[0]['message'] = __('Saved successfully');
                }
                // die();
                $serviceModel->save();
                $jobCardModel->save();

                $grandTotal = 0.00;
                $amounts = $this->getSparePartsTotal($data['job_no']);
                $grandTotal += (float) $amounts['sub_total'] + $amounts['cgst'] + $amounts['sgst'];
                $grandTotal += (float) $jobModel->getLabourCharge();
                $grandTotal += (float) $jobModel->getMiscCharge();

                $response[0]['details'] = [
                    'total' => number_format((float) $amounts['sub_total'], 2, '.', ''),
                    'cgst' => number_format((float) $amounts['cgst'], 2, '.', ''),
                    'sgst' => number_format((float) $amounts['sgst'], 2, '.', ''),
                    'labour_charge' => number_format((float) $jobModel->getLabourCharge(), 2, '.', ''),
                    'labour_charge_comment' => $jobModel->getLabourChargeComment(),
                    'misc_charge' => number_format((float) $jobModel->getMiscCharge(), 2, '.', ''),
                    'misc_charge_comment' => $jobModel->getMiscChargeComment(),
                    'misc_charge_type' => $jobModel->getMiscChargeType(),
                    'grand_total' => number_format((float) $grandTotal, 2, '.', ''),
                        //'workshop_bill_no' => $this->_commonHelper::CONST_NULL,
                        //'warranty_claim_no' => $this->_commonHelper::CONST_NULL,
                        //'status' => $jobModel->getStatus(),
                        //'job_closure_time' => $this->_commonHelper::CONST_NULL,
                        //'customer_remark' => $this->_commonHelper::CONST_NULL,
                        //'etc_remark' => $this->_commonHelper::CONST_NULL,
                        //'next_jobs' => $this->_commonHelper::CONST_NULL
                ];

                $response[0]['status'] = 1;
            }

            $jobModel->save();
        } catch (Exception $ex) {
            
        }

        return $response;
    }

    /**
     *  View Job Card All Tab
     * @param int $dealerId
     * @param int $srId
     * @return mixed
     */
    public function viewJobCardMain($dealerId, $srId) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong');

        if (!$this->_commonHelper->isEtcPermissons($dealerId)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        if (empty($srId)) {
            $response[0]['message'] = __('Service request number is empty');
            return $response;
        } else {
            $jobNo = 0;
            $srType = 0;
            $serviceModel = $this->_serviceFactory->create()->load($srId);
            if ($serviceModel->getId()) {
                $srType = $serviceModel->getServiceRequestType();
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('Service request number is not valid');
                return $response;
            }

            if (in_array($srType, [SR_TYPE_ROUTINE, SR_TYPE_REPAIR])) {
                try {
                    $joblistCollection = $this->_jobNoFactory->create()->getCollection();
                    $joblistCollection->addFieldToSelect(['id']);
                    $joblistCollection->addFieldToFilter('main_table.srid', ['eq' => $srId]);
                    $joblistCollection->addFieldToFilter('main_table.service_request_type', ['eq' => $srType]);
                    $joblistCollection->addFieldToFilter('main_table.service_request_type', ['nin' => ['1', '2']]);
                    $joblistCollection->addFieldToFilter('main_table.status', ['in' => [1, 2]]); /* status must be Closed 1, Cancelled 2 */
                    $joblistCollection->getSelect()
                            ->join(['srTable' => $joblistCollection->getTable('escorts_service_request')], "main_table.srid= srTable.id", ['service_request_type'])
                            ->join(['tractorTable' => $joblistCollection->getTable('escorts_customer_tractor')], "tractorTable.tractor_id=srTable.tractor_id", ['serial_number', 'engine_number', 'delivery_date', 'model_id', 'registration_no', 'customer_id', 'tractor_id'])
                            ->where('srTable.assigned_to=' . $dealerId);

                    if ($joblistCollection->getSize()) {
                        $jobCart = $joblistCollection->getData();
                        $jobNo = $jobCart[0]['id'];
                    }
                } catch (Exception $ex) {
                    $response[0]['status'] = 0;
                    $response[0]['message'] = __('Something went wrong');
                }
            }
            if (empty($jobNo)) {
                $response[0]['message'] = __('Job number not available for given service request');
                return $response;
            }
        }
        /* Response Data */
        try {
            if ($joblistCollection->getSize()) {
                $jobCart = $joblistCollection->getData();
                $response[0]['job_no'] = $jobCart[0]['id'];

                $modelName = $this->_modelMasterFactory->create()->load($jobCart[0]['model_id'])->getModelName();
                $installationDate = $this->_commonHelper::CONST_NULL;

                if (!empty($this->jobcardHelper->getinstallationDate($jobCart[0]['tractor_id']))) {
                    $installationDate = $this->jobcardHelper->getinstallationDate($jobCart[0]['tractor_id']);
                    if ($installationDate == "0000-00-00 00:00:00" || empty($installationDate)) {
                        $installationDate = $this->_commonHelper::CONST_NULL;
                    } else {
                        $installationDate = date("Y-m-d", strtotime($installationDate));
                    }
                }

                $response[0]['tractor_detail'] = [
                    'registration_no' => $jobCart[0]['registration_no'],
                    'serial_number' => $jobCart[0]['serial_number'],
                    'engine_number' => $jobCart[0]['engine_number'],
                    'warranty_upto' => '2020-06-31',
                    'model' => $modelName,
                    'delivery_date' => date("Y-m-d", strtotime($jobCart[0]['delivery_date'])),
                    'installation_date' => $installationDate
                ];

                //Customer default shipping address
                $customer = $this->_customerFactory->create()->load($jobCart[0]['customer_id']);
                $shippingAddressId = $customer->getDefaultShipping();
                $address = $this->_addressModel->load($shippingAddressId);

                if ($address) {
                    $streetAaddress = $address->getStreet();
                    if (!empty($streetAaddress)) {
                        $streetAaddress = implode(',', $streetAaddress);
                    }
                    $state = $address->getRegionId();
                    if (is_numeric($state)) {
                        $state = $this->_regionFactory->create()->load($state)->getName();
                    }
                    $response[0]['customer_detail'] = [
                        'customer_id' => $customer->getEntityId(),
                        'address_id' => $shippingAddressId,
                        'mobile_number' => $address->getTelephone(),
                        'customer_name' => $customer->getName(),
                        'father_name' => $customer->getFatherName(),
                        'alternative_mobile' => $address->getAltMobileNumber(),
                        'dob' => $customer->getDob(),
                        'email_id' => $customer->getEmail(),
                        'state' => $state,
                        'district' => $address->getCity(),
                        'tehsil' => $address->getTehsil(),
                        'village' => $address->getVillage(),
                        'address' => $streetAaddress,
                        'post_code' => $address->getPostcode()
                    ];
                }

                $jobCardCollection = $this->_jobNoFactory->create()->getCollection();
                $jobCardCollection->addFieldToSelect(['id', 'status', 'created_at']);
                $jobCardCollection->getSelect()
                        ->join(['secondTable' => $jobCardCollection->getTable('escorts_service_job_card')], 'secondTable.job_no = main_table.id', ['meter_reading', 'fuel_level'])
                        ->join(['srTable' => $jobCardCollection->getTable('escorts_service_request')], "main_table.srid= srTable.id", ['customer_id', 'service_request_type', 'service_no', 'coupon_code'])
                        ->where('main_table.id=' . $jobNo);
                $date = "";
                if ($jobCardCollection->getSize()) {
                    $jobCard = $jobCardCollection->getFirstItem()->getData();
                    if (!empty($jobCard['created_at'])) {
                        $date = date("Y-m-d", strtotime($jobCard['created_at']));
                    }
                    $response[0]['open_jobcard_detail'] = [
                        'job_card_date' => $date,
                        'service_request_type' => $jobCard['service_request_type'],
                        'service_no' => $jobCard['service_no'],
                        'coupon_number' => $jobCard['coupon_code'],
                        'meter_reading' => $jobCard['meter_reading'],
                        'last_meter_reading' => $jobCard['meter_reading'],
                        'fuel_level' => $jobCard['fuel_level']
                    ];
                }

                $jobModel = $this->_jobNoFactory->create()->load($jobNo);
                if (empty($jobModel->getId())) {
                    $response[0]['message'] = __('Job number not available for service request');
                    return $response;
                }

                $etcRemark = $this->_commonHelper::CONST_NULL;
                $nextJobs = $this->_commonHelper::CONST_NULL;
                if ($jobModel->getId()) {
                    $serviceModel = $this->_serviceFactory->create()->load($srId);
                    $jobCardModel = $this->serviceJobCardFactory->create()->load($jobNo, 'job_no');
                    if ($jobCardModel->getId()) {
                        $etcRemark = $jobCardModel->getEtcRemark();
                        $nextJobs = $jobCardModel->getNextJobs();
                    }

                    $grandTotal = 0.00;
                    $amounts = $this->getSparePartsTotal($jobNo);
                    $grandTotal += (float) $amounts['sub_total'] + $amounts['cgst'] + $amounts['sgst'];
                    $grandTotal += (float) $jobModel->getLabourCharge();
                    $grandTotal += (float) $jobModel->getMiscCharge();

                    $response[0]['close_jobcart_detail'] = [
                        'total' => $amounts['sub_total'],
                        'cgst' => $amounts['cgst'],
                        'sgst' => $amounts['sgst'],
                        'labour_charge' => $jobModel->getLabourCharge(),
                        'labour_charge_comment' => $jobModel->getLabourChargeComment(),
                        'misc_charge' => $jobModel->getMiscCharge(),
                        'misc_charge_comment' => $jobModel->getMiscChargeComment(),
                        'misc_charge_type' => $jobModel->getMiscChargeType(),
                        'grand_total' => $grandTotal,
                        'workshop_bill_no' => $this->_commonHelper::CONST_NULL,
                        'warranty_claim_no' => $this->_commonHelper::CONST_NULL,
                        'status' => $jobModel->getStatus(),
                        'job_closure_time' => $this->_commonHelper::CONST_NULL,
                        'customer_remark' => $serviceModel->getCustomerComment(),
                        'etc_remark' => $etcRemark,
                        'next_jobs' => $nextJobs
                    ];
                }
                $response[0]['status'] = 1;
                $response[0]['message'] = __('Job card detail');
            }
        } catch (Exception $ex) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Something went wrong');
        }
        return $response;
    }

    /**
     * @param int $sdid
     * @param int $srId
     * @return mixed
     */
    public function shareHappyCode($sdid, $srId) {
        $response = [];
        $response[0] = ['status' => 0];
        $response[0]['message'] = __('Something went wrong');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        $serviceRequest = $this->_serviceFactory->create()->load($srId);

        if ($serviceRequest->getId() &&
                !in_array($serviceRequest->getStatus(), [SR_STATUS_COMPLETED, SR_STATUS_REJECTED, SR_STATUS_CANCELLED]) &&
                !$serviceRequest->getOtpVerified()) {
            $customer_data = $this->_customerFactory->create()
                    ->setWebsiteId($this->_storeManager->getStore()->getWebsiteId())
                    ->load($serviceRequest->getCustomerId());

            if (!empty($customer_data->getId())) {
                $mobileNumber = $customer_data->getMobileNumber();
                $otp = $this->_commonHelper->generateOtp();

                try {
                    $serviceRequest->setOtpValue($otp);
                    $serviceRequest->setOtpCreatedAt($this->_timezone->scopeTimeStamp());
                    $serviceRequest->save();

                    $tat = $this->_smsNotificationHelper->getInstallationCloseTat();
                    $params = [
                        'otp' => $otp,
                        'tat' => $tat
                    ];
                    $this->_smsNotificationHelper->sendHappyCode($mobileNumber, $params);

                    $response[0]['status'] = 1;
                    $response[0]['message'] = __('We have sent an OTP on Customer registered mobile number');
                } catch (Exception $ex) {
                    $response[0]['status'] = 0;
                    $response[0]['message'] = __('Something went wrong');
                }
            } else {
                $response[0]['status'] = 0;
                $response[0]['message'] = __('Customer details not available');
            }
        } else {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('Can not generate OTP for this Service Request');
        }

        return $response;
    }

    /**
     * @param int $sdid
     * @param int $srId
     * @param string $otp
     * @return mixed
     */
    public function verifyHappyCode($sdid, $srId, $otp) {
        $response = [];
        $response[0]['status'] = 0;
        $response[0]['message'] = __('Something went wrong please try again later');

        if (!$this->_commonHelper->isEtcPermissons($sdid)) {
            $response[0]['status'] = 0;
            $response[0]['message'] = __('You aren\'t authorized user');
            return $response;
        }

        $serviceRequest = $this->_serviceFactory->create()->load($srId);

        if ($serviceRequest->getCustomerId()) {
            $systemOtp = is_null($serviceRequest->getOtpValue()) ? '' : $serviceRequest->getOtpValue();
            $time = is_null($serviceRequest->getOtpCreatedAt()) ? '' : $serviceRequest->getOtpCreatedAt();
            $diff = round(abs($this->_timezone->scopeTimeStamp() - $time) / 60);
            $tat = $this->_smsNotificationHelper->getInstallationCloseTat();

            if ($time && $systemOtp) {
                if ($diff <= $tat) {
                    if ($systemOtp === trim($otp)) {
                        try {
                            $serviceRequest->setOtpValue('');
                            $serviceRequest->setOtpCreatedAt('');
                            $serviceRequest->setOtpVerified(1);
                            $serviceRequest->save();
                            $response[0]['status'] = 1;
                            $response[0]['message'] = __('Verified');
                        } catch (Exception $ex) {
                            $response[0]['status'] = 0;
                            $response[0]['message'] = __('Something went wrong');
                        }
                    } else {
                        $response[0]['status'] = 0;
                        $response[0]['message'] = __('OTP is Wrong');
                    }
                } else {
                    $response[0]['status'] = 0;
                    $response[0]['message'] = __('OTP has been expired');
                }
            }
        }

        return $response;
    }

    public function getJobStatusStr($status) {
        foreach ($this->_commonHelper::JOB_STATUSES as $jobStatus) {
            if ($jobStatus['id'] == $status) {
                return $jobStatus['value'];
            }
        }
    }

    /**
     * Get Service Request Type in string
     * @param int $srType
     * @return string
     */
    public function getSrTypeString($srType) {
        $srTypes = $this->_serviceRequestTypeFactory->create()
                ->getCollection()
                ->addFieldToFilter('id', ['eq' => $srType])
                ->setPageSize(1);
        return $srTypes->getFirstItem()->getValue();
    }

    /* public function getCurrency()
      {
      return $this->_commonHelper->getStoreCurrencySymbol();
      }

      public function getFormattedPrice($price)
      {
      return $this->getCurrency().number_format((float) $price, 2, '.', '');
      } */
}
