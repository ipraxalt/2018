<?php

/**
 * Escorts
 */

namespace Escorts\JobCard\Helper;

use Magento\Store\Model\ScopeInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper {

    const XML_TAT_JOB_CARD = 'jobcard/general/tat';

    protected $_jobNoFactory;
    protected $_customerTractorFactory;
    protected $_serviceFactory;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Escorts\ServiceRequest\Model\ServiceJobNoFactory $jobNoFactory
     * @param \Escorts\ServiceRequest\Model\CustomerTractorFactory $_customerTractorFactory
     * @param \Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory
     */
    public function __construct(\Magento\Framework\App\Helper\Context $context, \Escorts\ServiceRequest\Model\ServiceJobNoFactory $jobNoFactory, \Escorts\ServiceRequest\Model\CustomerTractorFactory $_customerTractorFactory, \Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory) {
        $this->_jobNoFactory = $jobNoFactory;
        $this->_customerTractorFactory = $_customerTractorFactory;
        $this->_serviceFactory = $serviceFactory;
        parent::__construct($context);
    }

    /**
     * @param string $field
     * @param int $storeId
     * @return mixed
     */
    public function getConfigValue($field, $storeId = null) {
        return $this->scopeConfig->getValue($field, ScopeInterface::SCOPE_STORE, $storeId);
    }

    /**
     * Get Job Card TAT
     * @return int
     */
    public function getJobCardTat() {
        return $this->getConfigValue(self::XML_TAT_JOB_CARD);
    }

    /**
     * Get Tractor Installation Close Date
     * @param int $tractorId
     * @return string
     */
    public function getinstallationDate($tractorId) {
        try {
            $installationDate = "";
            $collection = $this->_customerTractorFactory->create()->getCollection();
            $collection->addFieldToFilter('main_table.tractor_id', ['eq' => $tractorId]);
            $collection->getSelect()
                    ->join(['srTable' => $collection->getTable('escorts_service_request')], "main_table.tractor_id=srTable.tractor_id", ['id'])
                    ->join(['jobnoTable' => $collection->getTable('escorts_service_job_no')], "jobnoTable.srid=srTable.id", ['closed_at'])
                    ->where('jobnoTable.service_request_type=' . SR_TYPE_INSTALLATION);
            $collection->addFieldToFilter('jobnoTable.closed_at', ['neq' => NULL]);
            if (!empty($collection->getSize())) {
                $tracObj = $collection->getData();
                $installationDate = $tracObj[0]['closed_at'];
            }
        } catch (Exception $e) {
            //echo 'Message: ' . $e->getMessage();
        }
        return $installationDate;
    }

    /**
     * Check part is in warranty or not
     * @param int $tractorId
     * @return boolean
     */
    public function isInWarranty() {
        return false;
    }

}
