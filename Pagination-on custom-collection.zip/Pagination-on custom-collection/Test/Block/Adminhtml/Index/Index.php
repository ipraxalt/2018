	<?php

namespace Company\Test\Block\Adminhtml\Index;
use Company\Test\Model\Test;

class Index extends \Magento\Backend\Block\Widget\Container
{



    public function __construct(\Magento\Backend\Block\Widget\Context $context,Test $model, array $data = [])
    {
		 $this->model = $model;
        parent::__construct($context, $data);
    }

	 public function getNewsCollection(){
            $helloCollection = $this->model->getCollection();
            return $helloCollection;
     }


}
