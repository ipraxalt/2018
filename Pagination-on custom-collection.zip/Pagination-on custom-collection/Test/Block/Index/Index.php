<?php

namespace Company\Test\Block\Index;
use Company\Test\Model\Test;


class Index extends \Magento\Framework\View\Element\Template {

    public function __construct(\Magento\Catalog\Block\Product\Context $context,Test $model,  array $data = []) {
		$this->model = $model;

        parent::__construct($context, $data);

    }


     protected function _prepareLayout()
    {

        parent::_prepareLayout();
        $this->pageConfig->getTitle()->set(__('My Reward History'));

        if ($this->getNewsCollection()) {
            $pager = $this->getLayout()->createBlock(
                'Magento\Theme\Block\Html\Pager',
                'test.news.pager'
            )->setAvailableLimit(array(2=>2,4=>4,6=>6,8=>8))
                ->setShowPerPage(true)->setCollection(
                $this->getNewsCollection()
            );
            $this->setChild('pager', $pager);
            $this->getNewsCollection()->load();
        }
        return $this;
    }

	
	

public function getPagerHtml()
{
    return $this->getChildHtml('pager');
}
	
	
	 public function getFormAction(){
        return $this->getUrl('test/index/post', ['_secure' => true]);
    }

	
	 public function getNewsCollection(){
		 
		 //get values of current page
        $page=($this->getRequest()->getParam('p'))? $this->getRequest()->getParam('p') : 1;
        //get values of current limit
        $pageSize=($this->getRequest()->getParam('limit'))? $this->getRequest
        ()->getParam('limit') : 2;
		
            $helloCollection = $this->model->getCollection();
			$helloCollection->setPageSize($pageSize);
        $helloCollection->setCurPage($page);
            return $helloCollection;
     }
	 
}