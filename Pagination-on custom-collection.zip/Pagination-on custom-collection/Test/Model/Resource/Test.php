<?php

namespace Company\Test\Model\Resource;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Test extends AbstractDb
{
    /**
     * Define main table
     */
	 
    protected function _construct()
    {
        $this->_init('company_test', 'id');
    }
}