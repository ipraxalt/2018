<?php
namespace Company\Test\Model\Resource\Test;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * Define model & resource model
     */
    protected function _construct()
    {
        $this->_init(
            'Company\Test\Model\Test',
            'Company\Test\Model\Resource\Test'
        );
    }
}