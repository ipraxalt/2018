<?php

/**
 * Copyright © 2015 Escorts . All rights reserved.
 */

namespace Escorts\SmsNotification\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper {

    /**
     * Path to store config
     *
     * @var string
     */
    const XML_SMS_BASEURL = 'escorts_sms/smsnotification/baseurl';
    const XML_SMS_USERNAME = 'escorts_sms/smsnotification/username';
    const XML_SMS_PASSWORD = 'escorts_sms/smsnotification/password';
    const XML_SMS_FROM = 'escorts_sms/smsnotification/smsfrom';

    /**
     * @var \Magento\Framework\HTTP\Client\Curl
     */
    protected $_curl;
    
    protected $_encryptor;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Escorts\Common\Helper\Data $commonHelper
     */
    public function __construct(
    \Magento\Framework\App\Helper\Context $context,
            \Magento\Framework\HTTP\Client\Curl $curl,
            \Magento\Framework\Encryption\EncryptorInterface $encryptor
    ) {
        $this->_curl = $curl;
        $this->_encryptor = $encryptor;
        parent::__construct($context);
    }

    /*     * $params
     * Retun Default URL
     *
     * @return String
     */

    public function getSmsGatewayCredentials() {
        return array(
            'baseurl' => $this->scopeConfig->getValue(
                    self::XML_SMS_BASEURL, \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            ),
            'username' => $this->scopeConfig->getValue(
                    self::XML_SMS_USERNAME, \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            ),
            'password' => $this->scopeConfig->getValue(
                    self::XML_SMS_PASSWORD, \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            ),
            'smsfrom' => $this->scopeConfig->getValue(
                    self::XML_SMS_FROM, \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            )
        );
    }

    //http://www.myvaluefirst.com/smpp/sendsms?username=esctest&password=tac2i4ra&to=9971822209&from=ESCORT&text=hi Alok this is test
    public function sendSms($mobileNumber, $message) {
        $credentials = $this->getSmsGatewayCredentials();

        if (!empty($credentials['baseurl']) &&
                !empty($credentials['username']) &&
                !empty($credentials['password'])) {
            $credentials['password'] = $this->getDecryptedString($credentials['password']);

            $params = array(
                'username' => $credentials['username'],
                'password' => $credentials['password'],
                'to' => $mobileNumber,
                'from' => $credentials['smsfrom'],
                'text' => $message
            );

            try {
                //if the method is get
                $this->_curl->get($credentials['baseurl'] . '?' . http_build_query($params));
                //if the method is post
                //$this->_curl->post($url, $params);
                //response will contain the output in form of JSON string
                $response = $this->_curl->getBody();

                if ($response == 'Sent.') {
                    return true;
                } else {
                    return false;
                }
            } catch (\Exception $e) {
                //echo $e;
                return false;
            }
        }
        return false;
    }
    
    /**
     * Return Decryped String
     *
     * @return String or Boolean
     */
    public function getDecryptedString($passString) {
        if (!empty($passString)) {
            return $this->_encryptor->decrypt($passString);
        }
        return false;
    }

}
