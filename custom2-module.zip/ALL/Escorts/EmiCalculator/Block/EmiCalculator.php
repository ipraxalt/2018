<?php
namespace Escorts\EmiCalculator\Block;

class EmiCalculator extends \Magento\Framework\View\Element\Template implements \Magento\Widget\Block\BlockInterface
{
    //https://magently.com/blog/magento-2-widgets-tutorial/
    
}