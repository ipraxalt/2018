<?php
/**
 * Copyright © 2015 Escorts. All rights reserved.
 */
namespace Escorts\CustomCron\Model\ResourceModel;

/**
 * CronStatus resource
 */
class CronStatus extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('escorts_service_request_notification', 'id');
    }

  
}
