<?php
/**
 * Copyright © 2015 Escorts . All rights reserved.
 */
namespace Escorts\CustomCron\Helper;

use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Store\Model\ScopeInterface;
use Psr\Log\LoggerInterface;
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	/**
     * Service Dealer Customer Group ID
     *
     * @var int
     */
	//const SD_GROUP_ID = 4;
	const ATTRIBUTE_SET_ID = 13;
	const ORDER_STATUS_DELIVERED = 'delivered';
	const ORDER_STATUS_COMPLETE = 'complete';
	const EMAIL_TEMPLATE_ID = 'service_request_notification';
	const EMAIL_SUBJECT = 'Service Request Notification';
	//const ORDER_INSTALLATION_DAY_FIRST = 23;
	//const ORDER_INSTALLATION_DAY_SECOND = 30;

	/**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder ;

    /**
     * @var \Magento\Framework\Translate\Inline\StateInterface
     */
    protected $inlineTranslation ;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig ;

	/**
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     */
	protected $_orderFactory;

	/**
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     */
	protected $_productFactory;

	/**
     * @param \Escorts\CustomCron\Model\CronStatusFactory $cronStatusFactory
     */
	protected $_cronStatusFactory;

	/**
     * @param \Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory
     */
	protected $_serviceFactory;

	/**
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     */
	protected $_customerFactory;

	/**
     * @param \Escorts\PushNotification\Helper\Data $pushNotifyHelper
     */
	protected $_pushNotifyHelper;

	/**
     * @param \Psr\Log\LoggerInterface
     */
	protected $_logLoggerInterface;

	/**
     * @param \Magento\Framework\App\Helper\Context $context
     */
	public function __construct(
		\Magento\Framework\App\Helper\Context $context,
		\Magento\Sales\Model\OrderFactory $orderFactory,
		\Escorts\CustomCron\Model\CronStatusFactory $cronStatusFactory,
		\Magento\Catalog\Model\ProductFactory $productFactory,
		\Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory,
		\Magento\Customer\Model\CustomerFactory $customerFactory,
		\Escorts\PushNotification\Helper\Data $pushNotifyHelper,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Mail\Template\TransportBuilder $_transportBuilder,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Psr\Log\LoggerInterface $logLoggerInterface
	) {
		$this->_orderFactory = $orderFactory;
		$this->_cronStatusFactory = $cronStatusFactory;
		$this->_productFactory = $productFactory;
		$this->_serviceFactory = $serviceFactory;
		$this->_customerFactory = $customerFactory;
		$this->_pushNotifyHelper = $pushNotifyHelper;
		$this->storeManager = $storeManager;
        $this->_transportBuilder = $_transportBuilder;
        $this->inlineTranslation = $inlineTranslation;
        $this->scopeConfig = $scopeConfig;
        $this->_logLoggerInterface = $logLoggerInterface;
		parent::__construct($context);
	}

/*Get order from last 635 days.*/
/*Filter by status 'complate' or 'delivered'.*/
/**/
	public function getFirstInstallation(){
		$currentDate = date('Y-m-d');
		$days_ago = date('Y-m-d', strtotime('-635 days', strtotime($currentDate))); //exit();
		$orders = $this->_orderFactory->create()->getCollection();
		$orders->addAttributeToSelect("*")
				->addAttributeToFilter('status',array(
					'in' => array(self::ORDER_STATUS_DELIVERED,self::ORDER_STATUS_COMPLETE)
				))
			   ->addAttributeToFilter('delivery_date_1',array('gteq' => $days_ago))->load();

		foreach ($orders as $order) {
			// echo "<pre>"; print_r($order->getData()); echo "</pre>";
			$date = date('Y-m-d', strtotime($order->getDeliveryDate1()));
		    $currentData = date('Y-m-d');
		    $date1=date_create($currentData);
		    $date2=date_create($date);
		    $diff=date_diff($date1,$date2);
		    $days = $diff->format("%a");

			$serviceDueDate = $this->serviceDueDate($days,$order->getDeliveryDate1());
		  
			$items = $order->getAllItems();
			foreach ($items as $i) {
				$_product = $this->_productFactory->create()->load($i->getProductId());
				if ($_product->getAttributeSetId() == self::ATTRIBUTE_SET_ID ) {
					$serviceNo = $this->serviceTypeWithInDays($days);
					$cronCollection = $this->_cronStatusFactory->create()->getCollection();
					$cronCollection->addFieldToFilter('order_id',array('eq' => $order->getEntityId()))
						   		   ->addFieldToFilter('customer_id',array('eq' => $order->getCustomerId()))
								   ->addFieldToFilter('item_id',array('eq' => $i->getProductId()))
						   		   ->addFieldToFilter('service_no',array('eq' => $serviceNo));
					if ($cronCollection->getSize() == 0) {
						$ServiceRequestCollection = $this->_serviceFactory->create()->getCollection();
						$ServiceRequestCollection->addFieldToFilter('order_id',array('eq' => $order->getEntityId()))
												 ->addFieldToFilter('customer_id',array('eq' => $order->getCustomerId()))
												 ->addFieldToFilter('order_item_id',array('eq' => $i->getProductId()))
												 ->addFieldToFilter('service_no',array('eq' => $serviceNo));
						// echo "<pre>"; print_r($ServiceRequestCollection->getData()); echo "</pre>";
						$customerModel = $this->_customerFactory->create()->load($order->getCustomerId());//->load(16);
						// echo "<pre>"; print_r($customerModel->getData()); echo "</pre>";
						if (!$ServiceRequestCollection->getData()) {
							if ($customerModel->getDeviceId()) {
								$data = [];
								$data['code'] = 1;
								$data['type'] = "message";
								//Code comment by Rupak
								//$this->_pushNotifyHelper->sendPushNotificationToAndroid('New Message', 'Customer Service Request Notifications.', $customerModel->getDeviceId(), $data);
							}
						}

						$this->sendEmailNotification($order->getCustomerId(),$order->getCustomerEmail(),$customerModel->getMobileNumber(),$i->getName(),$serviceDueDate,$serviceNo);
					}
					
				}
			}
			
		}
		return true;
	}

	public function serviceTypeWithInDays($days)
	{
		$day_range_array = array(array('23','30'),array('83','90'),array('173','180'),array('263','270'),array('358','365'),array('448','455'),array('538','545'),array('628','635'));
		$i = 0;
		foreach ($day_range_array as $key => $day_range) {
			if ($days >= $day_range[0] && $days <= $day_range[1]) {
				return $i+1 ;
			}
			$i++;
		}
	}


	public function serviceDueDate($days,$deliveryDate)
	{
		$day_range_array = array(array('23','30'),array('83','90'),array('173','180'),array('263','270'),array('358','365'),array('448','455'),array('538','545'),array('628','635'));
		$i = 0;
		foreach ($day_range_array as $key => $day_range) {
			if ($days >= $day_range[0] && $days <= $day_range[1]) {
				return $days_ago = date('Y-m-d', strtotime('+'.$day_range[1].' days', strtotime($deliveryDate)));
				
			}
			$i++;
		}
	}

	public function sendEmailNotification($customerName,$customerEmail,$customerMobile,$itemName,$serviceDueDate,$serviceType)
	{
		try {
            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
            $storeId = $this->storeManager->getStore()->getId();
            $this->inlineTranslation->suspend();
            $transport = $this->_transportBuilder
               ->setTemplateIdentifier(self::EMAIL_TEMPLATE_ID)
               ->setTemplateOptions(
                    [
                        'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                        'store' => $storeId
                    ]
                )
               ->setTemplateVars([
                    'store' => $this->storeManager->getStore(),
                    'customer_name' => $customerName,
                    'mobile' => $customerMobile,
                    'item_name' => $itemName,
                    'service_type' => $serviceType,
                    'service_due_date' => $serviceDueDate,
                    'subject' => self::EMAIL_SUBJECT
                ])
               ->setFrom([
                        'email' => $customerEmail,
                        'name' => 'XYZ'
                    ])
               ->addTo($this->scopeConfig->getValue('testing150392@gmail.com', $storeScope))
               ->getTransport();
            $transport->sendMessage();
            $this->inlineTranslation->resume();

		} catch (Exception $e) {
			$this->_logLoggerInterface->debug($e->getMessage());
		}
	}
}