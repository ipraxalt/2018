<?php
namespace Escorts\CustomCron\Cron;
use \Psr\Log\LoggerInterface;
class ServiceRequestNotifications {
 
    protected $_logger;
 
    public function __construct(
        \Psr\Log\LoggerInterface $logger
    ) {
        $this->_logger = $logger;
    }
    
    /**
     * Method executed when cron runs in server
     */
    public function execute() {
        $this->_logger->info('Running Cron from FirstInstallation class');
        $this->_logger->debug('Cron run successfully');
        return $this;
    }
}