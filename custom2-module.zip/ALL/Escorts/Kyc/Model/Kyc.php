<?php
namespace Escorts\Kyc\Model;

class Kyc extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'escorts_tractor_kyc';
	protected $_cacheTag = 'escorts_tractor_kyc';
	protected $_eventPrefix = 'escorts_tractor_kyc';

	protected function _construct(){
		$this->_init('Escorts\Kyc\Model\ResourceModel\Kyc');
	}

	public function getIdentities(){
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues(){
		$values = [];
		return $values;
	}
}