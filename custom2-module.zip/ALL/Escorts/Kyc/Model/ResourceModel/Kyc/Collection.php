<?php
namespace Escorts\Kyc\Model\ResourceModel\Kyc;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'kyc_id';
	protected $_eventPrefix = 'escorts_kyc_kyc_collection';
	protected $_eventObject = 'tractor_kyc_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct(){
		$this->_init('Escorts\Kyc\Model\Kyc', 'Escorts\Kyc\Model\ResourceModel\Kyc');
	}
}