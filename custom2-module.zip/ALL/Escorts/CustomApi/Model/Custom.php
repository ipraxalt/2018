<?php
namespace Escorts\CustomApi\Model;
use Escorts\CustomApi\Api\CustomInterface;
use Magento\Framework\Phrase; 
 
class Custom implements CustomInterface 
{   

    protected $productRepository;
	protected $_productFactory;
	protected $_categoryFactory;
	protected $_blogPostFactory;
	protected $_view;
	protected $_request;
	protected $_tokenModel;
	protected $quoteFactory;
	protected $quoteModel;
	
    
    /**
     * @param \Magento\Catalog\Model\Product\LinkTypeProvider $linkTypeProvider
     */
	public function __construct(
	    \Magento\Framework\View\Asset\Repository $view,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,   
        \Magefan\Blog\Model\PostFactory $blogPostFactory,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Integration\Model\Oauth\Token $tokenModel,
        \Magento\Quote\Model\QuoteFactory $quoteFactory,
        \Magento\Quote\Model\ResourceModel\Quote $quoteModel 
    ) {
        $this->_categoryFactory = $categoryFactory;
        $this->_productFactory = $productFactory;
        $this->_blogPostFactory = $blogPostFactory;
        $this->_view = $view;
        $this->productRepository = $productRepository;
        $this->_request = $request;
        $this->_tokenModel = $tokenModel;
        $this->quoteFactory = $quoteFactory;
        $this->quoteModel=$quoteModel;
    }  
	
    public function getProducts($products) {
	
		$currentPage = 1;
		$pageSize = 10;
		$orderBy = 'position';
		$orderPosition = 'ASC';
		
		$currentPageCheck = array_key_exists('current_page', $products);
		if($currentPageCheck){ $currentPage = $products['current_page'];  }
		
		$pageSizeCheck = array_key_exists('page_size', $products);
		if($pageSizeCheck){ $pageSize = $products['page_size'];  }
		
		$orderBycheck = array_key_exists('order_by', $products);
		if($orderBycheck){ $orderBy = strtolower($products['order_by']);  }
		
		$orderPositionCheck = array_key_exists('order_position', $products);
		if($orderPositionCheck){ $orderPosition = strtoupper($products['order_position']);  }
		
		$response = array();
		$product = array();
		$categoryId = $products['cat_id'];
		$category = $this->_categoryFactory->create()->load($categoryId);
		$collection = $this->_productFactory->create()->getCollection();
		$collection->addAttributeToSelect('*');
		$collection->addCategoryFilter($category);
		$collection->addAttributeToFilter('visibility', \Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH);
		$collection->addAttributeToFilter('status',\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED);
		$collection->setOrder($orderBy,$orderPosition);
		$collection->setCurPage($currentPage);
		$collection->setPageSize($pageSize);
		
		$products = $collection->getData();      
			
		foreach($products as $keyParent => $product){
		$productObj = $this->_productFactory->create()->load($product['entity_id']);
		$response[$keyParent]['name'] = $productObj->getName();
		$response[$keyParent]['price'] = $productObj->getPrice();
		$response[$keyParent]['image'] = $this->getImageValidator($productObj->getImage());
		$response[$keyParent]['sku'] = $productObj->getSku();
		$response[$keyParent]['id'] = (int)$productObj->getId();

		$attributes = array(
		'power_take_off_hp'=> $productObj->getPowerTakeOffHp(),
		'number_of_cylinder'=> $productObj->getNumberOfCylinder(),
		'cubic_capacity'=> $productObj->getCubicCapacity(),
		'clutch'=> $productObj->getClutch(),
		'fuel_tank_capacity_ltrs'=> $productObj->getFuelTankCapacityLtrs()		
		 );
		 
		foreach($attributes as $key => $value){
		$attr = $productObj->getResource()->getAttribute($key);
			 if ($attr->usesSource()) {
				$response[$keyParent][$key] =  $optionText = $attr->getSource()->getOptionText($value);
			}
			
		 } // end key foreach
		 
		} // end keyParent foreach
		
		$returnValue[0]['items'] = $response;
		$returnValue[0]['total_size'] = $collection->count();
		$returnValue[0]['current_page'] = $currentPage;
		$returnValue[0]['page_size'] = $pageSize;
		$returnValue[0]['order_by'] = $orderBy;
		$returnValue[0]['order_position'] = $orderPosition;
		
		return $returnValue;
    
    }
    
    public function getHomePage($homeData){
		
		$response = array();
		$banner = array();
		$homeMenu = array();
		$offers = array();
		$mandi = array();
		
		// home banner code
		$banner[0]['title'] =  'Image 1';
		$banner[0]['image'] =  'pub/media/wysiwyg/mobile-banner/2.jpg';
		$banner[0]['cat_id'] =  4;
		$banner[0]['sku'] =  'Digitrac PP 46i';
		
		$banner[1]['title'] =  'Image 2';
		$banner[1]['image'] =  'pub/media/wysiwyg/mobile-banner/1.jpg';
		$banner[1]['cat_id'] =  4;
		$banner[1]['sku'] =  'Digitrac PP 41i';
		
		
		// home menu icon
		$homeMenu[0]['image'] =  'pub/media/wysiwyg/mobile-icon/icon.jpeg';
		$homeMenu[0]['text'] =  strtoupper('Doorstep Demo');
		
		$homeMenu[1]['image'] =  'pub/media/wysiwyg/mobile-icon/icon.jpeg';
		$homeMenu[1]['text'] =  strtoupper('Emi Calculator');
		
		$homeMenu[2]['image'] =  'pub/media/wysiwyg/mobile-icon/icon.jpeg';
		$homeMenu[2]['text'] =  strtoupper('Expert Advice');
		
		$homeMenu[3]['image'] =  'pub/media/wysiwyg/mobile-icon/icon.jpeg';
		$homeMenu[3]['text'] =  strtoupper('Free Evaluation');
		
		
		// spacial product
		$productResponse = array();
		$products = array();
		$categoryId = 4; // tractor id
		$category = $this->_categoryFactory->create()->load($categoryId);
		$collection = $this->_productFactory->create()->getCollection();
		$collection->addAttributeToSelect('*');
		$collection->addCategoryFilter($category);
		$collection->addAttributeToFilter('visibility', \Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH);
		$collection->addAttributeToFilter('status',\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED);
		$collection->addAttributeToFilter('special_price',['gt'=>0]);
		$collection->setCurPage(1);
		$collection->setPageSize(8);
		
		$products = $collection->getData();      
		$productResponse = array(); 	
		foreach($products as $keyParent => $product){
		$productObj = $this->_productFactory->create()->load($product['entity_id']);
		$productResponse[$keyParent]['name'] = $productObj->getName();
		$productResponse[$keyParent]['price'] = $productObj->getPrice();
		$productResponse[$keyParent]['special_price'] = $productObj->getSpecialPrice();
		if(!$productObj->getImage()){ $productImage = ''; }else{  $productImage = 'pub/media/catalog/product'.$productObj->getImage(); }
		$productResponse[$keyParent]['image'] =  $productImage;
		$productResponse[$keyParent]['sku'] = $productObj->getSku();
		$productResponse[$keyParent]['id'] = (int)$productObj->getId();
		$productResponse[$keyParent]['off'] = number_format(($productObj->getPrice() - $productObj->getSpecialPrice())/$productObj->getPrice()*100,1);

		$attributes = array(
		'power_take_off_hp'=> $productObj->getPowerTakeOffHp(),
		'number_of_cylinder'=> $productObj->getNumberOfCylinder(),
		'cubic_capacity'=> $productObj->getCubicCapacity(),
		'clutch'=> $productObj->getClutch(),
		'fuel_tank_capacity_ltrs'=> $productObj->getFuelTankCapacityLtrs()		
		 );
		 
		foreach($attributes as $key => $value){
		$attr = $productObj->getResource()->getAttribute($key);
			 if ($attr->usesSource()) {
				$productResponse[$keyParent][$key] =  $optionText = $attr->getSource()->getOptionText($value);
			}
			
		 } // end key foreach
		 
		} // end keyParent foreach
		
		
		// get top category code 
		$catCollection = $this->_categoryFactory->create()->getCollection();
		//echo '<pre>'; print_r($catCollection->getData());
		$categories = array();
		$categories[0]['id'] = 4;
		$categories[0]['name'] = 'Tractor';
		$categories[0]['icon_image'] = 'pub/media/wysiwyg/mobile-icon/icon.jpeg';
		$categories[0]['bg_image'] = 'pub/media/wysiwyg/mobile-banner/2.jpg';
		
		$categories[1]['id'] = 7;
		$categories[1]['name'] = 'Accessories';
		$categories[1]['icon_image'] = 'pub/media/wysiwyg/mobile-icon/icon.jpeg';
		
		$categories[2]['id'] = 10;
		$categories[2]['name'] = 'Implements';
		$categories[2]['icon_image'] = 'pub/media/wysiwyg/mobile-icon/icon.jpeg';
		
		$categories[3]['id'] = 13;
		$categories[3]['name'] = 'Customizations';
		$categories[3]['icon_image'] = 'pub/media/wysiwyg/mobile-icon/icon.jpeg';
	
	    // temp code 
	    $temp['temp'] = '38°C'; 
	    $temp['location'] = 'Bhatinda, Panjab'; 
	    $temp['date'] = 'Tuesday, 1:30pm'; 
	    $temp['humidity'] = '11%'; 
	    $temp['wind'] = '18km/h'; 
     	
	
	    // banner service code
		$bannerService['text'] = 'DOORSTEP SERVICE';
		$bannerService['button_text'] = 'Request a service';
		$bannerService['bg_image'] = 'pub/media/wysiwyg/mobile-banner/2.jpg';
		 
		// mandi code 
		$mandi['text'] = 'Today\'s Mandi Price';
		$mandi['date'] = 'May 22';
		
		$mandi['items'][0]['name'] = 'Rice';
		$mandi['items'][0]['image'] = 'pub/media/wysiwyg/mobile-icon/icon.jpeg';
		$mandi['items'][0]['change'] = '-2.5';
		$mandi['items'][0]['price'] = '₹75.5/kg';
		
		$mandi['items'][1]['name'] = 'Onion';
		$mandi['items'][1]['image'] = 'pub/media/wysiwyg/mobile-icon/icon.jpeg';
		$mandi['items'][1]['change'] = '+1.5';
		$mandi['items'][1]['price'] = '₹20.5/kg';
		
		$mandi['items'][2]['name'] = 'Potato';
		$mandi['items'][2]['image'] = 'pub/media/wysiwyg/mobile-icon/icon.jpeg';
		$mandi['items'][2]['change'] = '+3.5';
		$mandi['items'][2]['price'] = '₹18.5/kg';
		
		// recently view
		$productRecentResponse = array();
		$products = array();
		$categoryId = 4; // tractor id
		$category = $this->_categoryFactory->create()->load($categoryId);
		$collection = $this->_productFactory->create()->getCollection();
		$collection->addAttributeToSelect('*');
		$collection->addCategoryFilter($category);
		$collection->addAttributeToFilter('visibility', \Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH);
		$collection->addAttributeToFilter('status',\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED);
		$collection->setCurPage(1);
		$collection->setPageSize(8);
		
		$products = $collection->getData();      	
		foreach($products as $keyParent => $product){
		$productObj = $this->_productFactory->create()->load($product['entity_id']);
		$productRecentResponse[$keyParent]['name'] = $productObj->getName();
		$productRecentResponse[$keyParent]['price'] = $productObj->getPrice();
		$productRecentResponse[$keyParent]['special_price'] = $productObj->getSpecialPrice();
		$productRecentResponse[$keyParent]['image'] =  $this->getImageValidator($productObj->getImage());
		$productRecentResponse[$keyParent]['sku'] = $productObj->getSku();
		$productRecentResponse[$keyParent]['id'] = (int)$productObj->getId();
		
		$attributes = array(
		'power_take_off_hp'=> $productObj->getPowerTakeOffHp(),
		'number_of_cylinder'=> $productObj->getNumberOfCylinder(),
		'cubic_capacity'=> $productObj->getCubicCapacity(),
		'clutch'=> $productObj->getClutch(),
		'fuel_tank_capacity_ltrs'=> $productObj->getFuelTankCapacityLtrs()		
		 );
		 
		foreach($attributes as $key => $value){
		$attr = $productObj->getResource()->getAttribute($key);
			 if ($attr->usesSource()) {
				$productRecentResponse[$keyParent][$key] =  $optionText = $attr->getSource()->getOptionText($value);
			}
			
		 } // end key foreach
		 
		} // end keyParent foreach
		
		 $blog = array();
		 $blogCollection = $this->_blogPostFactory->create()->getCollection();
		 $blogCollection->addFieldToSelect(['post_id','identifier','title','content_heading','short_content','publish_time','featured_img']);
		 $blogArray = $blogCollection->getData();
		 foreach($blogArray as $key => $valueArray){
          foreach($valueArray as $keychild => $value){
			 if($keychild == 'featured_img'){
			$blog[$key][$keychild] = 'pub/media/'.$value;
		    }
		    else if($keychild == 'publish_time'){
				$blog[$key][$keychild] = date("Y/m/d", strtotime($value) );
				}
		    else if($keychild == 'short_content'){
				$blog[$key][$keychild] = strip_tags($value);
				}
				
		    else{
				$blog[$key][$keychild] = $value ;
			}
		}
		}
		
		
		$response[0]['mobile_banner'] = $banner;
		$response[0]['home_menu'] = $homeMenu;
		$response[0]['offers'] = $productResponse;
		$response[0]['top_categorys'] = $categories;
		$response[0]['temperature'] = $temp;
		$response[0]['banner_service'] = $bannerService;
		$response[0]['mandi'] = $mandi;
		$response[0]['recently_viewed'] = $productRecentResponse;
		$response[0]['blog'] = $blog;
		
		
		return $response;
		
		}
		
		public function getProductDetails($id) {
			  
		$response = array();
		$products = array();
		$productCollection = $this->_productFactory->create()->load($id);
		$response[0]['name'] = $productCollection->getName();      
		$response[0]['sku'] = $productCollection->getSku();      
		$response[0]['price'] = $productCollection->getFinalPrice();         
		$response[0]['is_in_stock'] = $productCollection->getExtensionAttributes()->getStockItem()->getIsInStock();      
		$response[0]['qty'] = $productCollection->getExtensionAttributes()->getStockItem()->getQty();      
		$response[0]['min_sale_qty'] = $productCollection->getExtensionAttributes()->getStockItem()->getMinSaleQty();   
	    $response[0]['options'] = $this->getOptionsValues($productCollection->getOptions());  	
	    $response[0]['media_gallery_entries'] =  $this->getMediaImages($productCollection->getMediaGalleryEntries());                  
	    $response[0]['brochure'] = 'pub/media/brochure.pdf';    
          			
				
		$attributes = array(
		'power_take_off_hp'=> $productCollection->getPowerTakeOffHp(),
		'number_of_cylinder'=> $productCollection->getNumberOfCylinder(),
		'cubic_capacity'=> $productCollection->getCubicCapacity(),
		'clutch'=> $productCollection->getClutch(),
		'fuel_tank_capacity_ltrs'=> $productCollection->getFuelTankCapacityLtrs()		
		 );
		 
		foreach($attributes as $key => $value){
		$attr = $productCollection->getResource()->getAttribute($key);
			 if ($attr->usesSource()) {
				$response[0][$key] =  $optionText = $attr->getSource()->getOptionText($value);
			}
			
		 } // end key foreach


         $response[0]['tabs'][0]['title'] = 'Tractor Specifications';
         $response[0]['tabs'][0]['data'][0]['lable'] = "Power Take Off (HP)";
         $response[0]['tabs'][0]['data'][0]['value'] = "41 hp";        
         $response[0]['tabs'][0]['data'][1]['lable'] = "Number of Cylinder";
         $response[0]['tabs'][0]['data'][1]['value'] = 3;
         
         $response[0]['tabs'][1]['title'] = "FAQs";
         $response[0]['tabs'][1]['data'][0]['ques'] = "What is Lorem Ipsum?";
         $response[0]['tabs'][1]['data'][0]['ans'] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,";
         $response[0]['tabs'][1]['data'][1]['ques'] = "What is Lorem Ipsum?";
         $response[0]['tabs'][1]['data'][1]['ans'] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,";
         $response[0]['tabs'][1]['data'][2]['ques'] = "What is Lorem Ipsum?";
         $response[0]['tabs'][1]['data'][2]['ans'] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,";
         
         $response[0]['tabs'][2]['title'] = "Buying Procedure";
         $response[0]['tabs'][2]['data']['video_link'] = "https://www.youtube.com/embed/JOQEpz19ViI";
         
         $response[0]['related_products'] = $this->getmLinkedItemsByType($productCollection->getSku(), 'related',$productCollection);
         		
		return $response;
    
    }
    
    public function getMediaImages($images){
		$retunData = array();
		foreach($images as $key => $values){	
			
			$retunData[$key]['position'] = (int)$values['position']; 
			$retunData[$key]['media_type'] = $values['media_type']; 
			$retunData[$key]['file'] = $this->getImageValidator($values['file']); 
			}		
			
			if(!$retunData){ 
				 $retunData[0]['position'] = 1;
				 $retunData[0]['media_type'] = "image";  
				 $retunData[0]['file'] = "pub/media/wysiwyg/modile-default/image.jpg"; 
				  }
		return $retunData;	
			
		}
		
	
	public function getImageValidator($image){

		if($image){  $returnData =  'pub/media/catalog/product'.$image; }
		else{ $returnData =  "pub/media/wysiwyg/modile-default/image.jpg";  }
		return $returnData;		
		}
		
		
		
	public function getOptionsValues($options){
		foreach($options as $key => $option){		  
		$responseData = array();
		$responseData['title'] = $option->getTitle();      
		$responseData['option_id'] = $option->getOptionId();
	    
	    $i = 0;
		foreach($option->getValues() as  $values){
			$responseData['values'][$i]['option_type_id'] = (int)$values->getOptionTypeId();      
			$responseData['values'][$i]['title'] = $values->getTitle();     
			$i++; 
			}
			      
		return $responseData;
	}
    }
    
     public function getmLinkedItemsByType($sku, $type,$product)
      {
        $output = [];
        $links = $product->getProductLinks();
        // Only return the links of type specified
        foreach ($links as $key => $link) {
            if ($link->getLinkType() == $type) {
                //$output[] = $link;
              $productLink = $this->productRepository->get($link->getLinkedProductSku()); 
              $link->getLinkedProductType();
              $output[$key]['position'] = (int)$link->getPosition();
              $output[$key]['id'] = (int)$productLink->getId();
              $output[$key]['price'] = $productLink->getPrice();
              $output[$key]['special_price'] = $productLink->getSpecialPrice();
              $output[$key]['name'] = $productLink->getName();
              $output[$key]['sku'] = $link->getLinkedProductSku();
              $output[$key]['image'] = $this->getImageValidator($productLink->getImage());
            }
        }

        return $output;
     }
     
     public function getCartList(){
		$token = $this->_request->getHeader('Authorization'); 
        $token = trim(str_replace('Bearer', '', $token));
        $tokenObj = $this->_tokenModel->loadByToken($token);
        $customerId = $tokenObj->getCustomerId();    
        $quote = $this->quoteFactory->create();
		$customerQuote = $this->quoteModel->loadByCustomerId($quote,$customerId); 
		//$items = $customerQuote->getAllVisibleItems();  
		// print_r($items); 
		 }
		
    
}
