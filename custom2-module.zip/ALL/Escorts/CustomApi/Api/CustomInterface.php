<?php
namespace Escorts\CustomApi\Api;
 
interface CustomInterface
{
     /**
     * @param mixed $products
     * @return void
     */
    public function getProducts($products);
    
     /**
     *  @param mixed $homeData
     * @return void
     */
    public function getHomePage($homeData);
    
    /**
     * @param int $id
     * @return void
     */
    public function getProductDetails($id);
    
    /**
     * @return void
     */
    public function getCartList();
   
    
}
