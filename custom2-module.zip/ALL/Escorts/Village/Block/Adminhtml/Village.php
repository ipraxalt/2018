<?php
namespace Escorts\Village\Block\Adminhtml;
class Village extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
		
        $this->_controller = 'adminhtml_village';/*block grid.php directory*/
        $this->_blockGroup = 'Escorts_Village';
        $this->_headerText = __('Village');
        $this->_addButtonLabel = __('Add New Entry'); 
        parent::_construct();
		
    }
}
