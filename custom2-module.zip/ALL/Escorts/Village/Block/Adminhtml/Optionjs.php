<?php
namespace Escorts\Village\Block\Adminhtml;
class Optionjs extends \Magento\Backend\Block\Template
{
}
