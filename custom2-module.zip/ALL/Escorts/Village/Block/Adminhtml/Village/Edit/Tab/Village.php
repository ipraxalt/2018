<?php
namespace Escorts\Village\Block\Adminhtml\Village\Edit\Tab;
class Village extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @var \Escorts\Village\Model\VillageFactory $villageFactory
     */
    protected $_villageFactory;

    /**
     * @var \Escorts\Blocks\Model\StateFactory $stateFactory
     */
    protected $_stateFactory;

    /**
     * @var \Escorts\Blocks\Model\DistrictFactory $districtFactory
     */
    protected $_districtFactory;

    /**
     * @var \Escorts\Blocks\Model\TehsilFactory $tehsilFactory
     */
    protected $_tehsilFactory;

    

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param \Escorts\Village\Model\VillageFactory $villageFactory
     * @param \Escorts\Blocks\Model\StateFactory $stateFactory
     * @param \Escorts\Blocks\Model\DistrictFactory $districtFactory
     * @param \Escorts\Blocks\Model\TehsilFactory $tehsilFactory
     * @param array $data
     */

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Escorts\Village\Model\VillageFactory $villageFactory,
        \Escorts\Blocks\Model\StateFactory $stateFactory,
        \Escorts\Blocks\Model\DistrictFactory $districtFactory,
        \Escorts\Blocks\Model\TehsilFactory $tehsilFactory,
        array $data = array()
    ) {
        $this->_systemStore = $systemStore;
        $this->_villageFactory = $villageFactory;
        $this->_stateFactory = $stateFactory;
        $this->_districtFactory = $districtFactory;
        $this->_tehsilFactory = $tehsilFactory;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
		/* @var $model \Magento\Cms\Model\Page */
        $model = $this->_coreRegistry->registry('escorts_village');
		$isElementDisabled = false;
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('page_');

        $fieldset = $form->addFieldset('base_fieldset', array('legend' => __('Village')));

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', array('name' => 'id'));
        }

        /*$fieldset->addType('block_url', '\Escorts\Village\Block\Adminhtml\Village\Renderer\Addlink');

        $fieldset->addField(
            'block_url',
            'block_url',
            array(
                'name'  => 'block_url',
                'label' => __('Custom Div'),
                'title' => __('Custom Div'),
               
            )
        );*/

		$fieldset->addField(
            'village_token_id',
            'text',
            [
                'name' => 'village_token_id',
                'label' => __('Villge Token No'),
                'title' => __('Villge Token No'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'village_name',
            'text',
            [
                'name' => 'village_name',
                'label' => __('Village Name'),
                'title' => __('Village Name'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'country',
            'select',
            [
                'label' => __('Country'),
                'title' => __('Country'),
                'name' => 'country',
                'required' => true,
                'onchange' => 'countrylist(this)',
                'options' => \Escorts\Village\Block\Adminhtml\Village\Grid::getOptionArray3(),
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'state',
            'select',
            [
                'label' => __('State'),
                'title' => __('State'),
                'name' => 'state',
                'required' => true,
                'onchange' => 'statelist(this)',
                'options' => $this->getOptionArray4(),
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'district',
            'select',
            [
                'label' => __('District'),
                'title' => __('District'),
                'name' => 'district',
                'required' => true,
                'onchange' => 'districtlist(this)',
                'options' => $this->getOptionArray5(),
                'disabled' => $isElementDisabled
            ]
        );
		$fieldset->addField(
            'tehsil',
            'select',
            [
                'label' => __('Tehsil'),
                'title' => __('Tehsil'),
                'name' => 'tehsil',
                'required' => true,
                'options' => $this->getOptionArray6(),
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'post_code',
            'text',
            [
                'name' => 'post_code',
                'label' => __('Post Code'),
                'title' => __('Post Code'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );
		/*{{CedAddFormField}}*/
        
        if (!$model->getId()) {
            $model->setData('status', $isElementDisabled ? '2' : '1');
        }

        $form->setValues($model->getData());

        $this->setForm($form);

        return parent::_prepareForm();   
    }

    /**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('Village');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return __('Village');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }

    public function getOptionArray4()
    {
        $_id = $this->getRequest()->getParam('id');
        if (!$_id) {
            $data_array=array(''=>'Select State');
            return($data_array);
        }else{
            $_village = $this->_villageFactory->create()->load($_id);
            $states = $this->_stateFactory->create();
            $collection = $states->getCollection();
            $collection->addFieldToFilter('country_id',array('eq' => $_village->getCountry()));
            $data_array = array(''=>'Select State');
            foreach ($collection as $state) {
                $data_array[$state->getId()] = $state->getName();
            }
            return($data_array);
        }
    }
    
    public function getOptionArray5()
    {
        $_id = $this->getRequest()->getParam('id');
        if (!$_id) {
            $data_array=array(''=>'Select District');
            return($data_array);
        }else{
            $_village = $this->_villageFactory->create()->load($_id);
            $districts = $this->_districtFactory->create();
            $collection = $districts->getCollection();
            $collection->addFieldToFilter('state_id',array('eq' => $_village->getState()));
            $data_array = array(''=>'Select District');
            foreach ($collection as $district) {
                $data_array[$district->getId()] = $district->getName();
            }
            return($data_array);
        }
    }

    public function getOptionArray6()
    {
        // ini_set('display_errors', '1');
        // error_reporting(E_ALL);
        $_id = $this->getRequest()->getParam('id');
        if (!$_id) {
            $data_array=array(''=>'Select Tehsil');
            return($data_array);
        }else{
            $_village = $this->_villageFactory->create()->load($_id);
            $tehsils = $this->_tehsilFactory->create();
            $collection = $tehsils->getCollection();
            $collection->addFieldToFilter('district_id',array('eq' => $_village->getDistrict()));
            $data_array=array(''=>'Select Tehsil');
            foreach ($collection as $tehsil) {
                $data_array[$tehsil->getId()] = $tehsil->getName();
            }
            return($data_array);
        }
    }
}
