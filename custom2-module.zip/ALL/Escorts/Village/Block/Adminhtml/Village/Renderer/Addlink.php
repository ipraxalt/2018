<?php

namespace Escorts\Village\Block\Adminhtml\Village\Renderer;

use Magento\Framework\DataObject;

class Addlink extends \Magento\Framework\Data\Form\Element\AbstractElement
{
    protected $_backendUrl;
    protected $request;
    /**
     *@var \Escorts\Blocks\Model\BlocksFactory $blocksFactory
     **/
    protected $_banksFactory;
    /**
     *@var \Escorts\Village\Model\VillageFactory $villageFactory
     **/
    protected $_villageFactory;
    public function __construct( 
        \Magento\Backend\Model\UrlInterface $backendUrl,
        \Escorts\Village\Model\VillageFactory $villageFactory,
        \Escorts\Blocks\Model\BlocksFactory $blocksFactory,
        \Magento\Framework\App\Request\Http $request
    ) {
        $this->request = $request;
        $this->_villageFactory = $villageFactory;
        $this->_blocksFactory = $blocksFactory;
        $this->_backendUrl = $backendUrl;
    }

    public function getBankId()
    {
        $id = $this->request->getParam('id');
        $model = $this->_villageFactory->create()->load($id);
        return $model->getBankId();
    }

    public function getElementHtml()
    {
        $bank_id = $this->getBankId();
        $bank_name = $this->_blocksFactory->create()->load($bank_id)->getBankName();
        $url = $this->_backendUrl->getUrl("blocks/blocks/edit", array('block_id'=>$bank_id));
        $bankLink = "<a href='".$url."' target='_blank'>Return to Bank (".$bank_name.")</a>";
        return $bankLink;
    }
}