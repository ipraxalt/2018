<?php
namespace Escorts\TractorLoan\Model\ResourceModel\LoanApplication;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'tractor_loanapplication_id';
	protected $_eventPrefix = 'escorts_tractorloan_loanapplication_collection';
	protected $_eventObject = 'tractor_loan_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct(){
		$this->_init('Escorts\TractorLoan\Model\LoanApplication', 'Escorts\TractorLoan\Model\ResourceModel\LoanApplication');
	}
}