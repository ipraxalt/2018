<?php
namespace Escorts\TractorLoan\Model\ResourceModel;

class LoanApplication extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
	public function __construct(
		\Magento\Framework\Model\ResourceModel\Db\Context $context
	){
		parent::__construct($context);
	}
	
	protected function _construct(){
		$this->_init('escorts_tractor_loanapplication', 'tractor_loanapplication_id');
	}
}