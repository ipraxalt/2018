<?php
namespace Escorts\TractorLoan\Model;

class LoanApplication extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'escorts_tractorloan_exchange';
	protected $_cacheTag = 'escorts_tractorloan_exchange';
	protected $_eventPrefix = 'escorts_tractorloan_exchange';

	protected function _construct(){
		$this->_init('Escorts\TractorLoan\Model\ResourceModel\LoanApplication');
	}

	public function getIdentities(){
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues(){
		$values = [];
		return $values;
	}
}