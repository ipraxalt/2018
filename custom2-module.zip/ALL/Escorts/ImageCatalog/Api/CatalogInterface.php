<?php

namespace Escorts\ImageCatalog\Api;

interface CatalogInterface {

    /**
     * Returns images array
     *
     * @api
     * @param string $user_id
     * @return JSON aray of images.
     */
    public function listImage($user_id);
}
