<?php

namespace Escorts\ImageCatalog\Model;

use Escorts\ImageCatalog\Api\CatalogInterface;

class Catalog implements CatalogInterface {

    protected $_request;
    protected $_commonHelper;

    public function __construct(
    \Magento\Framework\App\RequestInterface $request, \Escorts\Common\Helper\Data $commonHelper
    ) {
        $this->_request = $request;
        $this->_commonHelper = $commonHelper;
    }

    public function listImage($user_id) {
        $imagesArr = array();

        if (!$this->_commonHelper->isEtcToken($this->_request->getHeader('Authorization'))) {
            return $imagesArr;
        }

        $imagesArr = array(
            array('title' => 'Title', 'src' => 'http://escortsonline.local/pub/media/catalog/product/e/s/escorts-tractors-500x500.jpg'),
            array('title' => 'Title', 'src' => 'http://escortsonline.local/pub/media/catalog/product/e/s/escorts-tractors-500x500.jpg'),
            array('title' => 'Title', 'src' => 'http://escortsonline.local/pub/media/catalog/product/e/s/escorts-tractors-500x500.jpg'),
            array('title' => 'Title', 'src' => 'http://escortsonline.local/pub/media/catalog/product/e/s/escorts-tractors-500x500.jpg'),
            array('title' => 'Title', 'src' => 'http://escortsonline.local/pub/media/catalog/product/e/s/escorts-tractors-500x500.jpg'),
            array('title' => 'Title', 'src' => 'http://escortsonline.local/pub/media/catalog/product/e/s/escorts-tractors-500x500.jpg'),
            array('title' => 'Title', 'src' => 'http://escortsonline.local/pub/media/catalog/product/e/s/escorts-tractors-500x500.jpg')
        );
        return $imagesArr;
    }

}
