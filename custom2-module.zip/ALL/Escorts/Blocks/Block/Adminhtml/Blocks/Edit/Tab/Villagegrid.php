<?php
namespace Escorts\Blocks\Block\Adminhtml\Blocks\Edit\Tab;

use \Escorts\Blocks\Model\BlocksFactory;
class Villagegrid extends \Magento\Backend\Block\Widget\Grid\Extended implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Framework\Module\Manager
     */
    protected $moduleManager;

    /**
     * @var \Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory]
     */
    protected $_setsFactory;

    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $_productFactory;

    /**
     * @var \Magento\Catalog\Model\Product\Type
     */
    protected $_type;

    /**
     * @var \Magento\Catalog\Model\Product\Attribute\Source\Status
     */
    protected $_status;
    protected $_collectionFactory;

    /**
     * @var \Magento\Catalog\Model\Product\Visibility
     */
    protected $_visibility;

    /**
     * @var \Magento\Store\Model\WebsiteFactory
     */
    protected $_websiteFactory;

    /**
     * @var BlocksFactory
     */
    private $contactFactory;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Backend\Helper\Data $backendHelper
     * @param \Magento\Store\Model\WebsiteFactory $websiteFactory
     * @param \Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory $setsFactory
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     * @param \Magento\Catalog\Model\Product\Type $type
     * @param \Magento\Catalog\Model\Product\Attribute\Source\Status $status
     * @param \Magento\Catalog\Model\Product\Visibility $visibility
     * @param \Magento\Framework\Module\Manager $moduleManager
     * @param BlocksFactory $contactFactory
     * @param array $data
     *
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Magento\Store\Model\WebsiteFactory $websiteFactory,
        \Escorts\Village\Model\ResourceModel\Village\Collection $collectionFactory,
        \Magento\Framework\Module\Manager $moduleManager,
        BlocksFactory $contactFactory,
        array $data = []
    ) {
        $this->contactFactory = $contactFactory;
        $this->_collectionFactory = $collectionFactory;
        $this->_websiteFactory = $websiteFactory;
        $this->moduleManager = $moduleManager;
        parent::__construct($context, $backendHelper, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        
        $this->setId('productGrid');
        $this->setDefaultSort('id');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(true);
        if ($this->getRequest()->getParam('id')) {
            $this->setDefaultFilter(['in_village' => 1]);
        }
       
    }

    /**
     * @return Store
     */
    protected function _getStore()
    {
        $storeId = (int)$this->getRequest()->getParam('store', 0);
        return $this->_storeManager->getStore($storeId);
    }

    /**
     * @return $this
     */
    protected function _prepareCollection()
    {
        try{
            $collection = $this->_collectionFactory->load();
            $collection->addFieldToFilter('post_code', array('neq' => 'NULL'));
			$villageIds = $this->_getSelectedVillages();
            if (empty($villageIds)) {
                $villageIds = 0;
            }
			if (is_null($this->getRequest()->getParam('ajax'))) {
                $collection->addFieldToFilter('id', ['in' => $villageIds]);
            }
            $this->setCollection($collection);
            parent::_prepareCollection();
            return $this;
        }
        catch(Exception $e)
        {
            echo $e->getMessage();die;
        }
    }

    /**
     * @param \Magento\Backend\Block\Widget\Grid\Column $column
     * @return $this
     */
    protected function _addColumnFilterToCollection($column)
    {
        if ($column->getId() == 'in_village') {
            $villageIds = $this->_getSelectedVillages();
            if (empty($villageIds)) {
                $villageIds = 0;
            }
            if ($column->getFilter()->getValue()) {
                $this->getCollection()->addFieldToFilter('id', ['in' => $villageIds]);
            } else {
                if ($villageIds) {
                    $this->getCollection()->addFieldToFilter('id', ['nin' => $villageIds]);
                }
            }
        } else {
            parent::_addColumnFilterToCollection($column);
        }
        return $this;


        /*if ($this->getCollection()) {
            if ($column->getId() == 'websites') {
                $this->getCollection()->joinField(
                    'websites',
                    'catalog_product_website',
                    'website_id',
                    'product_id=entity_id',
                    null,
                    'left'
                );
            }
        }
        return parent::_addColumnFilterToCollection($column);*/
    }

    /**
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareColumns()
    {
		//print_r($this->_getSelectedVillages());die;

        $this->addColumn(
            'in_village',
            [
                'header_css_class' => 'a-center',
                'type' => 'checkbox',
                'name' => 'in_village',
                'align' => 'center',
                'index' => 'id',
                'values' => $this->_getSelectedVillages(),
            ]
        );

        $this->addColumn(
            'id',
            [
                'header' => __('ID'),
                'type' => 'number',
                'index' => 'id',
                'header_css_class' => 'col-id',
                'column_css_class' => 'col-id'
            ]
        );
        $this->addColumn(
            'village_token_id',
            [
                'header' => __('Village Token Id'),
                'index' => 'village_token_id',
                'class' => 'village_token_id'
            ]
        );
        $this->addColumn(
            'village_name',
            [
                'header' => __('Village Name'),
                'index' => 'village_name',
                'class' => 'village_name'
            ]
        );
        $this->addColumn(
            'country',
            [
                'header' => __('Country'),
                'index' => 'country',
                'class' => 'country',
                'type' => 'options',
                'options' => \Escorts\Village\Block\Adminhtml\Village\Grid::getOptionArray3()
            ]
        );
        $this->addColumn(
            'state',
            [
                'header' => __('State'),
                'index' => 'state',
                'class' => 'state',
                'type' => 'options',
                'options' => \Escorts\Village\Block\Adminhtml\Village\Grid::getOptionArray7()
            ]
        );
        $this->addColumn(
            'district',
            [
                'header' => __('District'),
                'index' => 'district',
                'class' => 'district',
                'type' => 'options',
                'options' => \Escorts\Village\Block\Adminhtml\Village\Grid::getOptionArray8()
            ]
        );
        $this->addColumn(
            'tehsil',
            [
                'header' => __('Tehsil'),
                'index' => 'tehsil',
                'class' => 'tehsil',
                'type' => 'options',
                'options' => \Escorts\Village\Block\Adminhtml\Village\Grid::getOptionArray9()
            ]
        );
        $this->addColumn(
            'post_code',
            [
                'header' => __('Post Code'),
                'index' => 'post_code',
            ]
        );
        /*{{CedAddGridColumn}}*/

        $block = $this->getLayout()->getBlock('grid.bottom.links');
        if ($block) {
            $this->setChild('grid.bottom.links', $block);
        }

        return parent::_prepareColumns();
    }

    public function _getSelectedVillages()
    {
        $contact = $this->getContact();
        return $contact->getVillages($contact);
    }

    /**
     * Retrieve selected villages
     *
     * @return array
     */
    public function getSelectedVillages()
    {
        $contact = $this->getContact();
        $selected = $contact->getVillages($contact);
        
        if (!is_array($selected)) {
            $selected = [];
        }
        return $selected;
    }

    public function getContact()
    {
        $contactId = $this->getRequest()->getParam('block_id');
        $contact   = $this->contactFactory->create();
        if ($contactId) {
            $contact->load($contactId);
        }
        return $contact;
    }

    /**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('Village Grid');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return __('Village Grid');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    /*protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }*/
}