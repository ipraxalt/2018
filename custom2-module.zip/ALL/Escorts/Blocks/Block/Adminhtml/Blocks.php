<?php
namespace Escorts\Blocks\Block\Adminhtml;
class Blocks extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
		
        $this->_controller = 'adminhtml_blocks';/*block grid.php directory*/
        $this->_blockGroup = 'Escorts_Blocks';
        $this->_headerText = __('Blocks');
        $this->_addButtonLabel = __('Add New Entry'); 
        parent::_construct();
		
    }
}
