<?php
/**
 * Copyright © 2015 Escorts . All rights reserved.
 */
namespace Escorts\Blocks\Block\Index;
use Escorts\Blocks\Block\BaseBlock;
class Index extends BaseBlock
{
	public $hello='Hello World';
	
}
