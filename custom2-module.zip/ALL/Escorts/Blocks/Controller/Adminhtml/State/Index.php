<?php
namespace Escorts\Blocks\Controller\Adminhtml\State;
use Magento\Framework\App\Filesystem\DirectoryList;
class Index extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
	public function execute()
    {
        $data = $this->getRequest()->getParams();
        $state_id = $this->getRequest()->getParam('id');
        $districtModel = $this->_objectManager->create('Escorts\Blocks\Model\ResourceModel\District\Collection');
        $districtModel->addFieldToFilter('state_id', array('eq' => $state_id));
        $response = array();
        $response[] = array('id'=>'','label'=>'Select District');
        foreach ($districtModel as $district) {
        	$response[] = array('id'=>$district->getId(),'label'=>$district->getName());
        }
        echo json_encode($response);
    }
}
