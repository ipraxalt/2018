<?php
namespace Escorts\Blocks\Controller\Adminhtml\District;
use Magento\Framework\App\Filesystem\DirectoryList;
class Index extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
	public function execute()
    {
        $data = $this->getRequest()->getParams();
        $district_id = $this->getRequest()->getParam('id');
        $tehsilModel = $this->_objectManager->create('Escorts\Blocks\Model\ResourceModel\Tehsil\Collection');
        $tehsilModel->addFieldToFilter('district_id', array('eq' => $district_id));
        $response = array();
        $response[] = array('id'=>'','label'=>'Select Tehsil');
        foreach ($tehsilModel as $tehsil) {
        	$response[] = array('id'=>$tehsil->getId(),'label'=>$tehsil->getName());
        }
        echo json_encode($response);
    }
}
