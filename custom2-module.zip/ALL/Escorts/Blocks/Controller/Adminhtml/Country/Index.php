<?php
namespace Escorts\Blocks\Controller\Adminhtml\Country;
use Magento\Framework\App\Filesystem\DirectoryList;
class Index extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
	public function execute()
    {
        $data = $this->getRequest()->getParams();
        $country_id = $this->getRequest()->getParam('id');
        $stateModel = $this->_objectManager->create('Escorts\Blocks\Model\ResourceModel\State\Collection');
        $stateModel->addFieldToFilter('country_id', array('eq' => $country_id));
        $response = array();
        $response[] = array('id'=>'','label'=>'Select State');
        foreach ($stateModel as $state) {
        	$response[] = array('id'=>$state->getId(),'label'=>$state->getName());
        	//$response[] = $state->getName();
        }
        //echo "<pre>"; print_r($response); echo "</pre>";
        echo json_encode($response);
    }
}
