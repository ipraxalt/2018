<?php

/**
 * Copyright © 2015 Escorts . All rights reserved.
 */

namespace Escorts\Blocks\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper {

    /**
     * Service Dealer Group ID
     *
     * @var int
     */
    const SD_GROUP_ID = 4;

    /**
     * Broker Group ID
     *
     * @var int
     */
    const BROKER_GROUP_ID = 19;

    /**
     * @var \Magento\Backend\Model\UrlInterface
     */
    private $backendUrl;

    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $_resourceConnection;

    /**
     * @var \Magento\Customer\Model\Address
     */
    protected $_addressModel;

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    protected $_customerFactory;

    /**
     * @var \Escorts\Blocks\Model\CountryFactory
     */
    protected $_countryFactory;

    /**
     * @var \Escorts\Blocks\Model\StateFactory
     */
    protected $_stateFactory;

    /**
     * @var \Escorts\Blocks\Model\DistrictFactory
     */
    protected $_districtFactory;

    /**
     * @var \Escorts\Blocks\Model\TehsilFactory
     */
    protected $_tehsilFactory;

    /**
     * @var \Escorts\Blocks\Model\VillageFactory
     */
    protected $_villageFactory;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Backend\Model\UrlInterface $backendUrl
     */
    public function __construct(
    \Magento\Framework\App\Helper\Context $context, \Magento\Backend\Model\UrlInterface $backendUrl, \Magento\Framework\App\ResourceConnection $resourceConnection, \Magento\Customer\Model\Address $addressModel, \Magento\Customer\Model\CustomerFactory $customerFactory, \Escorts\Blocks\Model\CountryFactory $countryFactory, \Escorts\Blocks\Model\StateFactory $stateFactory, \Escorts\Blocks\Model\DistrictFactory $districtFactory, \Escorts\Blocks\Model\TehsilFactory $tehsilFactory, \Escorts\Village\Model\VillageFactory $villageFactory
    ) {
        $this->backendUrl = $backendUrl;
        $this->_resourceConnection = $resourceConnection;
        $this->_addressModel = $addressModel;
        $this->_customerFactory = $customerFactory;
        $this->_countryFactory = $countryFactory;
        $this->_stateFactory = $stateFactory;
        $this->_districtFactory = $districtFactory;
        $this->_tehsilFactory = $tehsilFactory;
        $this->_villageFactory = $villageFactory;
        parent::__construct($context);
    }

    public function getVillagesGridUrl() {
        return $this->backendUrl->getUrl('blocks/blocks/village', ['_current' => true]);
    }

    /**
     * @param string $postcode
     */
    public function getBlockServiceDealer($postcode) {
        $collection = $this->_villageFactory->create()
                ->getCollection()
                ->addFieldToSelect('id')
                ->addFieldToFilter('post_code', array('eq' => $postcode))
                ->addFieldToFilter('status', array('status' => 1))
                ->setPageSize(1)
                ->load();

        if (!empty($collection->getSize())) {
            $village = $collection->getFirstItem()->getData();
            $village_id = $village['id'];
            $connection = $this->_resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
            $block_id = $connection->fetchOne("SELECT block_id FROM escorts_blocks WHERE FIND_IN_SET($village_id, replace(assigned_village, '&', ','))");
            if (!empty($block_id)) {
                $service_dealer_collection = $this->_customerFactory->create()
                        ->getCollection()
                        ->addAttributeToSelect("id")
                        ->addAttributeToFilter("group_id", array("eq" => self::SD_GROUP_ID))
                        ->load();

                if (!empty($service_dealer_collection)) {
                    foreach ($service_dealer_collection as $item) {
                        $service_dealer_ids[] = $item->getid();
                    }
                    $service_dealer_ids_str = implode(',', $service_dealer_ids);

                    //$service_dealers = $connection->fetchAll("SELECT entity_id FROM customer_entity_varchar WHERE attribute_id=622 AND entity_id IN($service_dealer_ids_str) AND FIND_IN_SET($block_id, value)");
                    $service_dealers = $connection->fetchOne("SELECT entity_id FROM customer_entity_varchar WHERE attribute_id=622 AND entity_id IN($service_dealer_ids_str) AND FIND_IN_SET($block_id, value)");

                    if (!empty($service_dealers)) {
                        /* Bussiness logic if multiple service dealers in a block */
                        /*                         * ****************************************************** */
                        //print_r($service_dealers);
                        return $service_dealers;
                    }
                }
            }
        }
        return false;
    }

    /**
     * @param string $postcode
     */
    public function getBrokerByPostCode($postcode) {
        $collection = $this->_villageFactory->create()
                ->getCollection()
                ->addFieldToSelect('id')
                ->addFieldToFilter('post_code', array('eq' => $postcode))
                ->setPageSize(1)
                ->load();

        if (!empty($collection->getSize())) {
            $village = $collection->getFirstItem()->getData();
            $village_id = $village['id'];
            $connection = $this->_resourceConnection->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
            $block_id = $connection->fetchOne("SELECT block_id FROM escorts_blocks WHERE FIND_IN_SET($village_id, replace(assigned_village, '&', ','))");
            if (!empty($block_id)) {
                $broker_collection = $this->_customerFactory->create()
                        ->getCollection()
                        ->addAttributeToSelect("id")
                        ->addAttributeToFilter("group_id", array("eq" => self::BROKER_GROUP_ID))
                        ->load();

                if (!empty($broker_collection)) {
                    foreach ($broker_collection as $item) {
                        $broker_ids[] = $item->getid();
                    }
                    $broker_ids_str = implode(',', $broker_ids);

                    $brokers = $connection->fetchOne("SELECT entity_id FROM customer_entity_varchar WHERE attribute_id=622 AND entity_id IN($broker_ids_str) AND FIND_IN_SET($block_id, value)");

                    if (!empty($brokers)) {
                        /* Bussiness logic if multiple brokers in a block */
                        /*                         * ****************************************************** */

                        $customer = $this->_customerFactory->create()->load($brokers);
                        $broker = array();

                        if ($customer->getId()) {
                            $broker['id'] = $customer->getId();
                            $broker['name'] = $customer->getFirstname() . ' ' . $customer->getLastname();
                            $broker['mobile_number'] = $customer->getMobileNumber();

                            $address_id = $customer->getDefaultBilling();
                            if (!empty($address_id)) {
                                $billingAddress = $this->_addressModel->load($address_id);
                                $address = $billingAddress->getData();

                                $broker['address'] = '';

                                if (!empty($address['street'])) {
                                    $broker['address'] .= $address['street'];
                                }

                                if (!empty($address['village'])) {
                                    $broker['address'] .= ', ' . $address['village'];
                                }

                                if (!empty($address['tehsil'])) {
                                    $broker['address'] .= ', ' . $address['tehsil'];
                                }

                                if (!empty($address['city'])) {
                                    $broker['address'] .= ', ' . $address['city'];
                                }

                                if (!empty($address['region'])) {
                                    $broker['address'] .= ', ' . $address['region'];
                                }

                                if (!empty($address['country_id'])) {
                                    $broker['address'] .= ', ' . $address['country_id'];
                                }

                                if (!empty($address['postcode'])) {
                                    $broker['address'] .= ', ' . $address['postcode'];
                                }
                            }
                        }

                        return $broker;
                    }
                }
            }
        }
        return false;
    }

    public function getCountries() {
        $countries = array();
        $collection = $this->_countryFactory->create()->getCollection();

        if ($collection->getSize()) {
            foreach ($collection as $item) {
                $countries[] = $item->getData();
            }
        }

        return $countries;
    }

    public function getStates($countryId = null) {
        $states = array();
        $collection = $this->_stateFactory->create()->getCollection()->addFieldToSelect(array('id', 'name'));

        if ($countryId) {
            $collection->addFieldToFilter('country_id', array('eq' => $countryId));
        }

        if ($collection->getSize()) {
            foreach ($collection as $item) {
                $states[] = $item->getData();
            }
        }

        return $states;
    }

    public function getDistricts($stateId = null) {
        $districts = array();
        $collection = $this->_districtFactory->create()->getCollection()->addFieldToSelect(array('id', 'name'));

        if ($stateId) {
            $collection->addFieldToFilter('state_id', array('eq' => $stateId));
        }

        if ($collection->getSize()) {
            foreach ($collection as $item) {
                $districts[] = $item->getData();
            }
        }

        return $districts;
    }

    public function getTehsils($districtId = null) {
        $tehsils = array();
        $collection = $this->_tehsilFactory->create()
                ->getCollection()
                ->addFieldToSelect(array('id', 'name'));

        if ($districtId) {
            $collection->addFieldToFilter('district_id', array('eq' => $districtId));
        }

        if ($collection->getSize()) {
            foreach ($collection as $item) {
                $tehsils[] = $item->getData();
            }
        }

        return $tehsils;
    }

    public function getVillages($tehsilId = null) {
        $villages = array();
        //$collection = $this->_villageFactory->create()
        //->getCollection()->addFieldToSelect(array('id', 'village_name', 'post_code'));
        $collection = $this->_villageFactory->create()
                ->getCollection()
                ->addFieldToSelect(array('id', 'village_name', 'post_code'));

        if ($tehsilId) {
            $collection->addFieldToFilter('tehsil', array('eq' => $tehsilId));
        }

        $collection->addFieldToFilter('status', array('eq' => 1));

        if ($collection->getSize()) {
            foreach ($collection as $item) {
                $villages[] = $item->getData();
            }
        }

        return $villages;
    }

    public function getPostCodeByVillageId($villageId = null) {
        $postCode = false;

        if ($villageId) {
            $collection = $this->_villageFactory->create()
                    ->getCollection()
                    ->addFieldToSelect('post_code')
                    ->addFieldToFilter('id', array('eq' => $villageId))
                    ->setPageSize(1);

            if ($collection->getSize()) {
                return $collection->getFirstItem()->getPostCode();
            }
        }

        return $postCode;
    }

}
