<?php
/**
 * Copyright © 2015 Escorts. All rights reserved.
 */
namespace Escorts\Blocks\Model\ResourceModel;

/**
 * Blocks resource
 */
class District extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('escorts_district', 'id');
    }

  
}
