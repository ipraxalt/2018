<?php
namespace Escorts\EtcProfile\Model\Config\Source;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\OptionFactory;
use Magento\Framework\DB\Ddl\Table;

/**
* Custom Attribute Renderer
*/

class BlockOption extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
	/**
	* @var OptionFactory
	*/
	protected $optionFactory;
	/**
	* @param OptionFactory $optionFactory
	*/
	
	/**
	* @var Object
	*/
	protected $blocksFactory;
	
	
	public function __construct(
		\Escorts\Blocks\Model\BlocksFactory $blocksFactory
	){
		/* parent::__construct(
			$context,
			$resource,
			[]
		); */
		$this->blocksFactory = $blocksFactory;
	}
	
	/**
	* Get all options
	*
	* @return array
	*/

	public function getAllOptions(){
		$blocks = $this->blocksFactory->create();
		$collection = $blocks->getCollection();
		foreach ($collection as $item){
			$arr = $item->getData();
			$this->_options[] = ['label' => $arr['block_name'], 'value' => $arr['block_id']];
		}
		//print_r($this->_options);die;
		
		/* your Attribute options list*/
		/*$this->_options = [
			['label'=>'Block 1', 'value'=>'1'],
			['label'=>'Block 2', 'value'=>'2'],
			['label'=>'Block 3', 'value'=>'3'],
			['label'=>'Block 4', 'value'=>'4'],
			['label'=>'Block 5', 'value'=>'5']
		];*/

		return $this->_options;
	}
}