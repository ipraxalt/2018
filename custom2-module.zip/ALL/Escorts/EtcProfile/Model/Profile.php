<?php

namespace Escorts\EtcProfile\Model;

use Escorts\EtcProfile\Api\ProfileInterface;

class Profile implements ProfileInterface {

    protected $_storeManager;
    protected $_customerFactory;
    protected $_customerRepository;
    protected $_smsNotificationHelper;
    protected $_commonHelper;

    /**
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     * @param \Escorts\SmsNotification\Helper\Data $smsNotificationHelper
     */
    public function __construct(
    \Magento\Store\Model\StoreManagerInterface $storeManager, \Magento\Customer\Model\CustomerFactory $customerFactory, \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository, \Escorts\SmsNotification\Helper\Data $smsNotificationHelper, \Escorts\Common\Helper\Data $commonHelper
    ) {
        $this->_storeManager = $storeManager;
        $this->_customerFactory = $customerFactory;
        $this->_customerRepository = $customerRepository;
        $this->_smsNotificationHelper = $smsNotificationHelper;
        $this->_commonHelper = $commonHelper;
    }

    public function detail($user_id) {
        return "Hello, " . $user_id;
    }

    public function forgotPassword($username) {
        $response[0] = ['status' => 0];

        if (!empty($username)) {
            $otp = $this->_commonHelper->generateOtp();
            if (filter_var($username, FILTER_VALIDATE_EMAIL)) {
                $customer_data = $this->_customerFactory->create()
                        ->setWebsiteId($this->_storeManager->getStore()->getWebsiteId())
                        ->loadByEmail($username);

                if (!empty($customer_data->getId())) {
                    $mobileNumber = $customer_data->getMobileNumber();
                    $customer = $this->_customerRepository->getById($customer_data->getId());

                    if ($customer) {
                        $customer->setCustomAttribute('pass_reset_otp', $otp);
                        $customer->setCustomAttribute('pass_reset_time', time());
                        try {
                            $customer = $this->_customerRepository->save($customer);
                        } catch (Exception $e) {
                            //return $e->getMessage();
                        }

                        $smsText = "Your OTP to reset password is " . $otp . ". Its valid for 10 minutes.";
                        $this->_smsNotificationHelper->sendSms($mobileNumber, $smsText);
                        $response[0]['status'] = 1;
                        $response[0]['customer_id'] = $customer->getId();
                        $response[0]['msg'] = 'We have sent an OTP on your registered mobile number';
                    }
                } else {
                    $response[0]['status'] = 0;
                    $response[0]['msg'] = 'No user account exists for provided detail';
                }
            } else {
                $collection = $this->_customerFactory->create()
                        ->getCollection()
                        ->addAttributeToSelect("*")
                        ->addAttributeToFilter("mobile_number", ["eq" => $username])
                        ->setPageSize(1)
                        ->load();

                if (!empty($collection->getSize())) {
                    $customer_data = $collection->getFirstItem();
                    $mobileNumber = $customer_data->getMobileNumber();

                    $customer = $this->_customerRepository->getById($customer_data->getId());
                    if ($customer) {
                        $customer->setCustomAttribute('pass_reset_otp', $otp);
                        $customer->setCustomAttribute('pass_reset_time', time());
                        try {
                            $customer = $this->_customerRepository->save($customer);
                        } catch (Exception $e) {
                            //return $e->getMessage();
                        }

                        $smsText = "Your OTP to reset password is " . $otp . ". Its valid for 10 minutes.";
                        $this->_smsNotificationHelper->sendSms($mobileNumber, $smsText);

                        $response[0]['status'] = 1;
                        $response[0]['customer_id'] = $customer->getId();
                        $response[0]['msg'] = 'We have sent an OTP on your registered mobile number';
                    }
                } else {
                    $response[0]['status'] = 0;
                    $response[0]['msg'] = 'No user account exists for provided detail';
                }
            }
        } else {
            $response[0]['status'] = 0;
            $response[0]['msg'] = 'Please provide all required parameters';
        }

        return $response;
    }

    public function resetPassword($newdetail) {
        $response[0]['status'] = 0;
        $response[0]['msg'] = 'Something went wrong. Please try againg later.';
        $customer = $this->_customerRepository->getById(trim($newdetail['customer_id']));

        if ($customer) {
            $otp = is_null($customer->getCustomAttribute('pass_reset_otp')) ? '' : $customer->getCustomAttribute('pass_reset_otp')->getValue();
            $time = is_null($customer->getCustomAttribute('pass_reset_time')) ? '' : $customer->getCustomAttribute('pass_reset_time')->getValue();
            $diff = round(abs(time() - $time) / 60);

            if ($time) {
                if ($diff <= 10) {
                    if ($otp === trim($newdetail['otp'])) {
                        try {
                            //Reset custom attribute value of customer
                            $customer->setCustomAttribute('pass_reset_otp', '');
                            $customer->setCustomAttribute('pass_reset_time', '');

                            //Reset password
                            $this->_customerRepository->save($customer, $this->_commonHelper->getHashedString(trim($newdetail['new_pass'])));

                            //Send SMS to user on passoword reset
                            $this->_smsNotificationHelper->sendSms(
                                    $customer->getCustomAttribute('mobile_number')->getValue(), 'Hi, Your account password reset successfully. Thank You'
                            );

                            $response[0]['status'] = 1;
                            $response[0]['msg'] = 'Password reset successfully';
                        } catch (Exception $e) {
                            $response[0]['status'] = 0;
                            $response[0]['msg'] = 'Error: '.$e->getMessage();
                        }
                    } else {
                        $response[0]['status'] = 0;
                        $response[0]['msg'] = 'OTP is Wrong';
                    }
                } else {
                    $response[0]['status'] = 0;
                    $response[0]['msg'] = 'OTP has been expired';
                }
            }
        }

        return $response;
    }

}
