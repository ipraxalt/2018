<?php
namespace Escorts\EtcProfile\Api;
 
interface ProfileInterface
{
    /**
     * Returns profile detail
     *
     * @api
     * @param string $user_id
     * @return JSON array with users detail.
     */
    public function detail($user_id);
    
    /**
     * @api
     * @param string $username
     * @return JSON array
     */
    public function forgotPassword($username);

    /**
     * @api
     * @param mixed $newdetail
     * @return JSON array
     */
    public function resetPassword($newdetail);
}