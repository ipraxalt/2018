<?php

/*
 * Escorts
 */

namespace Escorts\EtcProfile\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

class Customer implements ObserverInterface {

    protected $_scopeConfig;
    protected $_request;
    protected $_messageManager;
    protected $_responseFactory;
    protected $_url;
    protected $_tekinfoCustomerDetailModel;

    public function __construct(
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Magento\Framework\App\RequestInterface $request, \Magento\Framework\Message\ManagerInterface $messageManager, \Magento\Framework\App\ResponseFactory $responseFactory, \Magento\Framework\UrlInterface $url, \Escorts\Tekinfo\Model\CustomerDetail $_tekinfoCustomerDetailModel
    ) {
        $this->_scopeConfig = $scopeConfig;
        $this->_request = $request;
        $this->_messageManager = $messageManager;
        $this->_responseFactory = $responseFactory;
        $this->_url = $url;
        $this->_tekinfoCustomerDetailModel = $_tekinfoCustomerDetailModel;
    }
    

    /**
     * @param EventObserver $observer
     * @return $this
     */
    public function execute(EventObserver $observer) {
        if ($this->_request->isPost()) {
            //echo '<pre>'; print_r($this->_request->getPost());echo '</pre>';
            $data = $this->_request->getPost();
            if (!empty($data['mobile_number'])) {
                $result = $this->_tekinfoCustomerDetailModel->getCustomerByMobile(trim($data['mobile_number']));

                if (!empty($result['customer_id'])) {
                    $this->_messageManager->addError('Customer with this mobile number already exists!');
                    $url = $this->_url->getUrl('*/*/create', ['_secure' => true]);
                    $this->_responseFactory->create()->setRedirect($url)->sendResponse();
                    exit;
                }
                /* elseif (!empty($result['enquiry_customer_id'])) {
                  echo 'Enquiry Customer Exists';
                  } */
            }
        }
    }
}