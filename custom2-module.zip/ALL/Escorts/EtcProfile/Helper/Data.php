<?php
/**
 * Copyright © 2015 Escorts . All rights reserved.
 */
namespace Escorts\EtcProfile\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	
	/**
     * Service Dealer Group ID
     *
     * @var int
     */
	const SD_GROUP_ID = 4;
	
	/**
     * Broker Group ID
     *
     * @var int
     */
	const BROKER_GROUP_ID = 19;
	
	/**
     * Broker Group ID
     *
     * @var int
     */
	const MOL_ANMOL_GROUP_ID = 22;
	
	
	/**
     * @var \Magento\Customer\Model\CustomerFactory
     */
	protected $_customerFactory;
	
	/**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     */
	public function __construct(
		\Magento\Framework\App\Helper\Context $context,
		\Magento\Customer\Model\CustomerFactory $customerFactory
	) {		
		$this->_customerFactory = $customerFactory;
		parent::__construct($context);
	}
	
	
	public function getAllBrokers() {
		$brokers[''] ='Select';
		
		$brokersCollection = $this->_customerFactory->create()
			->getCollection()
			->addAttributeToSelect(array('id', 'name'))
			->addAttributeToFilter('group_id', array('eq' => self::BROKER_GROUP_ID))
			->load();
		if ($brokersCollection->getSize()) {
			foreach($brokersCollection as $item){
				$brokers[$item->getId()] = $item->getFirstname() . ' ' .  $item->getLastname();
			}
		}
		
		return $brokers;
	}
	
	public function getAllMolAnmol() {
		$molAnmol[''] = 'Select';
		
		$molAnmolCollection = $this->_customerFactory->create()
			->getCollection()
			->addAttributeToSelect(array('id', 'name'))
			->addAttributeToFilter('group_id', array('eq' => self::MOL_ANMOL_GROUP_ID))
			->load();
		if ($molAnmolCollection->getSize()) {
			foreach($molAnmolCollection as $item){
				$molAnmol[$item->getId()] = $item->getFirstname() . ' ' .  $item->getLastname();
			}
		}
		
		return $molAnmol;
	}
}