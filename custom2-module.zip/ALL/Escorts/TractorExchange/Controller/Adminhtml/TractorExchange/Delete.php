<?php
namespace Escorts\TractorExchange\Controller\Adminhtml\TractorExchange;

class Delete extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    public function execute()
    {
		$id = $this->getRequest()->getParam('tractor_exchange_id');
		try {
				$banner = $this->_objectManager->get('Escorts\TractorExchange\Model\Exchange')->load($id);
				$banner->delete();
                $this->messageManager->addSuccess(
                    __('Delete successfully !')
                );
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            }
	    $this->_redirect('*/*/');
    }
}
