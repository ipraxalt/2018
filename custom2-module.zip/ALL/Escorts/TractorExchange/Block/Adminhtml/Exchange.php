<?php
namespace Escorts\TractorExchange\Block\Adminhtml;
class Exchange extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
		
        $this->_controller = 'adminhtml_exchange';/*block grid.php directory*/
        $this->_blockGroup = 'Escorts_TractorExchange';
        $this->_headerText = __('Exchange');
        $this->_addButtonLabel = __('Add New Entry'); 
        parent::_construct();
		$this->removeButton('add');
    }
}
