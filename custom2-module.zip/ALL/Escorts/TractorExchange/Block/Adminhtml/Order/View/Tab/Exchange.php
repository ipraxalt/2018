<?php

namespace Escorts\TractorExchange\Block\Adminhtml\Order\View\Tab;


class Exchange extends \Magento\Backend\Block\Template implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * Template
     *
     * @var string
     */
    protected $_template = 'order/view/tab/exchange.phtml';

    /**
     * @var \Escorts\TractorExchange\Model\ExchangeFactory $exchangeFactory
     */
    protected $_exchangeFactory;

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry = null;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param array $data
     */
    public function __construct(
        \Escorts\TractorExchange\Model\ExchangeFactory $exchangeFactory, 
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->_exchangeFactory = $exchangeFactory;
        $this->coreRegistry = $registry;
        parent::__construct($context, $data);
    }

    /**
     * Retrieve order model instance
     *
     * @return \Magento\Sales\Model\Order
     */

    public function getExchange(){
        $orderId = (int)$this->getRequest()->getParam('order_id');
        $exchangeCollection = $this->_exchangeFactory->create()->getCollection();
        return $exchangeCollection->addFieldToFilter('order_id', array('eq' => $orderId));
    }

    /**
     * {@inheritdoc}
     */
    public function getTabLabel()
    {
        return __('Tractor Exchange');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __('Exchange');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        // For me, I wanted this tab to always show
        // You can play around with the ACL settings 
        // to selectively show later if you want
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        // For me, I wanted this tab to always show
        // You can play around with conditions to
        // show the tab later
        $orderId = (int)$this->getRequest()->getParam('order_id');
        $exchangeCollection = $this->_exchangeFactory->create()->getCollection();
        $checkdata = $exchangeCollection->addFieldToFilter('order_id', array('eq' => $orderId));
        if ($checkdata->getSize()>0) {
            return false;
        }else{
            return true;
        }
    }

    /**
     * Get Tab Class
     *
     * @return string
     */
    public function getTabClass()
    {
        // I wanted mine to load via AJAX when it's selected
        // That's what this does
        return 'ajax only';
    }

    /**
     * Get Class
     *
     * @return string
     */
    public function getClass()
    {
        return $this->getTabClass();
    }
}