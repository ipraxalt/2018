<?php

namespace Escorts\TractorExchange\Block\Adminhtml\Exchange\Renderer;

use Magento\Framework\DataObject;
use Magento\Framework\App\Filesystem\DirectoryList;

class RightImage extends \Magento\Framework\Data\Form\Element\AbstractElement
{
    protected $_backendUrl;
    protected $request;
    protected $_storeManager;
    protected $_filesystem;
    /**
     *@var \Escorts\TractorExchange\Model\ExchangeFactory $exchangeFactory
     **/
    protected $_exchangeFactory;
    protected $_order;
    public function __construct( 
        \Magento\Backend\Model\UrlInterface $backendUrl,
        \Escorts\TractorExchange\Model\ExchangeFactory $exchangeFactory,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Sales\Model\Order $order,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Filesystem $_filesystem
    ) {
        $this->_order = $order;
        $this->request = $request;
        $this->_storeManager = $storeManager;
        $this->_filesystem = $_filesystem;
        $this->_exchangeFactory = $exchangeFactory;
        $this->_backendUrl = $backendUrl;
    }

    public function getOrderId()
    {
        $id = $this->request->getParam('tractor_exchange_id');
        $model = $this->_exchangeFactory->create()->load($id);
        return $model->getOrderId();
    }

    public function getElementHtml()
    {
        $id = $this->request->getParam('tractor_exchange_id');
        $model = $this->_exchangeFactory->create()->load($id);

        $orderId = $this->getOrderId();
        $order = $this->_order->load($orderId);
        $customerId = $order->getCustomerId();

        $mediapath=$this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
        $imgPath = $mediapath.'customer/customer-'.$customerId.'/exchange/'.$model->getImageRightPath();

        $mediaUrl = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        $imgUrl = $mediaUrl.'customer/customer-'.$customerId.'/exchange/'.$model->getImageRightPath();

        if ($model->getImageRightPath()) {
            if (file_exists($imgPath)) {
                return $img = '<label>Right Image : </label><img style="width:25%" src="'.$imgUrl.'" >';
            }
        }
    }

}