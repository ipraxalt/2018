<?php

namespace Escorts\TractorExchange\Block\Adminhtml\Exchange\Renderer;

use Magento\Framework\DataObject;

class Addlink extends \Magento\Framework\Data\Form\Element\AbstractElement
{
    protected $_backendUrl;
    protected $request;
    /**
     *@var \Escorts\TractorExchange\Model\ExchangeFactory $exchangeFactory
     **/
    protected $_exchangeFactory;
    protected $_order;
    public function __construct( 
        \Magento\Backend\Model\UrlInterface $backendUrl,
        \Escorts\TractorExchange\Model\ExchangeFactory $exchangeFactory,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Sales\Model\Order $order
    ) {
        $this->_order = $order;
        $this->request = $request;
        $this->_exchangeFactory = $exchangeFactory;
        $this->_backendUrl = $backendUrl;
    }

    public function getOrderId()
    {
        $id = $this->request->getParam('tractor_exchange_id');
        $model = $this->_exchangeFactory->create()->load($id);
        return $model->getOrderId();
    }

    public function getElementHtml()
    {
        $order_id = $this->getOrderId();
        $increment_id = $this->_order->load($order_id)->getIncrementId();
        $url = $this->_backendUrl->getUrl("sales/order/view", array('order_id'=>$order_id));
        $orderLink = "<a href='".$url."' target='_blank'>Return to Order (".$increment_id.")</a>";
        return $orderLink;
    }

}