<?php
namespace Escorts\TractorExchange\Block\Adminhtml\Exchange\Edit\Tab;
class TractorExchange extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
    /**
     * @var \Escorts\Common\Helper\Data
     */
    protected $_commonhelper;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Escorts\Common\Helper\Data $commonhelper,
        array $data = array()
    ) {
        $this->_systemStore = $systemStore;
        $this->_commonhelper = $commonhelper;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
		/* @var $model \Magento\Cms\Model\Page */
        $model = $this->_coreRegistry->registry('escorts_tractor_exchange');
		$isElementDisabled = false;
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('page_');

        $fieldset = $form->addFieldset('base_fieldset', array('legend' => __('TractorExchange')));

        if ($model->getTractorExchangeId()) {
            $fieldset->addField('tractor_exchange_id', 'hidden', array('name' => 'tractor_exchange_id'));
        }

        $fieldset->addType('order_id', '\Escorts\TractorExchange\Block\Adminhtml\Exchange\Renderer\Addlink');

        $fieldset->addField(
            'order_id',
            'order_id',
            array(
                'name'  => 'order_id',
                'label' => __('Custom Div'),
                'title' => __('Custom Div'),
               
            )
        );

		$fieldset->addField(
            'tractor_make',
            'text',
            array(
                'name' => 'tractor_make',
                'label' => __('Tractor Make'),
                'title' => __('Tractor Make'),
                /*'disabled' => true,*/
                'required' => true,
            )
        );
        $fieldset->addField(
            'tractor_model',
            'text',
            array(
                'name' => 'tractor_model',
                'label' => __('Tractor Model'),
                'title' => __('Tractor Model'),
                'required' => true,
            )
        );
        $fieldset->addField(
            'manufacturer_year',
            'text',
            array(
                'name' => 'manufacturer_year',
                'label' => __('Manufacturer Year'),
                'title' => __('Manufacturer Year'),
                'required' => true,
            )
        );
        $fieldset->addField(
            'tyre_condition',
            'select',
            array(
                'name' => 'tyre_condition',
                'label' => __('Tyre Condition'),
                'title' => __('Tyre Condition'),
                'options' => $this->getOptionArray(),
                'required' => true,
            )
        );
        $fieldset->addField(
            'hours',
            'text',
            array(
                'name' => 'hours',
                'label' => __('Hours'),
                'title' => __('Hours'),
                'required' => true,
            )
        );
        $fieldset->addField(
            'is_accidental',
            'select',
            array(
                'name' => 'is_accidental',
                'label' => __('Accidental'),
                'title' => __('Accidental'),
                'options' => $this->getOptionArray1(),
                'required' => true,
            )
        );
        $fieldset->addField(
            'customer_expected_price',
            'text',
            array(
                'name' => 'customer_expected_price',
                'label' => __('Customer Expected Price'),
                'title' => __('Customer Expected Price'),
                'required' => true,
            )
        );

        $fieldset->addField(
            'assigned_broker',
            'select',
            array(
                'name' => 'assigned_broker',
                'label' => __('Assigned Broker'),
                'title' => __('Assigned Broker'),
                'options' => $this->_commonhelper->getAllBrokers(),
                'required' => true,
            )
        );
        $fieldset->addField(
            'broker_quote_price',
            'text',
            array(
                'name' => 'broker_quote_price',
                'label' => __('Broker Quote Price'),
                'title' => __('Broker Quote Price'),
                'required' => true,
            )
        );
        $fieldset->addField(
            'assigned_mol_anmol',
            'select',
            array(
                'name' => 'assigned_mol_anmol',
                'label' => __('Assigned Mol Anmol'),
                'title' => __('Assigned Mol Anmol'),
                'options' => $this->_commonhelper->getAllMolAnmol(),
                'required' => true,
            )
        );
        $fieldset->addField(
            'mol_anmol_quote_price',
            'text',
            array(
                'name' => 'mol_anmol_quote_price',
                'label' => __('Mol Anmol Quote Price'),
                'title' => __('Mol Anmol Quote Price'),
                'required' => true,
            )
        );

        $fieldset->addType('image_front_path', '\Escorts\TractorExchange\Block\Adminhtml\Exchange\Renderer\FrontImage');

        $fieldset->addField(
            'image_front_path',
            'image_front_path',
            array(
                'name'  => 'image_front_path',
                'label' => __('Image Front Path'),
                'title' => __('Image Front Path'),
               
            )
        );

        $fieldset->addType('image_back_path', '\Escorts\TractorExchange\Block\Adminhtml\Exchange\Renderer\BackImage');

        $fieldset->addField(
            'image_back_path',
            'image_back_path',
            array(
                'name'  => 'image_back_path',
                'label' => __('Image Back Path'),
                'title' => __('Image Back Path'),
               
            )
        );

        $fieldset->addType('image_left_path', '\Escorts\TractorExchange\Block\Adminhtml\Exchange\Renderer\LeftImage');

        $fieldset->addField(
            'image_left_path',
            'image_left_path',
            array(
                'name'  => 'image_left_path',
                'label' => __('image_left_path'),
                'title' => __('image_left_path'),
               
            )
        );

        $fieldset->addType('image_right_path', '\Escorts\TractorExchange\Block\Adminhtml\Exchange\Renderer\RightImage');

        $fieldset->addField(
            'image_right_path',
            'image_right_path',
            array(
                'name'  => 'image_right_path',
                'label' => __('image_right_path'),
                'title' => __('image_right_path'),
               
            )
        );
        $fieldset->addType('rc_copy_path', '\Escorts\TractorExchange\Block\Adminhtml\Exchange\Renderer\RcImage');

        $fieldset->addField(
            'rc_copy_path',
            'rc_copy_path',
            array(
                'name'  => 'rc_copy_path',
                'label' => __('rc_copy_path'),
                'title' => __('rc_copy_path'),
               
            )
        );
		/*{{CedAddFormField}}*/
        
        if (!$model->getTractorExchangeId()) {
            $model->setData('status', $isElementDisabled ? '2' : '1');
        }

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();   
    }

    /**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('TractorExchange');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return __('TractorExchange');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }

    public function getOptionArray()
    {
        return $data_array = array(''=>'Select Tyre Condition','1'=>'25%','2'=>'50%','3'=>'75%','4'=>'100');
    }

    public function getOptionArray1()
    {
        return $option = array('Yes','No');
    }
}
