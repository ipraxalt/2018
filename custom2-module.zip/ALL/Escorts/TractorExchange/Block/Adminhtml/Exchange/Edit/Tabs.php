<?php
namespace Escorts\TractorExchange\Block\Adminhtml\Exchange\Edit;

class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    protected function _construct()
    {
		
        parent::_construct();
        $this->setId('checkmodule_exchange_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Exchange Information'));
    }
}