<?php

namespace Escorts\Core\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    public function isWebsite($key)
    {
        
    }
}