<?php
namespace Escorts\WeatherForecast\Block;

class CurrentWeather extends \Magento\Framework\View\Element\Template implements \Magento\Widget\Block\BlockInterface
{
	/**
	 * @var \Magento\Customer\Model\Session $customerSession;
	 */
	protected $customerSession;

	/**
	 * @var \Magento\Customer\Model\CustomerFactory $customerFactory
	 */
	protected $customerFactory;

	function __construct(
		\Magento\Framework\View\Element\Template\Context $context,
		\Magento\Customer\Model\Session $customerSession,
		\Magento\Customer\Model\CustomerFactory $customerFactory,
		array $data = []
	) {
		$this->customerSession = $customerSession;
		$this->customerFactory = $customerFactory;
		parent::__construct($context,$data);
	}

	public function getCustomer()
	{
		return $this->customerSession->getCustomer()->getData();
	}

	public function getCurrentWeather()
	{
		if ($this->getCustomer()) {
			$id = $this->customerSession->getCustomer()->getId();
			echo "<pre>"; print_r($id);
			$customer = $this->customerFactory->create()->load($id);
			$billingAddress = $customer->getDefaultBilling();
			//echo "<pre>***"; print_r($billingAddress); echo "</pre>";
			$shippingAddress = $customer->getDefaultShipping();
			
			if ($shippingAddress) {
				echo "<pre>+++"; print_r($shippingAddress); echo "</pre>";
			}elseif ($billingAddress) {
				echo "<pre>***"; print_r($billingAddress); echo "</pre>";
			}
		}
	}
}