<?php
/**
 * Copyright © 2015 Escorts . All rights reserved.
 */
namespace Escorts\WeatherForecast\Helper;
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

	const XML_WEATHER_CURRENT_URL = 'escorts_weather/weatherforecast/current_weather_url';
    const XML_WEATHER_FORECAST_URL = 'escorts_weather/weatherforecast/forecast_weather_url';
    const XML_WEATHER_API_KEY = 'escorts_weather/weatherforecast/api_key';
    const LOOP_BREAK = 30;
    const API_RESPONSE_CODE_SUCCESS = 200;

	/**
	 * @var \Magento\Framework\HTTP\Client\Curl
	 */
	protected $_curl;

	/**
	 * @var \Escorts\Blocks\Model\TehsilFactory
	 */
	protected $_tehsilFactory;

	/**
	 * @var \Escorts\WeatherForecast\Model\DailyFactory
	 */
	protected $_dailyWeather;

	/**
	 * @var \Escorts\WeatherForecast\Model\WeeklyFactory
	 */
	protected $_weeklyWeather;

	/**
	 * @var \Magento\Framework\Json\Helper\Data
	 */
	protected $jsonHelper;
	/**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\HTTP\Client\Curl $curl
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     * @param \Escorts\Blocks\Model\TehsilFactory $_tehsilFactory
     * @param \Escorts\WeatherForecast\Model\DailyFactory $_dailyWeather
     * @param \Escorts\WeatherForecast\Model\WeeklyFactory $_weeklyWeather
     */
	public function __construct(
		\Magento\Framework\App\Helper\Context $context,
		\Magento\Framework\HTTP\Client\Curl $curl,
		\Magento\Framework\Json\Helper\Data $jsonHelper,
		\Escorts\Blocks\Model\TehsilFactory $_tehsilFactory,
		\Escorts\WeatherForecast\Model\DailyFactory $_dailyWeather,
		\Escorts\WeatherForecast\Model\WeeklyFactory $_weeklyWeather
	) {
		$this->_curl = $curl;
		$this->jsonHelper = $jsonHelper;
		$this->_tehsilFactory = $_tehsilFactory;
		$this->_dailyWeather = $_dailyWeather;
		$this->_weeklyWeather = $_weeklyWeather;
		parent::__construct($context);
	}

	public function getWeatherForecastCredentials() {
        return array(
            'weather_current_url' => $this->scopeConfig->getValue(
                    self::XML_WEATHER_CURRENT_URL, \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            ),
            'weather_forecast_url' => $this->scopeConfig->getValue(
                    self::XML_WEATHER_FORECAST_URL, \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            ),
            'api_key' => $this->scopeConfig->getValue(
                    self::XML_WEATHER_API_KEY, \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            )
        );
    }

	public function getCurrentWeatherForecast()
	{
		$credentials = $this->getWeatherForecastCredentials();
		$_tehsil = $this->_tehsilFactory->create()->getCollection();
		try {
			$count = 0;
			foreach ($_tehsil as $tehsil) {
				$_tehsilname = explode('-', $tehsil->getName());
				$url = $credentials['weather_current_url'].'?q='.$_tehsilname[0].'&appid='.$credentials['api_key'];
				$this->_curl->get($url);
				$response = $this->_curl->getBody();
				$result = $this->jsonHelper->jsonDecode($response);
				if ($result['cod'] == self::API_RESPONSE_CODE_SUCCESS) {
					$dailyCollection = $this->_dailyWeather->create()->getCollection();
					$dailyCollection->addFieldToFilter('tehsil_id',array('eq' => $tehsil->getId()));
					$minTemp = $this->kelvin_to_celsius($result['main']['temp_min']);
					$maxtemp = $this->kelvin_to_celsius($result['main']['temp_max']);
					$date = $this->strtotimeToDate($result['dt']);
					$sunrise = $this->strtotimeToDate($result['sys']['sunrise']);
					$sunset = $this->strtotimeToDate($result['sys']['sunset']);

					if ($dailyCollection->getSize() == 0) {
						$dailyModel = $this->_dailyWeather->create();
						$dailyModel->setTehsilId($tehsil->getId());
						$dailyModel->setMinTemp($minTemp);
						$dailyModel->setMaxTemp($maxtemp);
						$dailyModel->setHumidity($result['main']['humidity']);
						$dailyModel->setWindSpeed($result['wind']['speed']);
						$dailyModel->setDate($date);
						$dailyModel->setSunrise($sunrise);
						$dailyModel->setSunset($sunset);
						$dailyModel->setLongitude($result['coord']['lon']);
						$dailyModel->setLatitude($result['coord']['lat']);
						$dailyModel->setResult($response);
						$dailyModel->save();
					}else{
						$dailyModel = $this->_dailyWeather->create()->load($tehsil->getId(),'tehsil_id');
						$dailyModel->setMinTemp($minTemp);
						$dailyModel->setMaxTemp($maxtemp);
						$dailyModel->setHumidity($result['main']['humidity']);
						$dailyModel->setWindSpeed($result['wind']['speed']);
						$dailyModel->setDate($date);
						$dailyModel->setSunrise($sunrise);
						$dailyModel->setSunset($sunset);
						$dailyModel->setLongitude($result['coord']['lon']);
						$dailyModel->setLatitude($result['coord']['lat']);
						$dailyModel->setResult($response);
						$dailyModel->save();
					}
				}
				if (($count % 30) == 0 && $count!=0) { sleep(60); }
			    $count++;
			}
		} catch (\Exception $e) {
			return false;
		}
	}

	public function getFiveDayWeatherForecast()
	{
		$credentials = $this->getWeatherForecastCredentials();
		$_tehsil = $this->_tehsilFactory->create()->getCollection();
		try {
			$count = 0;
			foreach ($_tehsil as $tehsil) {
				$_tehsilname = explode('-', $tehsil->getName());
					$url = $credentials['weather_forecast_url'].'?q='.$_tehsilname[0].'&appid='.$credentials['api_key'];
					$this->_curl->get($url);
					$response = $this->_curl->getBody();
					$result = $this->jsonHelper->jsonDecode($response);
					if ($result['cod'] == self::API_RESPONSE_CODE_SUCCESS) {
						$dailyCollection = $this->_weeklyWeather->create()->getCollection();
						$dailyCollection->addFieldToFilter('tehsil_id',array('eq' => $tehsil->getId()));
						if ($dailyCollection->getSize() == 0) {
							$dailyModel = $this->_weeklyWeather->create();
							$dailyModel->setTehsilId($tehsil->getId());
							$dailyModel->setResult($response);
							$dailyModel->save();
						}else{
							$dailyModel = $this->_weeklyWeather->create()->load($tehsil->getId(),'tehsil_id');
							$dailyModel->setResult($response);
							$dailyModel->save();
						}
					}
					if (($count % 30) == 0 && $count!=0) { sleep(60); }
			    $count++;
			}
		} catch (\Exception $e) {
			
		}
	}

	public function kelvin_to_celsius($given_value)
	{
		$celsius=$given_value-273.15;
		return $celsius ;
	}

	public function strtotimeToDate($unixtime)
	{
		return $time = date("m/d/Y h:i:s A T",$unixtime);
	}
}