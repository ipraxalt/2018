<?php
namespace Escorts\WeatherForecast\Api;

interface WeatherInterface
{
	/**
     * @api
     * @param string $tehsil
     * @return JSON array with current weather details.
     */
    public function currentWeather($tehsil);

    /**
     * @api
     * @param string $lat
     * @param string $long
     * @return JSON array with current weather details.
     */
    public function currentWeatherByLatLong($lat,$long);

    /**
     * @api
     * @param string $tehsil
     * @return JSON array with weather forecast details.
     */
    public function weatherForecast($tehsil);

    /**
     * @api
     * @param string $lat
     * @param string $long
     * @return JSON array with current weather details.
     */
    public function weatherForecastByLatLong($lat,$long);
}
?>