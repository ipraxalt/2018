<?php
/**
 * Copyright © 2015 Escorts. All rights reserved.
 */

namespace Escorts\WeatherForecast\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * {@inheritdoc}
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
	
        $installer = $setup;

        $installer->startSetup();

		/**
         * Create table 'escorts_weatherforecast_daily'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('escorts_weatherforecast_daily')
        )
		->addColumn(
            'id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'id'
        )
		->addColumn(
            'district_name',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'district_name'
        )
		->addColumn(
            'min_temp',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'min_temp'
        )
		->addColumn(
            'max_temp',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'max_temp'
        )
		->addColumn(
            'humidity',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'humidity'
        )
		->addColumn(
            'wind_speed',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'wind_speed'
        )
		->addColumn(
            'date',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'date'
        )
		->addColumn(
            'sunrise',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'sunrise'
        )
        ->addColumn(
            'sunset',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'sunset'
        )
        ->addColumn(
            'longitude',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'longitude'
        )
        ->addColumn(
            'latitude',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'latitude'
        )
        ->addColumn(
            'result',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'result'
        )
		/*{{CedAddTableColumn}}}*/
		
		
        ->setComment(
            'Escorts WeatherForecast escorts_weatherforecast_daily'
        );
		
		$installer->getConnection()->createTable($table);

        /**
         * Create table 'escorts_weatherforecast_weekly'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('escorts_weatherforecast_weekly')
        )
        ->addColumn(
            'id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'id'
        )
        ->addColumn(
            'district_name',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'district_name'
        )
        ->addColumn(
            'min_temp',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'min_temp'
        )
        ->addColumn(
            'max_temp',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'max_temp'
        )
        ->addColumn(
            'humidity',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'humidity'
        )
        ->addColumn(
            'wind_speed',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'wind_speed'
        )
        ->addColumn(
            'date',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'date'
        )
        ->addColumn(
            'sunrise',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'sunrise'
        )
        ->addColumn(
            'sunset',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'sunset'
        )
        ->addColumn(
            'longitude',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'longitude'
        )
        ->addColumn(
            'latitude',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'latitude'
        )
        ->addColumn(
            'result',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'result'
        )
        /*{{CedAddTableColumn}}}*/
        
        
        ->setComment(
            'Escorts WeatherForecast escorts_weatherforecast_weekly'
        );

        $installer->getConnection()->createTable($table);
        $installer->endSetup();

    }
}
