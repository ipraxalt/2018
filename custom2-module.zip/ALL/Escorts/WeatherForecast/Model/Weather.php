<?php
namespace Escorts\WeatherForecast\Model;
use Escorts\WeatherForecast\Api\WeatherInterface;

/**
 * @class Escorts\WeatherForecast\Model\Weather
 */
class Weather implements WeatherInterface
{
	const XML_WEATHER_DEFAULT_LOCATION = 'escorts_weather/weatherforecast/default_location';
	const XML_GOOGLE_API_URL = 'escorts_weather/geo_location/geo_location_url';
	const XML_GOOGLE_API_KEY = 'escorts_weather/geo_location/geo_api_key';

	/**
	 * @var \Escorts\WeatherForecast\Model\DailyFactory
	 */
	protected $_dailyFactory;

	/**
	 * @var \Escorts\WeatherForecast\Model\WeeklyFactory
	 */

	protected $_weeklyFactory;

	/**
	 * @var \Escorts\Blocks\Model\TehsilFactory
	 */

	protected $_tehsilFactory;

	/**
	 * @var \Magento\Framework\HTTP\Client\Curl
	 */
	protected $_curl;

	/**
	 * @var \Magento\Framework\Json\Helper\Data
	 */
	protected $jsonHelper;

	function __construct(
		\Escorts\WeatherForecast\Model\DailyFactory $_dailyFactory,
		\Escorts\WeatherForecast\Model\WeeklyFactory $_weeklyFactory,
		\Escorts\Blocks\Model\TehsilFactory $_tehsilFactory,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\Magento\Framework\HTTP\Client\Curl $curl,
		\Magento\Framework\Json\Helper\Data $jsonHelper
	) {
		$this->_dailyFactory = $_dailyFactory;
		$this->_weeklyFactory = $_weeklyFactory;
		$this->_tehsilFactory = $_tehsilFactory;
		$this->scopeConfig = $scopeConfig;
		$this->_curl = $curl;
		$this->jsonHelper = $jsonHelper;
	}

	public function currentWeather($tehsil)
	{
		$response[0] = ['status' => 0];

		if (!empty($tehsil)) {
			$_tehsil = $this->_tehsilFactory->create()->load($tehsil,'name');
			if (!empty($_tehsil->getData())) {
				$_currentWeather = $this->_dailyFactory->create()->load($_tehsil->getId(),'tehsil_id');
				if (!empty($_currentWeather->getData())) {
					$response[0]['status'] = 1;
					$response[0]['result'] = $_currentWeather->getData();
	            	$response[0]['msg'] = 'Successfully get response.';
				}else{
					$location_id = $this->scopeConfig->getValue(
														self::XML_WEATHER_DEFAULT_LOCATION, 
														\Magento\Store\Model\ScopeInterface::SCOPE_STORE
													);

					$_currentWeather = $this->_dailyFactory->create()->load($location_id,'tehsil_id');
					$response[0]['status'] = 1;
					$response[0]['result'] = $_currentWeather->getData();
	            	$response[0]['msg'] = 'Successfully get response.';
				}
			}else{
				$location_id = $this->scopeConfig->getValue(
														self::XML_WEATHER_DEFAULT_LOCATION, 
														\Magento\Store\Model\ScopeInterface::SCOPE_STORE
													);

				$_currentWeather = $this->_dailyFactory->create()->load($location_id,'tehsil_id');
				$response[0]['status'] = 1;
				$response[0]['result'] = $_currentWeather->getData();
            	$response[0]['msg'] = 'Successfully get response.';
			}
		}else{
			$response[0]['status'] = 0;
            $response[0]['msg'] = 'Please provide all required parameters';
		}
		return $response;
	}

	public function weatherForecast($tehsil)
	{

		$response[0] = ['status' => 0];

		if (!empty($tehsil)) {
			$_tehsil = $this->_tehsilFactory->create()->load($tehsil,'name');
			if (!empty($_tehsil->getData())) {
				$_currentWeather = $this->_weeklyFactory->create()->load($_tehsil->getId(),'tehsil_id');
				if (!empty($_currentWeather->getData())) {
					$response[0]['status'] = 1;
					$response[0]['result'] = $_currentWeather->getData();
	            	$response[0]['msg'] = 'Successfully get response.';
				}else{
					$location_id = $this->scopeConfig->getValue(
														self::XML_WEATHER_DEFAULT_LOCATION, 
														\Magento\Store\Model\ScopeInterface::SCOPE_STORE
													);

					$_currentWeather = $this->_weeklyFactory->create()->load($location_id,'tehsil_id');
					$response[0]['status'] = 1;
					$response[0]['result'] = $_currentWeather->getData();
	            	$response[0]['msg'] = 'Successfully get response.';
				}
			}else{
				$location_id = $this->scopeConfig->getValue(
														self::XML_WEATHER_DEFAULT_LOCATION, 
														\Magento\Store\Model\ScopeInterface::SCOPE_STORE
													);

				$_currentWeather = $this->_weeklyFactory->create()->load($location_id,'tehsil_id');
				$response[0]['status'] = 1;
				$response[0]['result'] = $_currentWeather->getData();
            	$response[0]['msg'] = 'Successfully get response.';
			}
		}else{
			$response[0]['status'] = 0;
            $response[0]['msg'] = 'Please provide all required parameters';
		}
		return $response;
	}

	public function currentWeatherByLatLong($lat,$long)
	{
		$api_url = $this->scopeConfig->getValue(
									self::XML_GOOGLE_API_URL,
									\Magento\Store\Model\ScopeInterface::SCOPE_STORE
								);
		$api_key = $this->scopeConfig->getValue(
									self::XML_GOOGLE_API_KEY,
									\Magento\Store\Model\ScopeInterface::SCOPE_STORE
								);

		$url = $api_url.'latlng='.$lat.','.$long.'&key='.$api_key;
		$this->_curl->get($url);
		$responses = $this->_curl->getBody();
		$result = $this->jsonHelper->jsonDecode($responses);
		$tehsil = $result['results'][0]['address_components'][1]['long_name'];

		if (!empty($tehsil)) {
			$_tehsil = $this->_tehsilFactory->create()->load($tehsil,'name');
			if (!empty($_tehsil->getData())) {
				$_currentWeather = $this->_dailyFactory->create()->load($_tehsil->getId(),'tehsil_id');
				if (!empty($_currentWeather->getData())) {
					$response[0]['status'] = 1;
					$response[0]['result'] = $_currentWeather->getData();
	            	$response[0]['msg'] = 'Successfully get response.';
				}else{
					$location_id = $this->scopeConfig->getValue(
														self::XML_WEATHER_DEFAULT_LOCATION, 
														\Magento\Store\Model\ScopeInterface::SCOPE_STORE
													);

					$_currentWeather = $this->_dailyFactory->create()->load($location_id,'tehsil_id');
					$response[0]['status'] = 1;
					$response[0]['result'] = $_currentWeather->getData();
	            	$response[0]['msg'] = 'Successfully get response.';
				}
			}else{
				$location_id = $this->scopeConfig->getValue(
														self::XML_WEATHER_DEFAULT_LOCATION, 
														\Magento\Store\Model\ScopeInterface::SCOPE_STORE
													);

				$_currentWeather = $this->_dailyFactory->create()->load($location_id,'tehsil_id');
				$response[0]['status'] = 1;
				$response[0]['result'] = $_currentWeather->getData();
            	$response[0]['msg'] = 'Successfully get response.';
			}
		}else{
			$response[0]['status'] = 0;
            $response[0]['msg'] = 'Please provide all required parameters';
		}

		return $response;
	}

	public function weatherForecastByLatLong($lat,$long)
	{
		$api_url = $this->scopeConfig->getValue(
									self::XML_GOOGLE_API_URL,
									\Magento\Store\Model\ScopeInterface::SCOPE_STORE
								);
		$api_key = $this->scopeConfig->getValue(
									self::XML_GOOGLE_API_KEY,
									\Magento\Store\Model\ScopeInterface::SCOPE_STORE
								);

		$url = $api_url.'latlng='.$lat.','.$long.'&key='.$api_key;
		$this->_curl->get($url);
		$responses = $this->_curl->getBody();
		$result = $this->jsonHelper->jsonDecode($responses);
		$tehsil = $result['results'][0]['address_components'][1]['long_name'];

		if (!empty($tehsil)) {
			$_tehsil = $this->_tehsilFactory->create()->load($tehsil,'name');
			if (!empty($_tehsil->getData())) {
				$_currentWeather = $this->_weeklyFactory->create()->load($_tehsil->getId(),'tehsil_id');
				if (!empty($_currentWeather->getData())) {
					$response[0]['status'] = 1;
					$response[0]['result'] = $_currentWeather->getData();
	            	$response[0]['msg'] = 'Successfully get response.';
				}else{
					$location_id = $this->scopeConfig->getValue(
														self::XML_WEATHER_DEFAULT_LOCATION, 
														\Magento\Store\Model\ScopeInterface::SCOPE_STORE
													);

					$_currentWeather = $this->_weeklyFactory->create()->load($location_id,'tehsil_id');
					$response[0]['status'] = 1;
					$response[0]['result'] = $_currentWeather->getData();
	            	$response[0]['msg'] = 'Successfully get response.';
				}
			}else{
				$location_id = $this->scopeConfig->getValue(
														self::XML_WEATHER_DEFAULT_LOCATION, 
														\Magento\Store\Model\ScopeInterface::SCOPE_STORE
													);

				$_currentWeather = $this->_weeklyFactory->create()->load($location_id,'tehsil_id');
				$response[0]['status'] = 1;
				$response[0]['result'] = $_currentWeather->getData();
            	$response[0]['msg'] = 'Successfully get response.';
			}
		}else{
			$response[0]['status'] = 0;
            $response[0]['msg'] = 'Please provide all required parameters';
		}

		return $response;
	}
}