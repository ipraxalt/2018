<?php
/**
 * Copyright © 2015 Escorts. All rights reserved.
 */
namespace Escorts\WeatherForecast\Model\ResourceModel;

/**
 * Weekly resource
 */
class Weekly extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('escorts_weatherforecast_weekly', 'id');
    }

  
}
