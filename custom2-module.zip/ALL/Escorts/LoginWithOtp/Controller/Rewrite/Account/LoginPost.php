<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Escorts\LoginWithOtp\Controller\Rewrite\Account;

use Magento\Customer\Model\Account\Redirect as AccountRedirect;
use Magento\Framework\App\Action\Context;
use Magento\Customer\Model\Session;
use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Model\Url as CustomerUrl;
use Magento\Framework\Exception\EmailNotConfirmedException;
use Magento\Framework\Exception\AuthenticationException;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\State\UserLockedException;
use Magento\Framework\App\Config\ScopeConfigInterface;

/**
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class LoginPost extends \Magento\Customer\Controller\Account\LoginPost
{
    /**
     * @var \Magento\Customer\Api\AccountManagementInterface
     */
    protected $customerAccountManagement;
    protected $_customerRepository;
    protected $_customerSession;
    protected $_accountRedirect;



    /**
     * @param Context $context
     * @param Session $customerSession
     * @param AccountManagementInterface $customerAccountManagement
     * @param CustomerUrl $customerHelperData
     * @param Validator $formKeyValidator
     * @param AccountRedirect $accountRedirect
     */
    public function __construct(
        Context $context,
        Session $customerSession,            
        AccountManagementInterface $customerAccountManagement,
        CustomerUrl $customerHelperData,
        Validator $formKeyValidator,
        AccountRedirect $accountRedirect,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository
        
    ) {
        $this->_customerRepository = $customerRepository;
        $this->_customerSession = $customerSession;
        $this->_accountRedirect = $accountRedirect;
        parent::__construct($context, $customerSession, $customerAccountManagement, $customerHelperData, $formKeyValidator, $accountRedirect);
        
    }
    

    /**
     * Login post action
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function execute()
    {
        if ($this->session->isLoggedIn() || !$this->formKeyValidator->validate($this->getRequest())) {
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setPath('*/*/');
            return $resultRedirect;
        }

        /* request post */
        if ($this->getRequest()->isPost()) {
            
            $login = $this->getRequest()->getPost('login');            
            if (!empty($login['customer_mobile']) && !empty($login['customer_otp']) && !empty($login['customer_id'])) {
                
                $customer = $this->_customerRepository->getById(trim($login['customer_id']));
                
                if ($customer) {
                    
                    $otp = is_null($customer->getCustomAttribute('pass_reset_otp')) ? '' : $customer->getCustomAttribute('pass_reset_otp')->getValue();
                    $time = is_null($customer->getCustomAttribute('pass_reset_time')) ? '' : $customer->getCustomAttribute('pass_reset_time')->getValue();
                    $validPeriod = round(abs(time() - $time) / 60);

                    if ($time) {
                        if ($validPeriod <= 10) {   //check OTP valid time period (10 minutes)
                            if ( $otp === trim($login['customer_otp']) ) {
                                
                                try { 
                                    //Reset custom attribute value of customer
                                    $customer->setCustomAttribute('pass_reset_otp', '');
                                    $customer->setCustomAttribute('pass_reset_time', '');

                                    $this->_customerRepository->save($customer);
                                    
                                    // Login user into system
                                    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                                    $customerForLogin = $objectManager->create('Magento\Customer\Model\Customer')->load($login['customer_id']); 
                                    $this->_customerSession->setCustomerAsLoggedIn($customerForLogin);                                    
                                    
                                    $this->messageManager->addSuccessMessage(
                                        __('Login successfully')
                                    );
                                    $this->_redirect('customer/account/');
//                                    $redirectUrl = $this->_accountRedirect->getRedirectCookie();
//                                    if (!$this->getScopeConfig()->getValue('customer/startup/redirect_dashboard') && $redirectUrl) {
//                                        $this->_accountRedirect->clearRedirectCookie();
//                                        $resultRedirect = $this->resultRedirectFactory->create();
//                                        // URL is checked to be internal in $this->_redirect->success()
//                                        $resultRedirect->setUrl($this->_redirect->success($redirectUrl));
//                                        return $resultRedirect;
//                                    }

                                }
                                catch (UserLockedException $e) {
                                    $message = __(
                                        'You did not sign in correctly or your account is temporarily disabled.'
                                    );
                                    $this->messageManager->addError($message);
                                    
                                } catch (AuthenticationException $e) {
                                    $message = __('You did not sign in correctly or your account is temporarily disabled.');
                                    $this->messageManager->addError($message);

                                } catch (LocalizedException $e) {
                                    $message = $e->getMessage();
                                    $this->messageManager->addError($message);

                                } catch (\Exception $e) {
                                    // PA DSS violation: throwing or logging an exception here can disclose customer password
                                    $this->messageManager->addError(
                                        __('An unspecified error occurred. Please contact us for assistance.')
                                    );
                                }
                            }
                            else{
                                $this->messageManager->addError(
                                    __('OTP Mismatched! Please try again.')
                                );
                            }
                        }
                        else{
                            $this->messageManager->addError(
                                __('OTP expired! Please try again.')
                            );
                        }
                    }
                    else{
                        $this->messageManager->addError(
                            __('OTP expired! Please try again.')
                        );
                    }
                }
                else{
                    $this->messageManager->addError(
                        __('No user account exists for provided detail.')
                    );
                }
                 
                return $this->accountRedirect->getRedirect();
                
            }
            
            else if ( !isset($login['username']) && !isset($login['password']) ) {  // return error (mobile login)
                $this->messageManager->addError(
                    __('Something went wrong. "Missing parameters or your session has been expired"')
                );
                return $this->accountRedirect->getRedirect();                
                //return parent::execute();
            }
            
            else{   // login request with email & password, forward it to main 'LoginPost' action
                return parent::execute();
            }
            
        }

        return parent::execute();
    }
}
