<?php
namespace Escorts\LoginWithOtp\Controller\Ajax;

use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Action\Action;

class Index extends Action
{
    protected $request;
    protected $_storeManager;
    protected $_customerFactory;
    protected $_customerRepository;
    protected $_smsNotificationHelper;
    protected $_commonHelper;
    
    public function __construct(
            \Magento\Framework\App\Action\Context $context,
            \Magento\Customer\Model\CustomerFactory $customerFactory, 
            \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,             
            \Escorts\SmsNotification\Helper\Data $smsNotificationHelper,
            \Escorts\Common\Helper\Data $commonHelper,
            array $data = []
    ) {
        //$this->_storeManager = $storeManager;
        $this->_customerFactory = $customerFactory;
        $this->_customerRepository = $customerRepository;
        $this->_smsNotificationHelper = $smsNotificationHelper;
        $this->_commonHelper = $commonHelper;
        parent::__construct($context,$data);
    } 

    public function execute() {
        
        //$a =  date("H:i", strtotime("04:25 PM"));
        //echo $a/3;

        //echo "<pre>";        print_r($_POST);
        //die;
        
        $customer_mobile = $_POST['customer_mobile'];
        $response = ['status' => 0, 'msg' => 'Invalid Request', 'entity' => '0'];

        if (!empty($customer_mobile)) {
            
            $otp = $this->_commonHelper->generateOtp();

            $collection = $this->_customerFactory->create()
                            ->getCollection()
                            ->addAttributeToSelect("*")
                            ->addAttributeToFilter("mobile_number", ["eq" => $customer_mobile])
                            ->setPageSize(1)
                            ->load();

            if (!empty($collection->getSize())) {
                
                $customer_data = $collection->getFirstItem();
                $mobileNumber = $customer_data->getMobileNumber();

                $customer = $this->_customerRepository->getById($customer_data->getId());
                if ($customer) {
                    $customer->setCustomAttribute('pass_reset_otp', $otp);
                    $customer->setCustomAttribute('pass_reset_time', time());
                    try {
                        $customer = $this->_customerRepository->save($customer);
                    } catch (Exception $e) {
                        //return $e->getMessage();
                        $response = ['status' => 0, 'msg' => 'Error: '.$e->getMessage(), 'entity' => '0'];
                    }

                    $smsText = "Your Login OTP is " . $otp . ". Its valid for 10 minutes.";
                    $this->_smsNotificationHelper->sendSms($mobileNumber, $smsText);

                    $response = ['status' => 1, 'msg' => 'We have sent an OTP on your registered mobile number', 'entity' => $customer->getId()];
                }
            } else {
                $response = ['status' => 0, 'msg' => 'No user account exists for provided detail', 'entity' => '0'];
            }

        } else {
            $response = ['status' => 0, 'msg' => 'Mobile number Missing', 'entity' => '0'];
        }

        
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $resultJson->setData($response); 
        return $resultJson; 
        
        //return $response;        
    }

}
