/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var config = {
    /*map: {
        '*': {
            mycomponent: 'Magentoexplorer_Helloworld/js/myscript'
        }
    }*/
    
    paths:{
        "jquery.custom":"Escorts_LoginWithOtp/js/myscript"
    },

    shim:{
        'jquery.custom':{
            'deps':['jquery']
        }
    }
};
