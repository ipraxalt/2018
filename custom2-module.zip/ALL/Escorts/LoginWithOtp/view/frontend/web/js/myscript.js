/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



require(['jquery', 'mage/url'],function($, url){
    
    /* login option */
    $('#login-option').change(function(){
        if( $(this).val() == 'mobile_login' ){
            $('.login-by-mobile').slideDown(700);
            $('.login-by-email').hide();
        }
        else if( $(this).val() == 'email_login' ){
            $('.login-by-mobile').hide();
            $('.login-by-email').slideDown(700);
        }
        else{
            $('.login-by-mobile').hide();
            $('.login-by-email').hide();
        }
    });
    
    /* request OTP */
    $(document).on('click','#get-otp',function(e) {
        e.preventDefault();
        mobile = $('#customer_mobile').val();
        if($('#customer_mobile').val() == ''){
            $('.message-holder').text('Mobile number Missing').addClass('mage-error');
            $('#customer_mobile').focus();
            return false;
        }
        else{
            $('.message-holder').text('').removeClass('mage-error');
        }
        
        $.ajax({
            showLoader: true,
            method: "POST",
            //url: "/loginwithotp/ajax/index",
            url: url.build('loginwithotp/ajax/index'),
            data: { customer_mobile: mobile},
            dataType: "json"
        })
        .done(function( response ) {
            if(response.status == '1'){
                $('#get-otp').text('Resend OTP');
                $('.message-holder').text(response.msg).removeClass('mage-error').addClass('mage-success');
                $('.otp-block').slideDown(500);
                $('#customer_id').val(response.entity);
                $('#customer_otp').focus();
                return false;
            }
            else{
                $('.message-holder').text(response.msg).removeClass('mage-success').addClass('mage-error');
                $('#customer_id').val(response.entity);
                $('.otp-block').slideUp(500);
                $('#customer_mobile').focus();
                return false;
            }
            //console.log("Message: "+ response);
        }); 
    });
    
    
     
});

