<?php
namespace Escorts\VehicleInsurance\Model\ResourceModel\VehicleInsurance;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'insurance_id';
	protected $_eventPrefix = 'escorts_vehicleInsurance_collection';
	protected $_eventObject = 'tractor_vehicleInsurance_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct(){
		$this->_init('Escorts\VehicleInsurance\Model\VehicleInsurance', 'Escorts\VehicleInsurance\Model\ResourceModel\VehicleInsurance');
	}
}