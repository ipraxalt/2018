<?php
namespace Escorts\VehicleInsurance\Model;

class VehicleInsurance extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'escorts_tractor_vehicleInsurance';
	protected $_cacheTag = 'escorts_tractor_vehicleInsurance';
	protected $_eventPrefix = 'escorts_tractor_vehicleInsurance';

	protected function _construct(){
		$this->_init('Escorts\VehicleInsurance\Model\ResourceModel\VehicleInsurance');
	}

	public function getIdentities(){
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues(){
		$values = [];
		return $values;
	}
}