<?php

/**
 * Copyright © 2015 Escorts . All rights reserved.
 */

namespace Escorts\PushNotification\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $_customerFactory;
    protected $_notificationFactory;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
    \Magento\Framework\App\Helper\Context $context, \Magento\Customer\Model\CustomerFactory $customerFactory, \Escorts\PushNotification\Model\NotificationFactory $notificationFactory
    ) {
        $this->_customerFactory = $customerFactory;
        $this->_notificationFactory = $notificationFactory;
        parent::__construct($context);
    }

    public function sendPushNotificationToAndroid($title, $body, $data, $type, $userId, $groupId = null) {
        /* $url = "https://fcm.googleapis.com/fcm/send";
          $serverKey = 'AAAA7jm_bMo:APA91bHCi_QMAzGNxxcaTFasCeh934_bGftcHTeSYq0dc1T_sr4jtZKcyl4ocMNtjcVqwy4sZP0UJmsDJJF35l_n74zCTRyZYm1D1GL3DLWcRyr30AHeIgCVLcUrYuAYnBgl6z3eBviH';
          $title = "Title";
          $body = "Body of the message";
          $notification = array('title' =>$title , 'text' => $body, 'sound' => 'default', 'badge' => '1');
          $arrayToSend = array('to' => $token, 'notification' => $notification,'priority'=>'high');
          $json = json_encode($arrayToSend);
          $headers = array();
          $headers[] = 'Content-Type: application/json';
          $headers[] = 'Authorization: key='. $serverKey;
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL, $url);

          curl_setopt($ch, CURLOPT_CUSTOMREQUEST,

          "POST");
          curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
          curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
          //Send the request
          $response = curl_exec($ch);
          //Close request
          if ($response === FALSE) {
          die('FCM Send Error: ' . curl_error($ch));
          }
          //$response = curl_exec($ch);

          curl_close($ch);

          return $response; */

        $res = false;
        $firebase_cm = 'https://fcm.googleapis.com/fcm/send';

        //$serverKey = 'AAAA7jm_bMo:APA91bHCi_QMAzGNxxcaTFasCeh934_bGftcHTeSYq0dc1T_sr4jtZKcyl4ocMNtjcVqwy4sZP0UJmsDJJF35l_n74zCTRyZYm1D1GL3DLWcRyr30AHeIgCVLcUrYuAYnBgl6z3eBviH';
        $serverKey = 'AAAA7jm_bMo:APA91bHCi_QMAzGNxxcaTFasCeh934_bGftcHTeSYq0dc1T_sr4jtZKcyl4ocMNtjcVqwy4sZP0UJmsDJJF35l_n74zCTRyZYm1D1GL3DLWcRyr30AHeIgCVLcUrYuAYnBgl6z3eBviH';
        
        $token = $this->getCustomerDeviceIdByCustomerId($userId);
        
        if ($token) {
            $fields = array();
            $fields['data'] = $data;
            $fields['data']['title'] = $title;
            $fields['data']['body'] = $body;
            $fields['data']['sound'] = 'default';
            $fields['to'] = $token;

            $headers = array();
            $headers[] = 'Content-Type: application/json';
            $headers[] = 'Authorization: key=' . $serverKey;
            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, $firebase_cm);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
            $result = json_decode(curl_exec($ch));
            curl_close($ch);

            //id, user_id, user_type, title, body, data, created_at
            if ($result->success) {
                $notification = $this->_notificationFactory->create();
                $notification->setUserId($userId);
                $notification->setGroupId($groupId);
                $notification->setType($type);    //1: Admin, 2: Customer
                $notification->setTitle($title);
                $notification->setBody($body);
                $notification->setMessage(serialize($data));
                $notification->save();
                //$id = $notification->getId();
                $res = true;
            }
        }

        return $res;
    }

    /*     * ***************************************************************** */

    public function getCustomerDeviceIdByCustomerId($id) {
        $customer = $this->_customerFactory->create()->load($id);
        if ($customer) {
            return $customer->getDeviceId() ? $customer->getDeviceId() : false;
        } else {
            return false;
        }
    }

}