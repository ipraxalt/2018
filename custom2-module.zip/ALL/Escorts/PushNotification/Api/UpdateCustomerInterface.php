<?php
namespace Escorts\PushNotification\Api;
 
interface UpdateCustomerInterface
{
     /**
     * @param mixed $updateCustomer
     * @return void
     */
    public function updateCustomerDeviceId($updateCustomer);
	
	/**
	 * @param int $status
     * @return Array
     */
    public function getNotificationList($status=2);

	
	/**
     * @param int $notificationId
     * @return Array
     */
    public function getNotificationDetail($notificationId);
	
	/**
     * @param int $notificationId
     * @return Void
     */
    public function setNotificationRead($notificationId);
}