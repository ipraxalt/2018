<?php
namespace Escorts\PushNotification\Model\ResourceModel\Notification;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
	protected $_eventPrefix = 'escorts_push_notification_collection';
	protected $_eventObject = 'escorts_push_collection';
	
	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct(){
		$this->_init('Escorts\PushNotification\Model\Notification', 'Escorts\PushNotification\Model\ResourceModel\Notification');
	}
}