<?php
namespace Escorts\PushNotification\Model;

class Notification extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'escorts_push_notification';
	protected $_cacheTag = 'escorts_push_notification';
	protected $_eventPrefix = 'escorts_push_notification';

	protected function _construct() {
		$this->_init('Escorts\PushNotification\Model\ResourceModel\Notification');
	}

	public function getIdentities() {
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues() {
		$values = [];
		return $values;
	}
}