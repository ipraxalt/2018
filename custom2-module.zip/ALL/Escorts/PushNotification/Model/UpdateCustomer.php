<?php
namespace Escorts\PushNotification\Model;
use Escorts\PushNotification\Api\UpdateCustomerInterface;
 
class UpdateCustomer implements UpdateCustomerInterface 
{
	protected $_request;
	protected $_customer;
    protected $_customerFactory;
	protected $_notificationFactory;
	protected $_commonHelper;
	
	
	/*****************************************************/
	public function __construct(
      	\Magento\Framework\App\RequestInterface $request,
		\Magento\Customer\Model\Customer $customer,
      	\Magento\Customer\Model\ResourceModel\CustomerFactory $customerFactory,
		\Escorts\PushNotification\Model\NotificationFactory $notificationFactory,
		\Escorts\Common\Helper\Data $commonHelper
    ) {
       	$this->_request = $request;
		$this->_customer = $customer;
       	$this->_customerFactory = $customerFactory;
		$this->_notificationFactory = $notificationFactory;
		$this->_commonHelper = $commonHelper;
    }
	
    
	/*****************************************************/
	public function updateCustomerDeviceId($updateCustomer) {
		$deviceId = $updateCustomer['device_id'];
		$customerId = $updateCustomer['customer_id'];
		$customer = $this->_customer->load($customerId);
		$customerData = $customer->getDataModel();
		$customerData->setCustomAttribute('device_id',$deviceId);
		$customer->updateData($customerData);
		$customerResource = $this->_customerFactory->create();
		$customerResource->saveAttribute($customer, 'device_id');
				 
		$response[0]['message'] = 'Device Id added Successfully'; 	 
								 
		return $response;
    }
    
	
	/*****************************************************/
    public function getNotificationList($status=2) {
        $notifications = array();
		
		if ($userId = $this->_commonHelper->getCustomerIdByToken($this->_request->getHeader('Authorization'))) {
			$collection = $this->_notificationFactory->create()
				->getCollection()
				->addFieldToFilter('user_id', array('eq' => $userId))
				->addFieldToSelect(array('id', 'title', 'body', 'message', 'created_at', 'is_read'));
			
			if ($status > 0) {
				$collection->addFieldToFilter('is_read', array('eq' => $status));
			}
			
			$collection->setOrder('is_read','ASC');

			if ($collection->getSize()) {
				foreach ($collection as $item) {
					$notifications[] = array(
						'id' => $item->getId(),
						'title' => $item->getTitle(),
						'body' => $item->getBody(),
						'data' => unserialize($item->getMessage()),
						'created_at' => $item->getCreatedAt(),
						'is_read' => $item->getIsRead()
					);
				}
			}
		}
		
		return $notifications;
    }
	
	public function getNotificationDetail($notificationId) {
		$notification = array();
		
		if ($userId = $this->_commonHelper->getCustomerIdByToken($this->_request->getHeader('Authorization'))) {
			$collection = $this->_notificationFactory->create()
				->getCollection()
				->addFieldToFilter('id', array('eq' => $notificationId))
				->addFieldToFilter('user_id', array('eq' => $userId))
				->addFieldToSelect(array('id', 'title', 'body', 'message', 'created_at', 'is_read'))
				->setPageSize(1);

			if ($collection->getSize()) {				
				$item = $collection->getFirstItem();
				$notification[] = array(
					'id' => $item->getId(),
					'title' => $item->getTitle(),
					'body' => $item->getBody(),
					'data' => unserialize($item->getMessage()),
					'created_at' => $item->getCreatedAt(),
					'is_read' => $item->getIsRead()
				);
			}
		}
		
		return $notification;
	}
	
	
	public function setNotificationRead($notificationId) {
		$response = array(array('status' => 0), array('msg' => 'Error: Try again later.'));
		
		if ($userId = $this->_commonHelper->getCustomerIdByToken($this->_request->getHeader('Authorization'))) {
			$collection = $this->_notificationFactory->create()
				->getCollection()
				->addFieldToFilter('id', array('eq' => $notificationId))
				->addFieldToFilter('user_id', array('eq' => $userId))
				->addFieldToSelect(array('id', 'is_read'))
				->setPageSize(1);

			if ($collection->getSize()) {
				$item = $collection->getFirstItem();
				$item->setIsRead(2);
				$item->save();
				$response = array(array('status' => 1), array('msg' => 'Marked read successfully.'));
			}
		}
		
		return $response;
	}
	
}