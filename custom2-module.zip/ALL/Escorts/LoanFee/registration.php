<?php
/**
 * @author 18th Technology
 * @copyright Copyright (c) 2018 18th Technology (http://www.18thtechnology.com/)
 * @package Eighteentech_Htmlsitemap
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Escorts_LoanFee',
    __DIR__
);
