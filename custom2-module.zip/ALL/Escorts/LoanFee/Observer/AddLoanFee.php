<?php

/*
 * Escorts
 */

namespace Escorts\LoanFee\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

class AddLoanFee implements ObserverInterface {

    const LOAN_VALUE = 1;
    const ATTRIBUTE_SET_ID = 13;
    const LOAN_PRODUCT_ID = 22;
    protected $_scopeConfig;
    protected $_request;
    protected $_messageManager;
    protected $_responseFactory;
    protected $_url;
    protected $_productFactory;
    protected $formKey;   
    protected $cart;
    //protected $product;

    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Magento\Checkout\Model\Cart $cart,
        //\Magento\Catalog\Model\Product $product,
        \Magento\Framework\UrlInterface $url,
        \Magento\Quote\Api\CartRepositoryInterface $cartRepositoryInterface,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        $this->_storeManager = $storeManager;
        $this->_scopeConfig = $scopeConfig;
        $this->_request = $request;
        $this->_messageManager = $messageManager;
        $this->_responseFactory = $responseFactory;
        $this->_productFactory = $productFactory;
        $this->formKey = $formKey;
        $this->cart = $cart;
        //$this->product = $product; 
        $this->_url = $url;
        $this->cartRepositoryInterface = $cartRepositoryInterface;
    }
    

    /**
     * @param EventObserver $observer
     * @return $this
     */
    public function execute(EventObserver $observer)
    {
        $store = $this->_storeManager->getStore();
        $request = $observer->getEvent()->getRequest();
        //echo "<pre>===>"; print_r($request->getPost()); echo "</pre>";
        $_product = $this->_productFactory->create()->load($request->getPost('product'));
        if ($_product->getAttributeSetId() == self::ATTRIBUTE_SET_ID) {
            if ($request->getPost('options')[1] == self::LOAN_VALUE) {
                $_products = $this->_productFactory->create()->load(self::LOAN_PRODUCT_ID);
                $params = array(
                    'form_key' => $this->formKey->getFormKey(),
                    'product' => self::LOAN_PRODUCT_ID,
                    'qty'   => $request->getPost('qty'),
                    'price' => $_products->getPrice()
                );

                //echo "<pre>"; print_r($params); echo "</pre>";

                $this->cart->addProduct($_products, new \Magento\Framework\DataObject($params));
                $this->cart->save();
                /*$this->cart->updateItem(self::LOAN_PRODUCT_ID, new \Magento\Framework\DataObject($params));
                $this->cart->save();
                $cartId = $this->cart->getQuote()->getId();
                $quote = $this->cartRepositoryInterface->get($cartId);
                $quote->setStore($store);
                $quote->addProduct($_products, intval($params['qty']));
                $quote->save();*/
                // get quote items array
                // $items = $this->cart->getQuote()->getAllItems();
                 
                /*foreach($items as $item) {
                    if ($item->getProductId() == self::LOAN_PRODUCT_ID) {
                        $item->setQty($request->getPost('qty'));
                        $item->setPrice($_products->getPrice());
                        $item->setBasePrice($_products->getPrice());
                        $item->setRowTotal($request->getPost('qty')*$_products->getPrice());
                        $item->setBaseRowTotal($request->getPost('qty')*$_products->getPrice());
                        $item->save();
                    }
                }
                $this->cart->save();*/
            }
        }
        return true;
    }
}