<?php

namespace Escorts\Common\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper {

    const TRACTOR_ATTRIBUTE_SET_ID = '13';

    protected $_backendUrl;
    protected $_resourceConnection;
    protected $_customerFactory;
    protected $_addressModel;
    protected $_tokenModel;
    protected $_orderModel;
    protected $_storeManagerInterface;
    protected $_encryptor;
    protected $_currencyFactory;
    protected $_order;
    protected $_productFactory;
    protected $_regionModel;
    protected $_customerEnquiryFactory;
    protected $_villageFactory;
    protected $_blockHelper;
    protected $_etcProfileHelper;
    protected $_tekInfoHelper;
    protected $_serviceFactory;
    protected $_notificationHelper;
    protected $_smsNotificationHelper;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Backend\Model\UrlInterface $backendUrl
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Backend\Model\UrlInterface $backendUrl,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Customer\Model\Address $addressModel,
        \Magento\Integration\Model\Oauth\Token $tokenModel,
        \Magento\Sales\Model\Order $orderModel,
        \Magento\Store\Model\StoreManagerInterface $storeManagerInterface,
        \Magento\Directory\Model\CurrencyFactory $currencyFactory,
        \Magento\Framework\Encryption\EncryptorInterface $encryptor,
        \Magento\Sales\Model\Order $order,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Directory\Model\Region $regionModel,
        \Escorts\Village\Model\VillageFactory $villageFactory,
        \Escorts\Tekinfo\Model\CustomerEnquiryFactory $customerEnquiryFactory,
        \Escorts\Blocks\Helper\Data $blockHelper,
        \Escorts\EtcProfile\Helper\Data $etcProfileHelper,
        \Escorts\Tekinfo\Helper\Data $tekInfoHelper,
        \Escorts\ServiceRequest\Model\ServiceFactory $serviceFactory,
        \Escorts\PushNotification\Helper\Data $notificationHelper,
        \Escorts\SmsNotification\Helper\Data $smsNotificationHelper
    ) {
        $this->_backendUrl = $backendUrl;
        $this->_resourceConnection = $resourceConnection;
        $this->_customerFactory = $customerFactory;
        $this->_addressModel = $addressModel;
        $this->_tokenModel = $tokenModel;
        $this->_orderModel = $orderModel;
        $this->_storeManagerInterface = $storeManagerInterface;
        $this->_encryptor = $encryptor;
        $this->_currencyFactory = $currencyFactory;
        $this->_order = $order;
        $this->_productFactory = $productFactory;
        $this->_regionModel = $regionModel;
        $this->_customerEnquiryFactory = $customerEnquiryFactory;
        $this->_villageFactory = $villageFactory;
        $this->_blockHelper = $blockHelper;
        $this->_etcProfileHelper = $etcProfileHelper;
        $this->_tekInfoHelper = $tekInfoHelper;
        $this->_serviceFactory = $serviceFactory;
        $this->_notificationHelper = $notificationHelper;
        $this->_smsNotificationHelper = $smsNotificationHelper;
        parent::__construct($context);
    }

    /*     * ***************************************************** */

    public function isWebsite($key) {
        
    }

    /*     * ***************************************************** */

    public function getCustomerPostCodeByMobile($mobile) {
        $collection = $this->_customerFactory->create()
                ->getCollection()
                ->addAttributeToSelect("*")
                ->addAttributeToFilter("mobile_number", array("eq" => $mobile))
                ->setPageSize(1)
                ->load();

        if (!empty($collection->getSize())) {
            $customer_data = $collection->getFirstItem();
            $address_id = $customer_data->getDefaultShipping();

            if (!empty($address_id)) {
                $shippingAddress = $this->_addressModel->load($address_id);
                $address = $shippingAddress->getData();
                //print_r($address);die;
                if (!empty($address['postcode'])) {
                    return $address['postcode'];
                }
            }
        } else {
            $collection = $this->_customerEnquiryFactory->create()
                    ->getCollection()
                    ->addFieldToSelect("*")
                    ->addFieldToFilter("mobile_number", array("eq" => $mobile))
                    ->setPageSize(1)
                    ->load();

            if (!empty($collection->getSize())) {
                $customer_data = $collection->getFirstItem();

                if (!empty($customer_data->getPostCode())) {
                    return $customer_data->getPostCode();
                }
            }
        }
        return false;
    }

    public function getCustomerPostCodeByID($id) {
        $customer = $this->_customerFactory->create()->load($id);

        if ($customer) {
            $address_id = $customer->getDefaultShipping();

            if (!empty($address_id)) {
                $shippingAddress = $this->_addressModel->load($address_id);
                $address = $shippingAddress->getData();
                //print_r($address);die;
                if (!empty($address['postcode'])) {
                    return $address['postcode'];
                }
            }
        }/* else {
          $collection = $this->_customerEnquiryFactory->create()
          ->getCollection()
          ->addFieldToSelect("*")
          ->addFieldToFilter("mobile_number", array("eq" => $mobile))
          ->setPageSize(1)
          ->load();

          if (!empty($collection->getSize())) {
          $customer_data = $collection->getFirstItem();

          if (!empty($customer_data->getPostCode())) {
          return $customer_data->getPostCode();
          }
          }
          } */
        return false;
    }

    public function getCustomerMobileByID($id) {
        $customer = $this->_customerFactory->create()->load($id);

        if ($customer) {
            return $customer->getMobileNumber();
        }
        return false;
    }

    /**
     * @param string $postcode
     */
    public function getBrokerByPostCode($postcode) {
        return $this->_blockHelper->getBrokerByPostCode($postcode);
    }

    /**
     * @param string $token
     */
    public function isEtcToken($token) {
        $allowedGroups = array(4, 7, 10);
        //$allowedGroups = array(16, 19, 22);
        $token = trim(str_replace('Bearer', '', $token));
        $tokenObj = $this->_tokenModel->loadByToken($token);

        if ($customerId = $tokenObj->getCustomerId()) {

            $customer = $this->_customerFactory->create()->load($customerId);
            if ($groupId = $customer->getGroupId()) {
                if (in_array($groupId, $allowedGroups)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * @param string $token
     */
    public function getCustomerIdByToken($token) {
        $token = trim(str_replace('Bearer', '', $token));
        $tokenObj = $this->_tokenModel->loadByToken($token);

        if ($customerId = $tokenObj->getCustomerId()) {
            return $customerId;
        }
        return false;
    }

    /*     * ***************************************************** */

    public function getCountries() {
        return $this->_blockHelper->getCountries();
    }

    /*     * ***************************************************** */

    public function getStates($countryId = null) {
        return $this->_blockHelper->getStates($countryId);
    }

    /*     * ***************************************************** */

    public function getDistricts($stateId = null) {
        return $this->_blockHelper->getDistricts($stateId);
    }

    /*     * ***************************************************** */

    public function getTehsils($districtId = null) {
        return $this->_blockHelper->getTehsils($districtId);
    }

    /*     * ***************************************************** */

    public function getVillages($tehsilId = null) {
        return $this->_blockHelper->getVillages($tehsilId);
    }

    /*     * ***************************************************** */

    public function getPostCodeByVillageId($villageId = null) {
        return $this->_blockHelper->getPostCodeByVillageId($villageId);
    }

    /*     * ***************************************************** */

    public function getAllBrokers() {
        return $this->_etcProfileHelper->getAllBrokers();
    }

    /*     * ***************************************************** */

    public function getAllMolAnmol() {
        return $this->_etcProfileHelper->getAllMolAnmol();
    }

    /*     * ***************************************************** */

    public function getLoanBanks($postcode = null) {
        return array(
            'recommended' => array(
                1 => 'Chola Mandalam',
                2 => 'Escorts Finance'
            ),
            'others' => array(
                4 => 'SBI Bank',
                5 => 'Magma Finance'
            )
        );
    }

    /*     * ***************************************************** */

    public function getCustomerIdByOrderId($orderId) {
        $order = $this->_orderModel->loadByIncrementId($orderId);
        return empty($order->getCustomerId()) ? false : $order->getCustomerId();
    }

    /**
     * Retun Insurance Options
     *
     * @return Array
     */
    public function getInsuranceOption() {
        return $this->_tekInfoHelper->getInsuranceOption();
    }

    /**
     * Retun Store Currecy Code
     *
     * @return String
     */
    public function getStoreCurrencyCode() {
        return $this->_storeManagerInterface->getStore()->getCurrentCurrencyCode();
    }

    /**
     * Retun Store Currecy Symbol
     *
     * @return String
     */
    public function getStoreCurrencySymbol() {
        $currencyCode = $this->_storeManagerInterface->getStore()->getCurrentCurrencyCode();
        $currency = $this->_currencyFactory->create()->load($currencyCode);
        return $currency->getCurrencySymbol();
    }

    /**
     * Return Decryped String
     *
     * @return string or Boolean
     */
    public function getDecryptedString($passString) {
        if (!empty($passString)) {
            return $this->_encryptor->decrypt($passString);
        }
        return false;
    }
    
    /**
     * Return Hashed String
     *
     * @return string or Boolean
     */
    public function getHashedString($string) {
        if (!empty($string)) {
            return $this->_encryptor->getHash($string, true);
        }
        return false;
    }

    /*     * ***************************************************** */

    public function getCustomerDeviceIdByMobileNumber($mobileNumber) {
        $collection = $this->_customerFactory->create()
                ->getCollection()
                ->addAttributeToSelect("*")
                ->addAttributeToFilter("mobile_number", array("eq" => $mobileNumber))
                ->setPageSize(1)
                ->load();

        if (!empty($collection->getSize())) {
            $customer_data = $collection->getFirstItem();
            return $customer_data->getDeviceId() ? $customer_data->getDeviceId() : false;
        } else {
            return false;
        }
    }

    /* This function also copied in push notification helper*********************** */

    public function getCustomerDeviceIdByCustomerId($id) {
        $customer = $this->_customerFactory->create()->load($id);
        if ($customer) {
            return $customer->getDeviceId() ? $customer->getDeviceId() : false;
        } else {
            return false;
        }
    }

    /* Temporary code for testing */

    public function createPdiServieRequest($customerId, $orderId, $orderIncrimentId) {
        $orderItemId = 0;
        $postcode = $this->getCustomerPostCodeByID($customerId);

        $order = $this->_order->load($orderId);
        if ($orderItems = $order->getAllItems()) {
            foreach ($orderItems as $item) {
                $_product = $this->_productFactory->create()->load($item->getProductId());
                if ($_product->getAttributeSetId() == self::TRACTOR_ATTRIBUTE_SET_ID) {
                    $orderItemId = $_product->getAttributeSetId();
                    break;
                }
            }
        }

        if ($orderItemId) {
            $assigned_to = $this->_blockHelper->getBlockServiceDealer($postcode);
            if ($assigned_to) {
                $mobileNumber = $this->getCustomerMobileByID($assigned_to);
                $serviceRequest = $this->_serviceFactory->create();
                $serviceRequest->setOrderId($orderId);
                $serviceRequest->setOrderItemId($orderItemId);
                $serviceRequest->setCustomerId($customerId);
                $serviceRequest->setServiceRequestType(1);
                $serviceRequest->setAssignedTo($assigned_to);
                $serviceRequest->setIsFreeService(1);
                $serviceRequest->setServiceNo(0);
                $serviceRequest->save();

                if ($serviceRequest->getId()) {
                    $title = "PDI Service Request";
                    $body = "PDI Service for Order ID: #$orderIncrimentId";
                    $data = array('type' => 'pdi_service', 'service_request_id' => 1, 'service_type' => 1);
                    //1. Admin  2. Customer
                    $smsText = "A PDI request has been created for Order ID: #$orderIncrimentId. Please check your service requests in mobile App.";
                    $this->_smsNotificationHelper->sendSms($mobileNumber, $smsText);
                    $this->_notificationHelper->sendPushNotificationToAndroid($title, $body, $data, 2, $assigned_to);
                    return true;
                } else {
                    //PDI Service request not created
                }
            } else {
                //Service dealer is not available for this block
            }
        }

        return false;
    }

    public function createInstallationServieRequest($customerId, $orderId, $orderItemId, $assignedTo) {
        $mobileNumber = $this->getCustomerMobileByID($assignedTo);
        $serviceRequest = $this->_serviceFactory->create();
        $serviceRequest->setOrderId($orderId);
        $serviceRequest->setOrderItemId($orderItemId);
        $serviceRequest->setCustomerId($customerId);
        $serviceRequest->setServiceRequestType(2);
        $serviceRequest->setAssignedTo($assignedTo);
        $serviceRequest->setIsFreeService(1);
        $serviceRequest->setServiceNo(0);
        $serviceRequest->save();

        if ($serviceRequest->getId()) {
            $title = "Installation Service Request";
            $body = "Installation Service for Order ID: #$orderId";
            $data = array('type' => 'installation_service', 'service_request_id' => $serviceRequest->getId(), 'service_type' => 2);
            //1. Admin  2. Customer
            $smsText = "An Installation service request has been created for Order ID: #$orderId. Please check your service requests in mobile App.";
            //$this->_smsNotificationHelper->sendSms($mobileNumber, $smsText);
            $this->_notificationHelper->sendPushNotificationToAndroid($title, $body, $data, 2, $assignedTo);
            return true;
        } else {
            //PDI Service request not created
        }

        return false;
    }
    /* Temporary code end */
    
    

    /* Get Customer name by customer ID ********************** */

    public function getCustomerNameById($id) {
        $name = '';
        $customer = $this->_customerFactory->create()->load($id);
        if ($customer) {
            $name = $customer->getName();
        }
        return $name;
    }
    
    /* Get 4 digit OTP ********************** */
    public function generateOtp($digits = 4){
        $i = 0; //counter
        $pin = ""; //our default pin is blank.
        while($i < $digits){
            //generate a random number between 0 and 9.
            $pin .= mt_rand(0, 9);
            $i++;
        }
        return $pin;
    }
    
    
    /* Get region code by name*/
    public function getRegionIdByName($region, $countryCode='IN') {
        $region =  $this->_regionModel->loadByName($region, $countryCode);
        return empty($region) ? false : $region->getId();
    }

}