<?php

namespace Escorts\ServiceRequest\Model;

use Escorts\ServiceRequest\Api\ServiceRequestInterface;
use Magento\Framework\Phrase;

class ServiceRequest implements ServiceRequestInterface {

    protected $_postFactory;
    protected $helperData;
    protected $_customer;
    protected $_productloader;
    protected $_address;
    protected $_countryFactory;
    protected $_regionFactory;
    protected $_orderFactory;
    protected $timezone;
    protected $_request;
    protected $_serviceTypeFactory;
    protected $_serviceIssuesFactory;
    protected $_servicePid;
    protected $_serviceOpsions;
    protected $_jobNoFactory;
    protected $_commonHelper;
    protected $_serviceInstallation;

    public function __construct(
    \Escorts\ServiceRequest\Model\ServiceFactory $postFactory, \Escorts\ServiceRequest\Helper\Data $helperData, \Magento\Customer\Model\CustomerFactory $customer, \Magento\Catalog\Model\ProductFactory $_productloader, \Magento\Customer\Model\AddressFactory $address, \Magento\Directory\Model\CountryFactory $countryFactory, \Magento\Directory\Model\RegionFactory $regionFactory, \Magento\Sales\Model\OrderFactory $orderFactory, \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone, \Magento\Framework\App\RequestInterface $request, \Escorts\ServiceRequest\Model\RequestTypeFactory $serviceTypeFactory, \Escorts\ServiceRequest\Model\ServiceIssuesFactory $serviceIssuesFactory, \Escorts\ServiceRequest\Model\ServicePdiFactory $servicePid, \Escorts\ServiceRequest\Model\ServiceOptionsFactory $serviceOptions, \Escorts\ServiceRequest\Model\ServiceJobNoFactory $jobNoFactory, \Escorts\ServiceRequest\Model\ServiceInstallationFactory $serviceInstallation, \Escorts\Common\Helper\Data $commonHelper
    ) {
        $this->_postFactory = $postFactory;
        $this->helperData = $helperData;
        $this->_customer = $customer;
        $this->_productloader = $_productloader;
        $this->_address = $address;
        $this->_countryFactory = $countryFactory;
        $this->_regionFactory = $regionFactory;
        $this->_orderFactory = $orderFactory;
        $this->timezone = $timezone;
        $this->_request = $request;
        $this->_serviceTypeFactory = $serviceTypeFactory;
        $this->_serviceIssuesFactory = $serviceIssuesFactory;
        $this->_servicePid = $servicePid;
        $this->_serviceOpsions = $serviceOptions;
        $this->_jobNoFactory = $jobNoFactory;
        $this->_commonHelper = $commonHelper;
        $this->_serviceInstallation = $serviceInstallation;
    }

    public function createServiceRequest($ServiceRequestArray) {

        $response = array();
        $orderIdValue = null;
        $orderItemIdValue = null;
        $customerIdValue = null;
        $serviceRequesttypeValue = null;

        $orderId = array_key_exists('order_id', $ServiceRequestArray);
        if ($orderId) {
            $orderIdValue = $ServiceRequestArray['order_id'];
        }
        if (!$orderIdValue) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('order_id is required'), 0, \Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST);
            return $response;
        }

        $orderItemId = array_key_exists('order_item_id', $ServiceRequestArray);
        if ($orderItemId) {
            $orderItemIdValue = $ServiceRequestArray['order_item_id'];
        }
        if (!$orderItemIdValue) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('order_item_id is required'), 0, \Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST);
            return $response;
        }

        $customerId = array_key_exists('customer_id', $ServiceRequestArray);
        if ($customerId) {
            $customerIdValue = $ServiceRequestArray['customer_id'];
        }
        if (!$customerIdValue) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('customer_id is required'), 0, \Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST);
            return $response;
        }

        $serviceRequesttype = array_key_exists('service_request_type', $ServiceRequestArray);
        if ($serviceRequesttype) {
            $serviceRequesttypeValue = $ServiceRequestArray['service_request_type'];
        }
        if (!$serviceRequesttypeValue) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('service_request_type is required'), 0, \Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST);
            return $response;
        }

        $model = $this->_postFactory->create();
        $model->setData($ServiceRequestArray);
        $model->save();
        $response[0]['message'] = 'New service created successfully';

        return $response;
    }

    public function getServiceRequestList($statusId = null, $curPage = null, $pageSize = null) {

        if (!$token = $this->_commonHelper->isEtcToken($this->_request->getHeader('Authorization'))) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }
        
        $sdid = $this->_commonHelper->getCustomerIdByToken($token);
                
        $collector = array();
        $groupId = $this->_customer->create()->load($sdid)->getGroupId();
        if ($groupId != 4) {
            return $collector;
        }

        $tat = $this->helperData->getGeneralConfig('tat');

        $modelobj = $this->_postFactory->create();
        $collection = $modelobj->getCollection();
        $collection->addFieldToSelect('*');
        $collection->addFieldToFilter('assigned_to', array('eq' => $sdid));
        if ($statusId) {
            $collection->addFieldToFilter('status', array('eq' => $statusId));
        }
        
        if ($pageSize) {
            //$pageSize = 10;
            $collector[0]['pages'] = ceil($collection->getSize() / $pageSize);
            $collector[1]['total'] = $collection->getSize();
            $collection->setPageSize($pageSize);
        }        
        
        if ($curPage) {
            //$curPage = 1;
            $collection->setCurPage($curPage);
        }
        
        foreach ($collection as $key => $item) {
            $data['sr_id'] = (int) $item->getId();
            $data['created_at'] = $item->getCreatedAt();
            $data['status'] = (int) $item->getStatus();
            $data['left_time'] = $this->getLeftTime($item->getCreatedAt(), $tat);

            $productCollection = $this->_productloader->create()->load($item->getOrderItemId());
            $data['product_name'] = $productCollection->getName();

            $customer = $this->_customer->create()->load($item->getCustomerId());
            $shippingAddressId = $customer->getDefaultShipping();
            $address = $this->_address->create()->load($shippingAddressId);

            $customerAddress['name'] = $address->getName();
            $customerAddress['street'] = implode(" ", $address->getStreet());
            $customerAddress['village'] = $address->getVillage();
            $customerAddress['tehsil'] = $address->getTehsil();
            $customerAddress['district'] = $address->getCity();
            $customerAddress['country'] = $this->_countryFactory->create()->loadByCode($address->getCountryId())->getName();
            $customerAddress['postcode'] = $address->getPostcode();
            $customerAddress['telephone'] = $address->getTelephone();

            $state = $address->getRegionId();
            if (is_numeric($state)) {
                $state = $this->_regionFactory->create()->load($state)->getName();
            }

            $customerAddress['state'] = $state;
            $data['customer_address'] = $customerAddress;
            
            $collector[2]['requests'][] = $data;
        }
        

        return $collector;
    }

    public function getServiceRequestCustomer($srid) {

        if (!$this->_commonHelper->isEtcToken($this->_request->getHeader('Authorization'))) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }

        $customerAddress = array();
        $tat = $this->helperData->getGeneralConfig('tat');
        $modelobj = $this->_postFactory->create()->load($srid);

        $customer = $this->_customer->create()->load($modelobj->getCustomerId());
        $shippingAddressId = $customer->getDefaultShipping();
        $address = $this->_address->create()->load($shippingAddressId);
        $key = 0;

        $customerAddress[$key]['created_at'] = $modelobj->getCreatedAt();
        $customerAddress[$key]['left_time'] = $this->getLeftTime($modelobj->getCreatedAt(), $tat);
        $customerAddress[$key]['name'] = $address->getName();
        $customerAddress[$key]['father_name'] = $customer->getFatherName();
        $customerAddress[$key]['street'] = implode(" ", $address->getStreet());
        $customerAddress[$key]['landmark'] = $address->getLandmark();
        $customerAddress[$key]['village'] = $address->getVillage();
        $customerAddress[$key]['tehsil'] = $address->getTehsil();
        $customerAddress[$key]['district'] = $address->getCity();
        $customerAddress[$key]['country'] = $this->_countryFactory->create()->loadByCode($address->getCountryId())->getName();
        $customerAddress[$key]['postcode'] = $address->getPostcode();
        $customerAddress[$key]['telephone'] = $address->getTelephone();

        $state = $address->getRegionId();
        if (is_numeric($state)) {
            $state = $this->_regionFactory->create()->load($state)->getName();
        }

        $customerAddress[$key]['state'] = $state;
        return $customerAddress;
    }

    public function getServiceRequestTractor($srid) {

        if (!$this->_commonHelper->isEtcToken($this->_request->getHeader('Authorization'))) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }

        $collector = array();
        $tat = $this->helperData->getGeneralConfig('tat');
        $modelobj = $this->_postFactory->create()->load($srid);

        $productCollection = $this->_productloader->create()->load($modelobj->getOrderItemId());

        $orderCollection = $this->_orderFactory->create()->load($modelobj->getOrderId());
        $key = 0;

        if ($modelobj->getCreatedAt()) {
            $collector[$key]['created_at'] = $modelobj->getCreatedAt();
            $collector[$key]['left_time'] = $this->getLeftTime($modelobj->getCreatedAt(), $tat);
            $collector[$key]['model'] = $productCollection->getName();

            $attr = $productCollection->getResource()->getAttribute('brand');
            if ($attr->usesSource()) {
                $brand = $attr->getSource()->getOptionText($productCollection->getBrand());
                $collector[$key]['brand'] = $brand;
            }

            $collector[$key]['serial_number'] = $orderCollection->getSerialNumber1();
            $collector[$key]['engine_number'] = $orderCollection->getEngineNumber1();
            $collector[$key]['manufacturing_year'] = $orderCollection->getManufacturingYear1();
            $collector[$key]['delivery_date'] = $orderCollection->getDeliveryDate1();
            $collector[$key]['chassis_number'] = $orderCollection->getChassisNumber1();
        }

        return $collector;
    }

    public function getServiceRequestServiceDetail($srid) {

        if (!$this->_commonHelper->isEtcToken($this->_request->getHeader('Authorization'))) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }

        $collector = array();
        $issuesArray = array();
        $serviceTypeArray = array();
        $i = 0;
        $j = 0;

        $serviceIssuesCollection = $this->_serviceIssuesFactory->create()->getCollection();
        foreach ($serviceIssuesCollection as $item) {
            $issuesArray[$i]['id'] = $item->getId();
            $issuesArray[$i]['value'] = $item->getValue();
            $i++;
        }

        $serviceTypeCollection = $this->_serviceTypeFactory->create()->getCollection();
        foreach ($serviceTypeCollection as $item) {
            $serviceTypeArray[$j]['id'] = $item->getId();
            $serviceTypeArray[$j]['value'] = $item->getValue();
            $j++;
        }


        $tat = $this->helperData->getGeneralConfig('tat');
        $modelobj = $this->_postFactory->create()->load($srid);
        $key = 0;
        if ($modelobj->getCreatedAt()) {
            $collector[$key]['created_at'] = $modelobj->getCreatedAt();
            $collector[$key]['issue_list'] = $issuesArray;
            $collector[$key]['service_type_list'] = $serviceTypeArray;
            $collector[$key]['left_time'] = $this->getLeftTime($modelobj->getCreatedAt(), $tat);
            $collector[$key]['type'] = (int) $modelobj->getServiceRequestType();
            $collector[$key]['coupon_code'] = $modelobj->getCouponCode() ?: '';
            $collector[$key]['issues'] = $modelobj->getIssuesId();
            $collector[$key]['customer_comment'] = $modelobj->getCustomerComment();
            $collector[$key]['status'] = (int) $modelobj->getStatus();
        }
        return $collector;
    }

    public function getServiceRequestServiceType() {


        if (!$this->_commonHelper->isEtcToken($this->_request->getHeader('Authorization'))) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }

        $serviceTypeCollection = $this->_serviceTypeFactory->create()->getCollection();

        $collect = array();
        foreach ($serviceTypeCollection as $key => $item) {
            $collect[$key]['id'] = $item->getId();
            $collect[$key]['value'] = $item->getValue();
        }
        return $collect;
    }

    public function getServiceRequestServiceIssues() {

        if (!$this->_commonHelper->isEtcToken($this->_request->getHeader('Authorization'))) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }

        $serviceIssuesCollection = $this->_serviceIssuesFactory->create()->getCollection();

        $collect = array();
        foreach ($serviceIssuesCollection as $key => $item) {
            $collect[$key]['id'] = $item->getId();
            $collect[$key]['value'] = $item->getValue();
        }
        return $collect;
    }

    public function createServiceRequestPdi($serviceRequestPdi) {

        if (!$this->_commonHelper->isEtcToken($this->_request->getHeader('Authorization'))) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }

        $response = array();
        $srIdValue = null;
        $jobNoValue = null;

        $srId = array_key_exists('srid', $serviceRequestPdi);
        if ($srId) {
            $srIdValue = $serviceRequestPdi['srid'];
        }
        if (!$srIdValue) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('srid is required'), 0, \Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST);
            return $response;
        }

        $jobNo = array_key_exists('job_no', $serviceRequestPdi);
        if ($jobNo) {
            $jobNoValue = $serviceRequestPdi['job_no'];
        }
        if (!$jobNoValue) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('job_no is required'), 0, \Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST);
        }



        $jobCheck = $this->_jobNoFactory->create()->load($serviceRequestPdi['job_no']);
        $jobcheckServiceFormId = $jobCheck->getServiceFormId();

        if ($jobcheckServiceFormId) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('This PDI already created'), 0, \Magento\Framework\Webapi\Exception::HTTP_INTERNAL_ERROR);
        }

        $modelpdi = $this->_servicePid->create();
        $modelpdi->setData($serviceRequestPdi);
        $modelpdi->save();
        if ($modelpdi->getId()) {
            $message = '';
            $serviceModel = $this->_postFactory->create()->load($serviceRequestPdi['srid']);
            $serviceModel->setStatus(2);
            $serviceModel->save();

            if (!$serviceModel->getId()) {
                throw new \Magento\Framework\Webapi\Exception(new Phrase('Service request does\'t update status'), 0, \Magento\Framework\Webapi\Exception::HTTP_INTERNAL_ERROR);
            }

            $jobmodel = $this->_jobNoFactory->create()->load($serviceRequestPdi['job_no']);
            $jobmodel->setServiceFormId($modelpdi->getId());
            $jobmodel->setStatus(1);
            $jobmodel->save();

            if (!$jobmodel->getId()) {
                throw new \Magento\Framework\Webapi\Exception(new Phrase('Service request does\'t update job number.'), 0, \Magento\Framework\Webapi\Exception::HTTP_INTERNAL_ERROR);
                return $response;
            }
            if (!$message) {
                $message = 'Successfully save data';
            }

            $response[0]['message'] = $message;
        }

        /* Temporary code for testing */
        $customerId = $serviceModel->getCustomerId();
        $orderId = $serviceModel->getOrderId();
        $orderItemId = $serviceModel->getOrderItemId();
        $assignedTo = $serviceModel->getAssignedTo();
        $this->_commonHelper->createInstallationServieRequest($customerId, $orderId, $orderItemId, $assignedTo);

        return $response;
    }

    public function getServiceRequestOptions() {

        if (!$this->_commonHelper->isEtcToken($this->_request->getHeader('Authorization'))) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }

        $serviceOptionsCollection = $this->_serviceOpsions->create()->getCollection();
        $collect = array();
        foreach ($serviceOptionsCollection as $key => $item) {
            $collect[$key]['id'] = $item->getId();
            $collect[$key]['value'] = $item->getValue();
        }

        return $collect;
    }

    public function getServiceRequestJobNo($serviceRequestType, $srid) {

        if (!$this->_commonHelper->isEtcToken($this->_request->getHeader('Authorization'))) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }

        $response = '';
        $jobmodel = $this->_jobNoFactory->create();
        $collection = $jobmodel->getCollection();
        $collection->addFieldToSelect('id');
        $collection->addFieldToFilter('srid', array('eq' => $srid));
        $collection->addFieldToFilter('service_request_type', array('eq' => $serviceRequestType));
        $response = $collection->getData();

        if (!$response) {
            $jobmodel->setSrid($srid);
            $jobmodel->setServiceRequestType($serviceRequestType);
            $jobmodel->setStatus(0);
            $jobmodel->save();
            $response[]['id'] = $jobmodel->getId();
        }

        return $response;
    }

    public function getLeftTime($startDateTime, $tat) {
        $newDatetime = date('Y-m-d H:i:s', strtotime('+' . $tat . ' hours', strtotime($startDateTime)));
        $currentDateTime = $this->timezone->date()->format('Y-m-d H:i:s');

        $leftTime = "00:00:00";
        $createStartDateTime = date_create($currentDateTime);
        $createNewDatetime = date_create($newDatetime);
        if (strtotime($currentDateTime) < strtotime($newDatetime)) {
            $diff = date_diff($createStartDateTime, $createNewDatetime);
            $leftTime = $diff->format("%h:%i:%s");
        }
        return $leftTime;
    }

    public function getServiceRequestPdi($serviceRequestType, $srid) {
        $data = [];

        if (!$this->_commonHelper->isEtcToken($this->_request->getHeader('Authorization'))) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }

        $jobServiceFormId = null;
        $jobCartno = $this->getServiceRequestJobNo($serviceRequestType, $srid);

        if ($jobCartno) {
            $jobCheck = $this->_jobNoFactory->create()->load($jobCartno);
            $jobServiceFormId = $jobCheck->getServiceFormId();
        }
        if (empty($jobServiceFormId)) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('PDI isn\'t created'), 0, \Magento\Framework\Webapi\Exception::HTTP_INTERNAL_ERROR);
        }

        $modelpdi = $this->_servicePid->create()->load($jobServiceFormId);
        $serviceModelObj = $this->_postFactory->create()->load($srid);
        $productCollection = $this->_productloader->create()->load($serviceModelObj->getOrderItemId());
        $orderCollection = $this->_orderFactory->create()->load($serviceModelObj->getOrderId());

        $data[] = $modelpdi->getData();
        $data[0]['job_card_no'] = $jobCartno[0]['id'];
        $data[0]['dealer_code'] = $serviceModelObj->getAssignedTo();
        $data[0]['dealer_name'] = $this->_commonHelper->getCustomerNameById($serviceModelObj->getAssignedTo());
        $data[0]['model'] = $productCollection->getName();
        $data[0]['serial_number'] = $orderCollection->getSerialNumber1();
        $data[0]['engine_number'] = $orderCollection->getEngineNumber1();
        return $data;
    }

    public function createServiceRequestInstallation($serviceRequestInstallation) {

        if (!$this->_commonHelper->isEtcToken($this->_request->getHeader('Authorization'))) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }

        $response = array();
        $srIdValue = null;
        $jobNoValue = null;

        $srId = array_key_exists('srid', $serviceRequestInstallation);
        if ($srId) {
            $srIdValue = $serviceRequestInstallation['srid'];
        }
        
        if (!$srIdValue) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('srid is required'), 0, \Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST);
        }

        $jobNo = array_key_exists('job_no', $serviceRequestInstallation);
        if ($jobNo) {
            $jobNoValue = $serviceRequestInstallation['job_no'];
        }
        if (!$jobNoValue) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('job_no is required'), 0, \Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST);
        }



        $jobCheck = $this->_jobNoFactory->create()->load($serviceRequestInstallation['job_no']);
        $jobcheckServiceFormId = $jobCheck->getServiceFormId();

        if ($jobcheckServiceFormId) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('Installation already created'), 0, \Magento\Framework\Webapi\Exception::HTTP_INTERNAL_ERROR);
        }

        $modelInstallation = $this->_serviceInstallation->create();
        $modelInstallation->setData($serviceRequestInstallation);
        $modelInstallation->save();

        if ($modelInstallation->getId()) {
            $message = '';
            $model = $this->_postFactory->create()->load($serviceRequestInstallation['srid']);
            $model->setStatus(2);
            $model->save();

            if (!$model->getId()) {
                throw new \Magento\Framework\Webapi\Exception(new Phrase('Service request does\'t update status'), 0, \Magento\Framework\Webapi\Exception::HTTP_INTERNAL_ERROR);
            }

            $jobmodel = $this->_jobNoFactory->create()->load($serviceRequestInstallation['job_no']);
            $jobmodel->setServiceFormId($modelInstallation->getId());
            $jobmodel->setStatus(1);
            $jobmodel->save();

            if (!$jobmodel->getId()) {
                throw new \Magento\Framework\Webapi\Exception(new Phrase('Service request does\'t update job number.'), 0, \Magento\Framework\Webapi\Exception::HTTP_INTERNAL_ERROR);
            }
            if (!$message) {
                $message = 'Successfully save data';
            }

            $response[0]['message'] = $message;
        }
        
        //$this->_smsNotificationHelper->sendSms($mobileNumber, $smsText);

        return $response;
    }

    public function getServiceRequestInstallation($serviceRequestType, $srid) {

        if (!$this->_commonHelper->isEtcToken($this->_request->getHeader('Authorization'))) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('You aren\'t authorized user.'), 0, \Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED);
        }

        $jobServiceFormId = null;
        $jobCartno = $this->getServiceRequestJobNo($serviceRequestType, $srid);

        if ($jobCartno) {
            $jobCheck = $this->_jobNoFactory->create()->load($jobCartno);
            $jobServiceFormId = $jobCheck->getServiceFormId();
        }
        
        if (!$jobServiceFormId) {
            throw new \Magento\Framework\Webapi\Exception(new Phrase('Installation isn\'t created'), 0, \Magento\Framework\Webapi\Exception::HTTP_INTERNAL_ERROR);
        }

        $modelpdi = $this->_serviceInstallation->create()->load($jobServiceFormId);
        $serviceModelObj = $this->_postFactory->create()->load($srid);
        $productCollection = $this->_productloader->create()->load($serviceModelObj->getOrderItemId());
        $orderCollection = $this->_orderFactory->create()->load($serviceModelObj->getOrderId());
        
        $data[] = $modelpdi->getData();
        $data[0]['job_card_no'] = $jobCartno[0]['id'];
        $data[0]['customer_name'] = $this->_commonHelper->getCustomerNameById($serviceModelObj->getCustomerId());
        $data[0]['model'] = $productCollection->getName();
        $data[0]['serial_number'] = $orderCollection->getSerialNumber1();
        $data[0]['engine_number'] = $orderCollection->getEngineNumber1();
        $data[0]['chassis_number'] = $orderCollection->getChassisNumber1();
        return $data;
    }

}
