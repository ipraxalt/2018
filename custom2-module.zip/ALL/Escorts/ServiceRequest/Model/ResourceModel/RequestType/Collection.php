<?php

namespace Escorts\ServiceRequest\Model\ResourceModel\RequestType;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Escorts\ServiceRequest\Model\RequestType', 'Escorts\ServiceRequest\Model\ResourceModel\RequestType');
    }
}
