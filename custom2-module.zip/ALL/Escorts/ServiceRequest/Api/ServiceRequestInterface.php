<?php
namespace Escorts\ServiceRequest\Api;
 
interface ServiceRequestInterface
{
     /**
     * @param mixed $serviceRequest
     * @return void
     */
    public function createServiceRequest($serviceRequest);
    
    /**
     * @param int $sdid
     * @param int $statusId
     * @param int $curPage
     * @param int $pageSize
     * @return void
     */
    public function getServiceRequestList($statusId,$curPage,$pageSize);
    
    
    /**
     * @param int $srid
     * @return void
     */
    public function getServiceRequestCustomer($srid);
    
    /**
     * @param int $srid
     * @return void
     */
    public function getServiceRequestTractor($srid);
    
    /**
     * @param int $srid
     * @return void
     */
    public function getServiceRequestServiceDetail($srid);
    
    /**
     * @return void
     */
    public function getServiceRequestServiceType();
    
    /**
     * @return void
     */
    public function getServiceRequestServiceIssues();
    
    /**
     * @param mixed $serviceRequestPdi
     * @return void
     */
    public function createServiceRequestPdi($serviceRequestPdi);
    
    /**
     * @return void
     */
    public function getServiceRequestOptions();
    
    /**
     * @param int $serviceRequestType
     * @param int $srid
     * @return void
     */                
    public function getServiceRequestJobNo($serviceRequestType,$srid);
    
    /**
     * @param int $serviceRequestType
     * @param int $srid
     * @return void
     */ 
    public function getServiceRequestPdi($serviceRequestType,$srid);
    
    /**
     * @param mixed $serviceRequestInstallation
     * @return void
     */
    public function createServiceRequestInstallation($serviceRequestInstallation);
    
    /**
     * @param int $serviceRequestType
     * @param int $srid
     * @return void
     */ 
    public function getServiceRequestInstallation($serviceRequestType,$srid);
    
}
