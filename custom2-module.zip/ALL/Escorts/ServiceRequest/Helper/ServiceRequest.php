<?php
/**
 * Copyright © 2015 Escorts . All rights reserved.
 */
namespace Escorts\ServiceRequest\Helper;
class ServiceRequest extends \Magento\Framework\App\Helper\AbstractHelper
{

	const ATTRIBUTE_SET_ID = 13;
	/**
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     */
	protected $_orderFactory;
	/**
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     */
	protected $_productFactory;

	/**
     * @param \Magento\Framework\App\Helper\Context $context
     */
	public function __construct(
		\Magento\Framework\App\Helper\Context $context,
		\Magento\Sales\Model\OrderFactory $orderFactory,
		\Magento\Catalog\Model\ProductFactory $productFactory
	) 
	{
		$this->_orderFactory = $orderFactory;
		$this->_productFactory = $productFactory;
		parent::__construct($context);
	}

	public function getServiceProduct($customerId)
	{
		$orders = $this->_orderFactory->create()->getCollection();
		$orders->addAttributeToSelect("*")
			   ->addAttributeToFilter('customer_id',$customerId)->load();
			   $response = array();
		foreach ($orders as $order) {
			$items = $order->getAllItems();
			
			foreach ($items as $i) {
				$_product = $this->_productFactory->create()->load($i->getProductId());
				if ($_product->getAttributeSetId() == self::ATTRIBUTE_SET_ID) {
					/*echo "<pre>"; print_r($i->getProductId()); echo "</pre>";
					echo "<pre>"; print_r($i->getName()); echo "</pre>";
					
					echo "<pre>"; print_r($order->getCreatedAt()); echo "</pre>";*/
					/*echo "<pre>++"; print_r($order->getEntityId()); echo "</pre>";
					echo "<pre>**"; print_r($i->getProductId()); echo "</pre>";*/
					$response[] = array('order_id'=>$order->getEntityId(),'created_at'=>$order->getCreatedAt(),'delivery_date'=>'XX-YY-ZZZZ','item_id'=>$i->getProductId(),'item_name'=>$i->getName());
				}
			}
		}
		if ($response) {
			return $response;
		}else{
			return $response = 'false';
		}
	}
}