<?php

namespace Escorts\Tekinfo\Model;

use Escorts\Tekinfo\Api\CustomerDetailInterface;

class CustomerDetail implements CustomerDetailInterface {

    protected $_addressFactory;
    protected $_customerFactory;
    protected $_customerRepository;
    protected $_customerEnquiryFactory;
    protected $_helper;
    protected $_commonHelper;

    public function __construct(
        \Magento\Customer\Model\AddressFactory $addressFactory,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
        \Escorts\Tekinfo\Model\CustomerEnquiryFactory $customerEnquiryFactory,
        \Escorts\Tekinfo\Helper\Data $helper,
        \Escorts\Common\Helper\Data $commonHelper
    ) {
        $this->_addressFactory = $addressFactory;
        $this->_customerFactory = $customerFactory;
        $this->_customerRepository = $customerRepository;
        $this->_customerEnquiryFactory = $customerEnquiryFactory;
        $this->_helper = $helper;
        $this->_commonHelper = $commonHelper;
    }

    public function getCustomerDetailByEmail($emailid) {
        //$customerGroup = array('1', '2', '3');
        // Get object manager
        $object_manager = \Magento\Framework\App\ObjectManager::getInstance();

        $mage_url = \Magento\Framework\App\ObjectManager::getInstance();
        $storeManager = $mage_url->get('\Magento\Store\Model\StoreManagerInterface');

        // Get website id
        $website_id = $storeManager->getWebsite()->getWebsiteId();

        $customer_factory = $object_manager->get('\Magento\Customer\Model\CustomerFactory');
        $customer_data = $customer_factory->create();

        $customer_data->setWebsiteId($website_id);
        $customer_data->loadByEmail($emailid);
        $data = $customer_data->getData();

        if (!empty($data)) {
            //$group_id = $data['group_id'];
            $address_id = $customer_data->getDefaultShipping();

            //if (in_array($group_id, $customerGroup)){
            if (1) {
                $customerInfo = array(
                    'status' => 1,
                    'msg' => 'Customer detail found',
                    'customer_id' => $data['entity_id'],
                    'profile_type' => $data['group_id']
                );

                if (isset($data['mobile_number'])) {
                    $customerInfo['mobile_number'] = $data['mobile_number'];
                }

                if (isset($data['firstname'])) {
                    $customerInfo['name'] = $data['firstname'];
                    if (isset($data['lastname'])) {
                        $customerInfo['name'] .= ' ' . $data['lastname'];
                    }
                }

                if (isset($data['email'])) {
                    $customerInfo['email_id'] = $data['email'];
                }

                //get default billing address
                if (!empty($address_id)) {
                    try {
                        $shippingAddress = $this->_addressFactory->create()->load($address_id);
                        $data = $shippingAddress->getData();

                        if (!empty($data['street'])) {
                            $customerInfo['street'] = $data['street'];
                        }

                        if (!empty($data['village'])) {
                            $customerInfo['village'] = $data['village'];
                        }

                        if (!empty($data['tehsil'])) {
                            $customerInfo['tehsil'] = $data['tehsil'];
                        }

                        if (!empty($data['city'])) {
                            $customerInfo['district'] = $data['city'];
                        }

                        if (!empty($data['region'])) {
                            $customerInfo['state'] = $data['region'];
                        }

                        if (!empty($data['country_id'])) {
                            $customerInfo['country'] = $data['country_id'];
                        }

                        if (!empty($data['postcode'])) {
                            $customerInfo['post_code'] = $data['postcode'];
                        }
                    } catch (\Exception $e) {
                        //echo $e->getMessage();
                    }
                }
                $customerInfo['default_url'] = $this->_helper->getDefaultUrl();
                $customerInfo['sub_campaign'] = '';
            } else {
                $customerInfo = array('status' => 0, 'msg' => 'Customer details does not exists in system!');
            }
        } else {
            $collection = $this->_customerEnquiryFactory->create()
                    ->getCollection()
                    ->addFieldToSelect("*")
                    ->addFieldToFilter("email", array("eq" => $emailid))
                    ->setPageSize(1)
                    ->load();

            if (!empty($collection->getSize())) {
                $customer_data = $collection->getFirstItem();
                $customerInfo = array(
                    'status' => 1,
                    'msg' => 'Customer detail found',
                    'customer_id' => $customer_data->getEnquiryCustomerId(),
                    'profile_type' => 0,
                    'mobile_number' => $customer_data->getMobileNumber(),
                    'name' => $customer_data->getName(),
                    'email_id' => $customer_data->getEmail(),
                    'street' => $customer_data->getStreetName(),
                    'village' => $customer_data->getVillage(),
                    'tehsil' => $customer_data->getTehsil(),
                    'district' => $customer_data->getDistrict(),
                    'state' => $customer_data->getState(),
                    'country' => $customer_data->getCountry(),
                    'post_code' => $customer_data->getPostCode(),
                    'default_url' => $this->_helper->getDefaultUrl(),
                    'sub_campaign' => ''
                );
            } else {
                $customerInfo = array('status' => 0, 'msg' => 'Customer details does not exists in system!');
            }
        }

        return json_encode($customerInfo);
    }

    public function getCustomerDetailById($id) {
        //$customerGroup = array('1', '2', '3');
        // Get object manager
        $object_manager = \Magento\Framework\App\ObjectManager::getInstance();

        $mage_url = \Magento\Framework\App\ObjectManager::getInstance();
        $storeManager = $mage_url->get('\Magento\Store\Model\StoreManagerInterface');

        // Get website id
        $website_id = $storeManager->getWebsite()->getWebsiteId();

        $customer_factory = $object_manager->get('\Magento\Customer\Model\CustomerFactory');
        $customer_data = $customer_factory->create()->load($id);
        //$customer_data->setWebsiteId($website_id);

        $data = $customer_data->getData();

        if (!empty($data)) {
            //$group_id = $data['group_id'];
            $address_id = $customer_data->getDefaultShipping();

            //if (in_array($group_id, $customerGroup)){
            if (1) {
                $customerInfo = array(
                    'status' => 1,
                    'msg' => 'Customer detail found',
                    'customer_id' => $data['entity_id'],
                    'profile_type' => $data['group_id']
                );

                if (isset($data['mobile_number'])) {
                    $customerInfo['mobile_number'] = $data['mobile_number'];
                }

                if (isset($data['firstname'])) {
                    $customerInfo['name'] = $data['firstname'];
                    if (isset($data['lastname'])) {
                        $customerInfo['name'] .= ' ' . $data['lastname'];
                    }
                }

                if (isset($data['email'])) {
                    $customerInfo['email_id'] = $data['email'];
                }

                //get default billing address
                if (!empty($address_id)) {
                    try {
                        $shippingAddress = $this->_addressFactory->create()->load($address_id);
                        $data = $shippingAddress->getData();

                        if (!empty($data['street'])) {
                            $customerInfo['street'] = $data['street'];
                        }

                        if (!empty($data['village'])) {
                            $customerInfo['village'] = $data['village'];
                        }

                        if (!empty($data['tehsil'])) {
                            $customerInfo['tehsil'] = $data['tehsil'];
                        }

                        if (!empty($data['city'])) {
                            $customerInfo['district'] = $data['city'];
                        }

                        if (!empty($data['region'])) {
                            $customerInfo['state'] = $data['region'];
                        }

                        if (!empty($data['country_id'])) {
                            $customerInfo['country'] = $data['country_id'];
                        }

                        if (!empty($data['postcode'])) {
                            $customerInfo['post_code'] = $data['postcode'];
                        }
                    } catch (\Exception $e) {
                        //echo $e->getMessage();
                    }
                }
                $customerInfo['default_url'] = $this->_helper->getDefaultUrl();
                $customerInfo['sub_campaign'] = '';
            } else {
                $customerInfo = array('status' => 0, 'msg' => 'Customer details does not exists in system!');
            }
        } else {
            if (!empty($profiletype) && $profiletype == 0) {
                $collection = $this->_customerEnquiryFactory->create()
                        ->getCollection()
                        ->addFieldToSelect("*")
                        ->addFieldToFilter("enquiry_customer_id", array("eq" => $id))
                        ->setPageSize(1)
                        ->load();

                if (!empty($collection->getSize())) {
                    $customer_data = $collection->getFirstItem();
                    $customerInfo = array(
                        'status' => 1,
                        'msg' => 'Customer detail found',
                        'customer_id' => $customer_data->getEnquiryCustomerId(),
                        'profile_type' => 0,
                        'mobile_number' => $customer_data->getMobileNumber(),
                        'name' => $customer_data->getName(),
                        'email_id' => $customer_data->getEmail(),
                        'street' => $customer_data->getStreetName(),
                        'village' => $customer_data->getVillage(),
                        'tehsil' => $customer_data->getTehsil(),
                        'district' => $customer_data->getDistrict(),
                        'state' => $customer_data->getState(),
                        'country' => $customer_data->getCountry(),
                        'post_code' => $customer_data->getPostCode(),
                        'default_url' => $this->_helper->getDefaultUrl(),
                        'sub_campaign' => ''
                    );
                }
            } else {
                $customerInfo = array('status' => 0, 'msg' => 'Customer details does not exists in system!');
            }
        }

        return json_encode($customerInfo);
    }

    public function getCustomerDetailByMobile($mobile) {
        //$customerGroup = array('1', '2', '3');
        $collection = $this->_customerFactory->create()
                ->getCollection()
                ->addAttributeToSelect("*")
                ->addAttributeToFilter("mobile_number", array("eq" => $mobile))
                ->setPageSize(1)
                ->load();

        if (!empty($collection->getSize())) {
            $customer_data = $collection->getFirstItem();
            //foreach($collection as $item){
            //	$customer_data = $item;
            //}
        }

        if (!empty($customer_data)) {
            $data = $customer_data->getData();
            //$group_id = $data['group_id'];
            $address_id = $customer_data->getDefaultShipping();

            //if (in_array($group_id, $customerGroup)){
            if (1) {
                $customerInfo = array(
                    'status' => 1,
                    'msg' => 'Customer detail found',
                    'customer_id' => $data['entity_id'],
                    'profile_type' => $data['group_id']
                );

                if (isset($data['mobile_number'])) {
                    $customerInfo['mobile_number'] = $data['mobile_number'];
                }

                if (isset($data['firstname'])) {
                    $customerInfo['name'] = $data['firstname'];
                    if (isset($data['lastname'])) {
                        $customerInfo['name'] .= ' ' . $data['lastname'];
                    }
                }

                if (isset($data['email'])) {
                    $customerInfo['email_id'] = $data['email'];
                }

                //get default billing address
                if (!empty($address_id)) {
                    try {
                        $shippingAddress = $this->_addressFactory->create()->load($address_id);
                        $data = $shippingAddress->getData();

                        if (!empty($data['street'])) {
                            $customerInfo['street'] = $data['street'];
                        }

                        if (!empty($data['village'])) {
                            $customerInfo['village'] = $data['village'];
                        }

                        if (!empty($data['tehsil'])) {
                            $customerInfo['tehsil'] = $data['tehsil'];
                        }

                        if (!empty($data['city'])) {
                            $customerInfo['district'] = $data['city'];
                        }

                        if (!empty($data['region'])) {
                            $customerInfo['state'] = $data['region'];
                        }

                        if (!empty($data['country_id'])) {
                            $customerInfo['country'] = $data['country_id'];
                        }

                        if (!empty($data['postcode'])) {
                            $customerInfo['post_code'] = $data['postcode'];
                        }
                    } catch (\Exception $e) {
                        //echo $e->getMessage();
                    }
                }
                $customerInfo['default_url'] = $this->_helper->getDefaultUrl();
                $customerInfo['sub_campaign'] = '';
            } else {
                $customerInfo = array('status' => 0, 'msg' => 'Customer details does not exists in system!');
            }
        } else {
            $collection = $this->_customerEnquiryFactory->create()
                    ->getCollection()
                    ->addFieldToSelect("*")
                    ->addFieldToFilter("mobile_number", array("eq" => $mobile))
                    ->setPageSize(1)
                    ->load();

            if (!empty($collection->getSize())) {
                $customer_data = $collection->getFirstItem();
                $customerInfo = array(
                    'status' => 1,
                    'msg' => 'Customer detail found',
                    'customer_id' => $customer_data->getEnquiryCustomerId(),
                    'profile_type' => 0,
                    'mobile_number' => $customer_data->getMobileNumber(),
                    'name' => $customer_data->getName(),
                    'email_id' => $customer_data->getEmail(),
                    'street' => $customer_data->getStreetName(),
                    'village' => $customer_data->getVillage(),
                    'tehsil' => $customer_data->getTehsil(),
                    'district' => $customer_data->getDistrict(),
                    'state' => $customer_data->getState(),
                    'country' => $customer_data->getCountry(),
                    'post_code' => $customer_data->getPostCode(),
                    'default_url' => $this->_helper->getDefaultUrl(),
                    'sub_campaign' => ''
                );
            } else {
                $customerInfo = array('status' => 0, 'msg' => 'Customer details does not exists in system!');
            }
        }

        return json_encode($customerInfo);
    }

    public function getCustomerByMobile($mobile = null) {
        if ($mobile) {
            $collection = $this->_customerFactory->create()
                    ->getCollection()
                    ->addAttributeToSelect('id')
                    ->addAttributeToFilter('mobile_number', ['eq' => $mobile])
                    ->setPageSize(1)
                    ->load();

            if (!empty($collection->getSize())) {
                $customer_data = $collection->getFirstItem();
            }

            if (!empty($customer_data)) {
                //$data = $customer_data->getData();
                //$group_id = $data['group_id'];
                //return array('customer_id' => $customer_data->getId(), 'group_id' => $customer_data->getGroupId(), 'enquiry_customer_id' => 0);
                return array('customer_id' => $customer_data->getId(), 'enquiry_customer_id' => 0);
            } else {
                $collection = $this->_customerEnquiryFactory->create()
                        ->getCollection()
                        ->addFieldToSelect("enquiry_customer_id")
                        ->addFieldToFilter("mobile_number", array("eq" => $mobile))
                        ->setPageSize(1)
                        ->load();

                if (!empty($collection->getSize())) {
                    $customer_data = $collection->getFirstItem();
                    return array('customer_id' => 0, 'enquiry_customer_id' => $customer_data->getEnquiryCustomerId());
                }
            }
        }

        return false;
    }

    public function updateCustomerDetail($customerDetails) {
        //print_r($customerDetails);die;
        $response = array(
            'status' => 0,
            'msg' => 'Please provide all required fields'
        );

        if (!empty($customerDetails['mobile_number'])) {
            if ($customer_ids = $this->getCustomerByMobile($customerDetails['mobile_number'])) {
                if ($customer_ids['customer_id']) {
                    $customer = $this->_customerRepository->getById($customer_ids['customer_id']);
                    
                    if ($customer) {
                         if (!empty($customerDetails['name'])) {
                            $nameArr = explode(' ', $customerDetails['name']);

                            if (!empty($nameArr[0])) {
                                $customer->setFirstname($nameArr[0]);
                            }

                            if (!empty($nameArr[1])) {
                                $customer->setLastname($nameArr[1]);
                            }
                        }

                        if (!empty($customerDetails['email_id'])) {
                            $customer->setEmail($customerDetails['email_id']);
                        }
                        
                        //$customer->setMobileNumber($customerDetails['mobile_number']);
                        //$customer->save();
                        $customer = $this->_customerRepository->save($customer);

                        $address_id = $customer->getDefaultShipping();
                        //var_dump($address_id);die;
                        if (!empty($address_id)) {
                            $shippingAddress = $this->_addressFactory->create()->load($address_id);

                            if (!empty($customerDetails['street'])) {
                                $shippingAddress->setStreet($customerDetails['street']);
                            }

                            if (!empty($customerDetails['village'])) {
                                $shippingAddress->setVillage($customerDetails['village']);
                            }

                            if (!empty($customerDetails['tehsil'])) {
                                $shippingAddress->setTehsil($customerDetails['tehsil']);
                            }

                            if (!empty($customerDetails['district'])) {
                                $shippingAddress->setCity($customerDetails['district']);
                            }

                            if (!empty($customerDetails['state'])) {
                                $shippingAddress->setRegionId($this->_commonHelper->getRegionIdByName($customerDetails['state']));
                            }

                            if (!empty($customerDetails['post_code'])) {
                                $shippingAddress->setPostcode($customerDetails['post_code']);
                            }
                            
                            if (!empty($customerDetails['mobile_number'])) {
                                $shippingAddress->setTelephone($customerDetails['mobile_number']);
                            }

                            $shippingAddress->save();
                        } else {
                            //echo $customer->getId();die;
                            //create a defaut shipping and billing address
                            $address = $this->_addressFactory->create();
                            $address->setCustomerId($customer->getId())
                                    ->setIsDefaultBilling('1')
                                    ->setIsDefaultShipping('1')
                                    ->setSaveInAddressBook('1')
                                    //->setCompany('n/a')
                                    //->setFax('n/a')
                                    ->setFirstname($customer->getFirstname())
                                    ->setLastname($customer->getLastname())
                                    ->setStreet([$customerDetails['street']])
                                    ->setVillage($customerDetails['village'])
                                    ->setTehsil($customerDetails['tehsil'])
                                    ->setCity($customerDetails['district'])
                                    ->setRegionId($this->_commonHelper->getRegionIdByName($customerDetails['state']))
                                    ->setCountryId('IN')
                                    ->setPostcode($customerDetails['post_code'])
                                    ->setTelephone($customerDetails['mobile_number']);

                            //$this->_addressFactory->save($address);
                            $address->save();
                        }

                        $response = array(
                            'status' => 1,
                            'customer_id' => $customer->getId(),
                            'msg' => 'Updated successfully'
                        );
                    }
                    
                    /*$collection = $this->_customerFactory->create()
                            ->getCollection()
                            ->addAttributeToSelect("id")
                            ->addAttributeToFilter("mobile_number", array("eq" => $customerDetails['mobile_number']))
                            ->setPageSize(1)
                            ->load();

                    if (!empty($collection->getSize())) {
                        $customer_data = $collection->getFirstItem();
                        $customer_data->getId();
                        die;
                    }*/

                    /*if (!empty($customer_data)) {

                        if (!empty($customerDetails['name'])) {
                            $nameArr = explode(' ', $customerDetails['name']);

                            if (!empty($nameArr[0])) {
                                $customer_data->setFirstname($nameArr[0]);
                            }

                            if (!empty($nameArr[1])) {
                                $customer_data->setLastname($nameArr[1]);
                            }
                        }

                        if (!empty($customerDetails['email_id'])) {
                            $customer_data->setEmail($customerDetails['email_id']);
                        }

                        $address_id = $customer_data->getDefaultShipping();
                        if (!empty($address_id)) {
                            $shippingAddress = $this->_addressFactory->load($address_id);

                            if (!empty($customerDetails['street'])) {
                                $shippingAddress->setStreet($customerDetails['street']);
                            }

                            if (!empty($customerDetails['village'])) {
                                $shippingAddress->setVillage($customerDetails['village']);
                            }

                            if (!empty($customerDetails['tehsil'])) {
                                $shippingAddress->setTehsil($customerDetails['tehsil']);
                            }

                            if (!empty($customerDetails['district'])) {
                                $shippingAddress->setCity($customerDetails['district']);
                            }

                            if (!empty($customerDetails['state'])) {
                                $shippingAddress->setRegion($customerDetails['state']);
                            }

                            if (!empty($customerDetails['post_code'])) {
                                $shippingAddress->setPostcode($customerDetails['post_code']);
                            }

                            $shippingAddress->save();
                        } else {
                            //create a defaut shipping and billing address
                            $address = $this->addressFactory->create()
                                    ->setCustomerId($this->customerObject->getId())
                                    ->setIsDefaultBilling($isDefaultBilling)
                                    ->setIsDefaultShipping($isDefaultShipping)
                                    ->setCity('n/a')
                                    ->setCountryId('UA')
                                    ->setCompany('n/a')
                                    ->setFax('n/a')
                                    ->setFirstname($this->customerObject->getFirstname())
                                    ->setLastname($this->customerObject->getLastname())
                                    ->setPostcode('n/a')
                                    ->setStreet(['n/a'])
                                    ->setTelephone('n/a');

                            $this->addressRepository->save($address);
                        }

                        $customer_data->setMobileNumber($customerDetails['mobile_number']);
                        $customer_data->save();

                        $response = array(
                            'status' => 1,
                            'customer_id' => $customer_data->getId(),
                            'msg' => 'Updated successfully'
                        );
                    }*/
                } elseif ($customer_ids['enquiry_customer_id']) {
                    $collection = $this->_customerEnquiryFactory->create()
                            ->getCollection()
                            ->addFieldToSelect("enquiry_customer_id")
                            ->addFieldToFilter("mobile_number", array("eq" => $customerDetails['mobile_number']))
                            ->setPageSize(1)
                            ->load();

                    if (!empty($collection->getSize())) {
                        $customer_data = $collection->getFirstItem();

                        if (!empty($customerDetails['name'])) {
                            $customer_data->setName($customerDetails['name']);
                        }

                        if (!empty($customerDetails['alt_mobile_number'])) {
                            $customer_data->setAltMobileNumber($customerDetails['alt_mobile_number']);
                        }

                        if (!empty($customerDetails['email_id'])) {
                            $customer_data->setEmail($customerDetails['email_id']);
                        }

                        if (!empty($customerDetails['street'])) {
                            $customer_data->setStreetName($customerDetails['street']);
                        }

                        if (!empty($customerDetails['village'])) {
                            $customer_data->setVillage($customerDetails['village']);
                        }

                        if (!empty($customerDetails['tehsil'])) {
                            $customer_data->setTehsil($customerDetails['tehsil']);
                        }

                        if (!empty($customerDetails['district'])) {
                            $customer_data->setDistrict($customerDetails['district']);
                        }

                        if (!empty($customerDetails['state'])) {
                            $customer_data->setState($customerDetails['state']);
                        }

                        if (!empty($customerDetails['country'])) {
                            $customer_data->setCountry($customerDetails['country']);
                        }

                        if (!empty($customerDetails['post_code'])) {
                            $customer_data->setPostCode($customerDetails['post_code']);
                        }
                        $customer_data->save();

                        $response = array(
                            'status' => 1,
                            'customer_id' => $customer_data->getId(),
                            'msg' => 'Updated successfully'
                        );
                    }
                }
            } else {
                $enquiryCustomer = $this->_customerEnquiryFactory->create();
                if (!empty($customerDetails['mobile_number'])) {
                    $enquiryCustomer->setMobileNumber($customerDetails['mobile_number']);
                }

                if (!empty($customerDetails['name'])) {
                    $enquiryCustomer->setName($customerDetails['name']);
                }

                if (!empty($customerDetails['alt_mobile_number'])) {
                    $enquiryCustomer->setAltMobileNumber($customerDetails['alt_mobile_number']);
                }

                if (!empty($customerDetails['email_id'])) {
                    $enquiryCustomer->setEmail($customerDetails['email_id']);
                }

                if (!empty($customerDetails['street'])) {
                    $enquiryCustomer->setStreetName($customerDetails['street']);
                }

                if (!empty($customerDetails['village'])) {
                    $enquiryCustomer->setVillage($customerDetails['village']);
                }

                if (!empty($customerDetails['tehsil'])) {
                    $enquiryCustomer->setTehsil($customerDetails['tehsil']);
                }

                if (!empty($customerDetails['district'])) {
                    $enquiryCustomer->setDistrict($customerDetails['district']);
                }

                if (!empty($customerDetails['state'])) {
                    $enquiryCustomer->setState($customerDetails['state']);
                }

                if (!empty($customerDetails['country'])) {
                    $enquiryCustomer->setCountry($customerDetails['country']);
                }

                if (!empty($customerDetails['post_code'])) {
                    $enquiryCustomer->setPostCode($customerDetails['post_code']);
                }
                $enquiryCustomer->save();

                $response = array(
                    'status' => 2,
                    'customer_id' => $enquiryCustomer->getId(),
                    'msg' => 'New customer added successfully'
                );
            }
        }

        return json_encode($response);
    }

}
