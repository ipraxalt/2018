<?php
/**
 * Copyright © 2015 Escorts. All rights reserved.
 */
namespace Escorts\Tekinfo\Model\ResourceModel;

/**
 * CustomerEnquiry resource
 */
class CustomerEnquiry extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('escorts_enquiry_customer', 'enquiry_customer_id');
    }

  
}
