<?php
/**
 * Copyright © 2015 Escorts. All rights reserved.
 */
namespace Escorts\Tekinfo\Model\ResourceModel;

/**
 * TekinfoKyc resource
 */
class TekinfoKyc extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('escorts_tekinfo_kyc', 'kyc_id');
    }

  
}
