<?php
/**
 * Copyright © 2015 Escorts. All rights reserved.
 */
namespace Escorts\Tekinfo\Model\ResourceModel;

/**
 * TekinfoInsurance resource
 */
class TekinfoInsurance extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('escorts_tekinfo_insurance', 'insurance_id');
    }
}