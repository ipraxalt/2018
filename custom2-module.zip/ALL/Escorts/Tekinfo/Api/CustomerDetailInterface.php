<?php
namespace Escorts\Tekinfo\Api;
 
interface CustomerDetailInterface
{
    /**
     * Returns customer detail
     *
     * @api
     * @param string $emailid Email ID.
     * @return string with customer detail
     */
    public function getCustomerDetailByEmail($emailid);
	
	/**
     * Returns customer detail
     *
     * @api
     * @param int $id ID.
	 * @param int $profiletype profiletype.
     * @return string with customer detail.
     */
    public function getCustomerDetailById($id);
	
	/**
     * Returns customer detail
     *
     * @api
     * @param int $mobile ID.
     * @return string with customer detail.
     */
    public function getCustomerDetailByMobile($mobile);
	
	/**
     * Returns customer detail status
     *
     * @api
	 * @param mixed $customerDetails
     * @return string.
     */
    public function updateCustomerDetail($customerDetails);
}
