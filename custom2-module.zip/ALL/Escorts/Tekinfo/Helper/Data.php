<?php
namespace Escorts\Tekinfo\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	/**
     * Path to store config if extension is enabled
     *
     * @var string
     */
    const XML_DEFAULT_URL = 'escorts/tekinfo/default_url';
	
	/**
     * @var \Magento\Customer\Model\CustomerFactory
     */
	protected $_insuranceOptionModel;
	
	/**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     */
	public function __construct(
		\Magento\Framework\App\Helper\Context $context,
		\Escorts\Tekinfo\Model\InsuranceOptionFactory $insuranceOptionModel
	) {		
		$this->_insuranceOptionModel = $insuranceOptionModel;
		parent::__construct($context);
	}
	
	/**
     * Retun Default URL
     *
     * @return String
     */
	public function getDefaultUrl() {
		return $this->scopeConfig->getValue(
			self::XML_DEFAULT_URL,
			\Magento\Store\Model\ScopeInterface::SCOPE_STORE
		);
    }
	
	/**
     * Retun Insurance Options
     *
     * @return Array
     */
	public function getInsuranceOption() {
		$insuranceOption = array();
		
		$optionCollection = $this->_insuranceOptionModel->create()->getCollection();
		
		if ($optionCollection->getSize()) {
			foreach($optionCollection as $item) {
				$insuranceOption[$item->getId()] = $item->getOptionName();
			}
		}
		
		return $insuranceOption;
	}
	
}