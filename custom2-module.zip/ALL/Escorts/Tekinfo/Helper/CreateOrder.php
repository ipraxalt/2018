<?php

/**
 * Copyright © 2015 Escorts . All rights reserved.
 */

namespace Escorts\Tekinfo\Helper;

use \Psr\Log\LoggerInterface;

class CreateOrder extends \Magento\Framework\App\Helper\AbstractHelper {

    const ATTRIBUTE_SET_ID = '13';
    const QUOTE_STATUS = '1';

    /**
     * \Psr\Log\LoggerInterface
     */
    protected $_logger;

    /**
     * \Escorts\Tekinfo\Model\TekinfoQuoteFactory $tekInfoQuote
     */
    protected $_tekInfoQuote;

    /**
     * \Escorts\Tekinfo\Model\CustomerEnquiryFactory $enquiryCustomerFactory
     */
    protected $_enquiryCustomerFactory;

    /**
     * \Escorts\Tekinfo\Model\TekinfoExchangeFactory $tekinfoExchangeFactory
     */
    protected $_tekinfoExchangeFactory;

    /**
     * \Escorts\TractorExchange\Model\ExchangeFactory $tractorExchangeFactory
     */
    protected $_tractorExchangeFactory;

    /**
     * \Magento\Catalog\Model\ProductFactory $productFactory
     */
    protected $_productFactory;

    /**
     * \Escorts\Tekinfo\Model\TekinfoLoanapplicationFactory $tekinfoLoanapplicationFactory
     */
    protected $_tekinfoLoanapplicationFactory;

    /**
     * \Escorts\TractorLoan\Model\LoanApplicationFactory $loanApplicationFactory
     */
    protected $_loanApplicationFactory;

    /**
     * \Escorts\Tekinfo\Model\TekinfoKycFactory $tekinfoKycFactory
     */
    protected $_tekinfoKycFactory;

    /**
     * \Escorts\Kyc\Model\KycFactory $kycFactory
     */
    protected $_kycFactory;

    /**
     * \Escorts\VehicleInsurance\Model\VehicleInsuranceFactory $vehicleInsuranceFactory
     */
    protected $_vehicleInsuranceFactory;

    /**
     * \Escorts\Tekinfo\Model\TekinfoInsuranceFactory $tekinfoInsuranceFactory
     */
    protected $_tekinfoInsuranceFactory;

    /**
     * \Escorts\Common\Helper\Data $commonHelper
     */
    protected $_commonHelper;

    /**
     * \Escorts\SmsNotification\Helper\Data $smsHelper
     */
    protected $_smsHelper;

    /**
     * \Magento\Framework\App\Filesystem\DirectoryList $directory_list
     */
    protected $_directory_list;
            
    /**
     * \Magento\Framework\App\State $state
     */
    protected $_state;

    /**
     * \Escorts\Tekinfo\Model\CustomerDetail $_tekinfoCustomerDetailModel
     */
    protected $_tekinfoCustomerDetailModel;

    /**
     * @param Magento\Framework\App\Helper\Context $context
     * @param Magento\Store\Model\StoreManagerInterface $storeManager
     * @param Psr\Log\LoggerInterface $logger
     * @param Magento\Catalog\Model\Product $product,
     * @param Magento\Quote\Api\CartRepositoryInterface $cartRepositoryInterface,
     * @param Magento\Quote\Api\CartManagementInterface $cartManagementInterface,
     * @param Magento\Customer\Model\CustomerFactory $customerFactory,
     * @param Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
     * @param Magento\Sales\Model\Order $order,
     * @param Escorts\Tekinfo\Model\TekinfoQuoteFactory $tekInfoQuote,
     * @param Escorts\Tekinfo\Model\CustomerEnquiryFactory $enquiryCustomerFactory,
     * @param Escorts\Tekinfo\Model\TekinfoExchangeFactory $tekinfoExchangeFactory,
     * @param Escorts\TractorExchange\Model\ExchangeFactory $tractorExchangeFactory,
     * @param Escorts\TractorLoan\Model\LoanApplicationFactory $loanApplicationFactory,
     * @param Escorts\Tekinfo\Model\TekinfoLoanapplicationFactory $tekinfoLoanapplicationFactory,
     * @param Escorts\Tekinfo\Model\TekinfoKycFactory $tekinfoKycFactory,
     * @param Escorts\Kyc\Model\KycFactory $kycFactory,
     * @param Escorts\VehicleInsurance\Model\VehicleInsuranceFactory $vehicleInsuranceFactory,
     * @param Escorts\Tekinfo\Model\TekinfoInsuranceFactory $tekinfoInsuranceFactory,
     * @param Escorts\Common\Helper\Data $commonHelper,
     * @param Escorts\SmsNotification\Helper\Data $smsHelper,
     * @param Magento\Framework\App\Filesystem\DirectoryList $directory_list,
     * @param \Escorts\Tekinfo\Model\CustomerDetail $_tekinfoCustomerDetailModel
     */
    public function __construct(
    \Magento\Framework\App\Helper\Context $context, \Magento\Store\Model\StoreManagerInterface $storeManager, \Psr\Log\LoggerInterface $logger, \Magento\Catalog\Model\Product $product, \Magento\Quote\Api\CartRepositoryInterface $cartRepositoryInterface, \Magento\Quote\Api\CartManagementInterface $cartManagementInterface, \Magento\Customer\Model\CustomerFactory $customerFactory, \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository, \Magento\Sales\Model\Order $order, \Escorts\Tekinfo\Model\TekinfoQuoteFactory $tekInfoQuote, \Escorts\Tekinfo\Model\CustomerEnquiryFactory $enquiryCustomerFactory, \Escorts\Tekinfo\Model\TekinfoExchangeFactory $tekinfoExchangeFactory, \Escorts\TractorExchange\Model\ExchangeFactory $tractorExchangeFactory, \Magento\Catalog\Model\ProductFactory $productFactory, \Escorts\TractorLoan\Model\LoanApplicationFactory $loanApplicationFactory, \Escorts\Tekinfo\Model\TekinfoLoanapplicationFactory $tekinfoLoanapplicationFactory, \Escorts\Tekinfo\Model\TekinfoKycFactory $tekinfoKycFactory, \Escorts\Kyc\Model\KycFactory $kycFactory, \Escorts\VehicleInsurance\Model\VehicleInsuranceFactory $vehicleInsuranceFactory, \Escorts\Tekinfo\Model\TekinfoInsuranceFactory $tekinfoInsuranceFactory, \Escorts\Common\Helper\Data $commonHelper, \Escorts\SmsNotification\Helper\Data $smsHelper, \Magento\Framework\App\Filesystem\DirectoryList $directory_list, \Magento\Framework\App\State $state, \Escorts\Tekinfo\Model\CustomerDetail $_tekinfoCustomerDetailModel
    ) {
        $this->_storeManager = $storeManager;
        $this->_logger = $logger;
        $this->_product = $product;
        $this->cartRepositoryInterface = $cartRepositoryInterface;
        $this->cartManagementInterface = $cartManagementInterface;
        $this->customerFactory = $customerFactory;
        $this->customerRepository = $customerRepository;
        $this->order = $order;
        $this->_tekInfoQuote = $tekInfoQuote;
        $this->_enquiryCustomerFactory = $enquiryCustomerFactory;
        $this->_tekinfoExchangeFactory = $tekinfoExchangeFactory;
        $this->_productFactory = $productFactory;
        $this->_tractorExchangeFactory = $tractorExchangeFactory;
        $this->_loanApplicationFactory = $loanApplicationFactory;
        $this->_tekinfoLoanapplicationFactory = $tekinfoLoanapplicationFactory;
        $this->_tekinfoKycFactory = $tekinfoKycFactory;
        $this->_kycFactory = $kycFactory;
        $this->_vehicleInsuranceFactory = $vehicleInsuranceFactory;
        $this->_tekinfoInsuranceFactory = $tekinfoInsuranceFactory;
        $this->_commonHelper = $commonHelper;
        $this->_smsHelper = $smsHelper;
        $this->_directory_list = $directory_list;
        $this->_state = $state;
        $this->_tekinfoCustomerDetailModel = $_tekinfoCustomerDetailModel;
        parent::__construct($context);
    }

    /**
     * Create Order On Your Store
     * 
     * @param array $orderData
     * @return array
     * 
     */
    public function tekInfoOrder($quote_id) {
        $message = '';

        $_isQuote = $this->checkQuote($quote_id);
        if ($_isQuote) {
            $quoteData = $this->getQuote($quote_id);
            // echo "<pre>********"; print_r($quoteData->getData()); echo "</pre>";
            if ($quoteData->getProductIds() == 0) {
                return ['status' => 0, 'message' => 'No product selected.'];
            } else {
                $itemArray[] = ['product_id' => $quoteData->getProductIds(), 'qty' => $quoteData->getQty()];
                $currency_code = $this->_commonHelper->getStoreCurrencyCode();

                if ($quoteData->getCustomerId() == 0) {
                    $customer = $this->getEnquiryCustomerData($quoteData->getEnquiryCustomerId());
                    if ($customer['status'] == 0) {
                        return $customer;
                    } else {
                        $customerEnqData = $customer['message'];
                        $tempOrder = [
                            'currency_id' => $currency_code,
                            'email' => $customerEnqData['email'],
                            'mobile_number' => $customerEnqData['mobile_number'],
                            'shipping_address' => [
                                'firstname' => $customerEnqData['name'],
                                'lastname' => $customerEnqData['name'],
                                'street' => $customerEnqData['street_name'],
                                'country_id' => $customerEnqData['country'],
                                /* 'region' => 'xxx', */
                                'region_id' => '1678',
                                'postcode' => $customerEnqData['post_code'],
                                'telephone' => $customerEnqData['mobile_number'],
                                'village' => $customerEnqData['village'],
                                'tehsil' => $customerEnqData['tehsil'],
                                'city' => $customerEnqData['district'],
                                /* 'fax' => '32423', */
                                'save_in_address_book' => 1
                            ],
                            'items' => $itemArray
                        ];
                    }
                } elseif ($quoteData->getEnquiryCustomerId() == 0) {
                    $customerId = $quoteData->getCustomerId();
                    $customerModel = $this->customerFactory->create()->load($customerId);

                    /*                     * **************************Check**************************************** */
                    $customerAddress = array();
                    foreach ($customerModel->getAddresses() as $address) {
                        $customerAddress[] = $address->toArray();
                        break;
                    }

                    /*                     * ***************************************************************** */
                    foreach ($customerAddress as $customerAddres) {

                        $tempOrder = [
                            'currency_id' => $currency_code,
                            'email' => $customerModel->getEmail(),
                            'mobile_number' => $customerModel->getMobileNumber(),
                            'shipping_address' => [
                                'firstname' => $customerModel->getFirstname(),
                                'lastname' => $customerModel->getLastname(),
                                'street' => $customerAddres['street'],
                                'country_id' => $customerAddres['country_id'],
                                'region' => $customerAddres['region'],
                                'region_id' => $customerAddres['region_id'],
                                'postcode' => $customerAddres['postcode'],
                                'telephone' => $customerAddres['telephone'],
                                'village' => $customerAddres['village'],
                                'tehsil' => $customerAddres['tehsil'],
                                'city' => $customerAddres['city'],
                                'fax' => $customerAddres['fax'],
                                'save_in_address_book' => 1
                            ],
                            'items' => $itemArray
                        ];
                    }
                }

                // echo "<pre>!!!"; print_r($tempOrder); echo "</pre>";
                $order = $this->createMageOrder($tempOrder, $quote_id);
                //echo "===================>";
                //exit();
                if ($order['status'] == 0) {
                    return $order;
                } else {
                    /****************************Check when order item multiples**************************************** */
                    $orderId = $order['order_id'];
                    $orderIncrimentId = $order['increment_id'];
                    $customerId = $order['customer_id'];
                    $productName = $order['product_name'];

                    /* sms Notification */
                    try {
                        $mobileNumber = $this->_commonHelper->getCustomerMobileByID($customerId);
                        $this->_smsHelper->sendSms($mobileNumber, 'Your Order ' . $orderIncrimentId . ' of item ' . $productName . ' has been placed successfully.');
                        $message .= "SMS sent to customer at $mobileNumber . ";
						
                        /*************Create service request for PDI*******Temporary********/
                        $this->_commonHelper->createPdiServieRequest($customerId, $orderId, $orderIncrimentId);
                    } catch (\Exception $e) {
                        $this->_logger->debug($e->getMessage());
                        $message .= 'Notifications send Error. '. $e->getMessage() .'. ';
                    }

                    /* Update Exchange Details */
                    $_isExchange = $this->isExchange($quote_id);
                    if ($_isExchange == 1) {
                        $updateExchange = $this->updateExchange($quote_id, $orderId);

                        if ($updateExchange) {
                            $message .= 'Exchange created successfully. ';
                        } else {
                            $message .= 'Exchange not created. ';
                        }
                    }

                    /* Update loan details */
                    $loan = $this->isLoan($quote_id);
                    if ($loan == 1) {
                        $updateLoan = $this->updateLoan($quote_id, $orderId);

                        if ($updateLoan) {
                            $message .= 'Loan application created successfully. ';
                        } else {
                            $message .= 'Loan application not created. ';
                        }
                    }

                    /* Update KYC Details */
                    $kyc = $this->updateKyc($quote_id, $orderId);

                    if ($kyc) {
                        $message .= 'KYC created successfully. ';
                    } else {
                        $message .= 'KYC not created. ';
                    }

                    /* Update Tractor Insurance */
                    $insurance = $this->updateInsurance($quote_id, $orderId);
                    if ($insurance) {
                        $message .= 'Insurance created successfully. ';
                    } else {
                        $message .= 'Insurance not created. ';
                    }

                    /* Update Quote Status */
                    $quoteUpdate = $this->updateQuote($quote_id);

                    $message .= $order['message'];
                    return ['status' => 1, 'message' => $message];
                }
            }
        } else {
            return ['status' => 0, 'message' => 'Quote does not exists'];
        }
    }

    public function checkQuote($quote_id) {
        try {
            $quotecheck = $this->_tekInfoQuote->create()->getCollection();
            $quotecheck->addFieldToFilter('status', array('eq' => self::QUOTE_STATUS))
                    ->addFieldToFilter('quote_id', array('eq' => $quote_id));
            if ($quotecheck->getSize() == 1) {
                return true;
            } else {
                return false;
            }
            return $quotecheck;
        } catch (\Exception $e) {
            $this->_logger->debug($e->getMessage());
            return false;
        }
    }

    public function createMageOrder($orderData, $tek_quote_id) {
        //echo '<pre>';print_r($orderData);echo '</pre>';die;
        try {
            //$this->_state->setAreaCode(\Magento\Framework\App\Area::AREA_FRONTEND);
            $res = $this->_tekinfoCustomerDetailModel->getCustomerByMobile(trim($orderData['mobile_number']));
            // echo "<pre>"; print_r($res); echo "</pre>"; exit();
            $store = $this->_storeManager->getStore();
            $websiteId = $this->_storeManager->getStore()->getWebsiteId();
            $customer = $this->customerFactory->create();
            $customer->setWebsiteId($websiteId);
            // $customer->loadByEmail($orderData['email']);// load customet by email address
            
            $customer_id = $res['customer_id'];
            
            if ($customer_id == 0) {
                //If not avilable then create this customer 
                try {
                    $mediaPath = $this->_directory_list->getPath('media');
                    $path = $mediaPath . '/customer/enquiry-customer-' . $res['enquiry_customer_id'];
                    
                    if (!is_dir($path)) {
                        return ['status' => 0, 'message' => 'Documents directory of customer does not exists.'];
                    }
                    
                    $customer->setWebsiteId($websiteId)
                            ->setStore($store)
                            ->setFirstname($orderData['shipping_address']['firstname'])
                            ->setLastname($orderData['shipping_address']['lastname'])
                            ->setEmail($orderData['email'])
                            ->setPassword($orderData['email'])
                            ->setMobileNumber($orderData['mobile_number']);
                    $customer->save();
                    $customer_id = $customer->getEntityId();

                    /* Rename Directory for enquiry customer */
                    try {
                        $path1 = $mediaPath . '/customer/customer-' . $customer_id;
                        if (is_dir($path)) {
                            if (!rename($path, $path1)) {
                                return ['status' => 0, 'message' => 'customer created but directory not renamed.'];
                            }/* else{
                              return array('status' => 1, 'message' => 'customer created & directory renamed.');
                              } */
                        } else {
                            return ['status' => 0, 'message' => 'Documents directory of customer does not exists.'];
                        }
                    } catch (\Exception $e) {
                        $this->_logger->debug($e->getMessage());
                        return ['status' => 0, 'message' => 'Something went wrong. Please try again later. <span class="text-danger">' . $e->getMessage().'</span>'];
                    }
                } catch (\Exception $e) {
                    $this->_logger->debug($e->getMessage());
                    return ['status' => 0, 'message' => 'Something went wrong. Please try again later. <span class="text-danger">' . $e->getMessage().'</span>'];
                }
            }

            //exit();
            $cartId = $this->cartManagementInterface->createEmptyCart(); //Create empty cart
            $quote = $this->cartRepositoryInterface->get($cartId); // load empty cart quote
            $quote->setStore($store);
            
            // if you have allready buyer id then you can load customer directly 
            $customer = $this->customerRepository->getById($customer_id);
            $quote->setCurrency();
            $quote->assignCustomer($customer); //Assign quote to customer
            
            //add items in quote
            $product_name = array();
            $options = array();
            foreach ($orderData['items'] as $item) {
                $product = $this->_product->load($item['product_id']);
                
                 $params = array(
                    'product' => $item['product_id'],
                    'qty' => $item['qty']
                );
                 
                if ($customOptions = $product->getOptions()) {
                    foreach ($customOptions as $o) {
                        if ($o->getTitle() == 'Payment Type') {
                            foreach ($o->getValues() as $value) {
                                //$options[$value['option_id']] = $value['option_type_id'];
                                //$options[] = $value['option_type_id'];
                                $optionId = $value['option_id'];
                                $options[$value['title']] = $value['option_type_id'];
                            }
                            
                            $paymentType = $this->isLoan($tek_quote_id) ? 'Loan': 'Bank Transfer';
                            //$params['options'] = [$optionId => $options[$paymentType]];
                            $params['options'] = [$optionId => $paymentType];
                        }
                    }
                }
                //echo '<pre>';print_r($params);echo '</pre>';die;
                $objParam = new \Magento\Framework\DataObject();
                $objParam->setData($params);
                $quote->addProduct($product, $objParam);
                $product_name[] = $product->getName();
                /*
                //$product->setPrice($item['price']);
                $quote->addProduct($product, $params);
                */
            }

            //Set Address to quote
            $quote->getBillingAddress()->addData($orderData['shipping_address']);
            $quote->getShippingAddress()->addData($orderData['shipping_address']);

            // Collect Rates and Set Shipping & Payment Method

            $shippingAddress = $quote->getShippingAddress();
            $shippingAddress->setCollectShippingRates(true)
                    ->collectShippingRates()
                    //->setShippingMethod('freeshipping_freeshipping'); //shipping method 
                    ->setShippingMethod('flatrate_flatrate'); //shipping method 
            
            $paymentMethod = $this->isLoan($tek_quote_id) ? 'checkmo': 'banktransfer';
            $quote->setPaymentMethod($paymentMethod); //payment method
            $quote->setInventoryProcessed(false); //not effetc inventory
            // Set Sales Order Payment
            $quote->getPayment()->importData(['method' => 'checkmo']);
            $quote->save(); //Now Save quote and your quote is ready
            // Collect Totals
            $quote->collectTotals();
            
            // Create Order From Quote
            $quote = $this->cartRepositoryInterface->get($quote->getId());
            $orderId = $this->cartManagementInterface->placeOrder($quote->getId());
            $order = $this->order->load($orderId);

            if ($order->getEntityId()) {
                $order->setEmailSent(1);
                $increment_id = $order->getRealOrderId();
                
                $result['status'] = 1;
                $result['order_id'] = $order->getEntityId();
                $result['increment_id'] = $increment_id;
                $result['customer_id'] = $customer_id;
                $result['product_name'] = implode(', ', $product_name);
                $result['message'] = 'Order successfully placed';
                
                /*****************Temporary code for testing purpose******************/
                try {
                    $order->setSerialNumber1('SR5698789878');
                    $order->setEngineNumber1('EN5698789878');
                    $order->setManufacturingYear1('2017');
                    $order->setDeliveryDate1(date('Y-m-d h:i:s'));
                    $order->setChassisNumber1('CH5896457898');
                    $order->save();
                }
                catch(Exception $e){
                    //
                }
            } else {
                $result = ['status' => 0, 'message' => 'Order is not placed, Please try again'];
            }

            return $result;
        } catch (\Exception $e) {
            $this->_logger->debug($e->getMessage());
            return ['status' => 0, 'message' => 'Something went wrong. Please try again later. <span class="text-danger">' . $e->getMessage().'</span>'];
        }
    }
    

    public function getQuote($quote_id) {
        try {
            return $this->_tekInfoQuote->create()->load($quote_id);
        } catch (\Exception $e) {
            $this->_logger->debug($e->getMessage());
            return false;
        }
    }

    public function isExchange($quote_id) {
        try {
            return $this->getQuote($quote_id)->getIsExchange();
        } catch (\Exception $e) {
            $this->_logger->debug($e->getMessage());
            return false;
        }
    }

    public function isLoan($quote_id) {
        try {
            return $this->getQuote($quote_id)->getIsLoan();
        } catch (\Exception $e) {
            $this->_logger->debug($e->getMessage());
            return false;
        }
    }

    public function getEnquiryCustomerData($enquiryCustomerId) {
        $response = [];
        try {
            $_check = $this->_enquiryCustomerFactory->create()->load($enquiryCustomerId);
            if (($_check->getName() && $_check->getEmail() && $_check->getStreetName() && $_check->getVillage() && $_check->getTehsil() && $_check->getDistrict() && $_check->getState() && $_check->getCountry() && $_check->getPostCode() ) == '') {
                $response['status'] = 0;
                $response['message'] = 'Some Fields like Name, Email, Street Name, Village, Tehsil, District, State, Country and Postcode are required. Kindly save the customer detail first.';
                return $response;
            } else {
                $response['status'] = 1;
                $response['message'] = $_check->getData();
                return $response;
            }
            //return true;
        } catch (\Exception $e) {
            $this->_logger->debug($e->getMessage());
            return ['status' => 0, 'message' => 'Something went wrong. Please try again later. <span class="text-danger">' . $e->getMessage().'</span>'];
        }
    }

    public function updateExchange($quote_id, $orderId) {
        try {
            $exchange = $this->_tekinfoExchangeFactory->create()->load($quote_id, 'quote_id');
            $order = $this->order->load($orderId);
            foreach ($order->getAllItems() as $item) {
                $_product = $this->_productFactory->create()->load($item->getProductId());
                if ($_product->getAttributeSetId() == self::ATTRIBUTE_SET_ID) {
                    $exchangeCollection = $this->_tractorExchangeFactory->create()->getCollection();
                    $exchangeCollection->addFieldToFilter('order_id', array('eq' => $orderId));

                    if ($exchangeCollection->getSize() == 0) {
                        $tractorExchange = $this->_tractorExchangeFactory->create();
                        $tractorExchange->setOrderId($orderId);
                        $tractorExchange->setOrderItemId($item->getProductId());
                        $tractorExchange->setTractorMake($exchange->getTractorMake());
                        $tractorExchange->setTractorModel($exchange->getTractorModel());
                        $tractorExchange->setManufacturerYear($exchange->getManufacturerYear());
                        $tractorExchange->setTyreCondition($exchange->getTyreCondition());
                        $tractorExchange->setHours($exchange->getHours());
                        $tractorExchange->setIsAccidental($exchange->getIsAccidental());
                        $tractorExchange->setCustomerExpectedPrice($exchange->getCustomerExpectedPrice());
                        $tractorExchange->setImageFrontPath($exchange->getImageFrontPath());
                        $tractorExchange->setImageBackPath($exchange->getImageBackPath());
                        $tractorExchange->setImageLeftPath($exchange->getImageLeftPath());
                        $tractorExchange->setImageRightPath($exchange->getImageRightPath());
                        $tractorExchange->setRcCopyPath($exchange->getRcCopyPath());
                        $tractorExchange->setAssignedBroker($exchange->getAssignedBroker());
                        $tractorExchange->setBrokerQuotePrice($exchange->getBrokerQuotePrice());
                        $tractorExchange->setAssignedMolAnmol($exchange->getAssignedMolAnmol());
                        $tractorExchange->setMolAnmolQuotePrice($exchange->getMolAnmolQuotePrice());
                        $tractorExchange->save();
                    }
                }
            }
            return true;
        } catch (\Exception $e) {
            $this->_logger->debug($e->getMessage());
            return false;
        }
    }

    public function updateLoan($quote_id, $orderId) {
        try {
            $loan = $this->_tekinfoLoanapplicationFactory->create()->load($quote_id, 'quote_id');
            $order = $this->order->load($orderId);
            foreach ($order->getAllItems() as $item) {
                $_product = $this->_productFactory->create()->load($item->getProductId());
                if ($_product->getAttributeSetId() == self::ATTRIBUTE_SET_ID) {
                    $loanCollection = $this->_loanApplicationFactory->create()->getCollection();
                    $loanCollection->addFieldToFilter('order_id', array('eq' => $orderId));

                    if ($loanCollection->getSize() == 0) {
                        $tratorLoan = $this->_loanApplicationFactory->create();
                        $tratorLoan->setOrderId($loan->getOrderId());
                        $tratorLoan->setOrderItemId($item->getProductId());
                        $tratorLoan->setApplicantName($loan->getApplicantName());
                        $tratorLoan->setApplicantMobileNumber($loan->getApplicantMobileNumber());
                        $tratorLoan->setApplicantAltMobileNumber($loan->getApplicantAltMobileNumber());
                        $tratorLoan->setApplicantEmail($loan->getApplicantEmail());
                        $tratorLoan->setStreetName($loan->getStreetName());
                        $tratorLoan->setCountryId($loan->getCountryId());
                        $tratorLoan->setStateId($loan->getStateId());
                        $tratorLoan->setDistrictId($loan->getDistrictId());
                        $tratorLoan->setTehsilId($loan->getTehsilId());
                        $tratorLoan->setPostCode($loan->getPostCode());
                        $tratorLoan->setAgricultureDocumentPath($loan->getAgricultureDocumentPath());
                        $tratorLoan->setBankId($loan->getBankId());
                        $tratorLoan->save();
                    }
                }
            }
            return true;
        } catch (\Exception $e) {
            $this->_logger->debug($e->getMessage());
            return false;
        }
    }

    public function updateKyc($quote_id, $orderId) {
        try {
            $tekinfoKyc = $this->_tekinfoKycFactory->create()->load($quote_id, 'quote_id');
            $order = $this->order->load($orderId);
            foreach ($order->getAllItems() as $item) {
                $_product = $this->_productFactory->create()->load($item->getProductId());
                if ($_product->getAttributeSetId() == self::ATTRIBUTE_SET_ID) {
                    $kycCollection = $this->_kycFactory->create()->getCollection();
                    $kycCollection->addFieldToFilter('order_id', array('eq' => $orderId));
                    if ($kycCollection->getSize() == 0) {
                        $tractorkyc = $this->_kycFactory->create();
                        $tractorkyc->setOrderId($orderId);
                        $tractorkyc->setOrderItemId($item->getProductId());
                        $tractorkyc->setIdProofImagePath($tekinfoKyc->getIdProofImagePath());
                        $tractorkyc->setIdProofType($tekinfoKyc->getIdProofType());
                        $tractorkyc->setIdProofSerialNo($tekinfoKyc->getIdProofSerialNo());
                        $tractorkyc->setAddressProofImagePath($tekinfoKyc->getAddressProofImagePath());
                        $tractorkyc->setAddressProofType($tekinfoKyc->getAddressProofType());
                        $tractorkyc->setAddressProofSerialNo($tekinfoKyc->getAddressProofSerialNo());
                        $tractorkyc->save();
                    }
                }
            }
            return true;
        } catch (\Exception $e) {
            $this->_logger->debug($e->getMessage());
            return false;
        }
    }

    public function updateInsurance($quote_id, $orderId) {
        try {
            $tekinfoInsurance = $this->_tekinfoInsuranceFactory->create()->load($quote_id, 'quote_id');

            $order = $this->order->load($orderId);
            foreach ($order->getAllItems() as $item) {
                $_product = $this->_productFactory->create()->load($item->getProductId());
                if ($_product->getAttributeSetId() == self::ATTRIBUTE_SET_ID) {
                    $insuranceCollection = $this->_vehicleInsuranceFactory->create()->getCollection();
                    $insuranceCollection->addFieldToFilter('order_id', array('eq' => $orderId));
                    //echo "<pre>"; print_r($insuranceCollection->getData()); echo "</pre>"; exit();
                    if ($insuranceCollection->getSize() == 0) {
                        $tractorInsurance = $this->_vehicleInsuranceFactory->create();
                        $tractorInsurance->setOrderId($orderId);
                        $tractorInsurance->setOrderItemId($item->getProductId());
                        $tractorInsurance->setInsuranceOptionsId($tekinfoInsurance->getInsuranceOptionsId());
                        $tractorInsurance->save();
                    }
                }
            }
            return true;
        } catch (\Exception $e) {
            $this->_logger->debug($e->getMessage());
            return false;
        }
    }

    public function updateQuote($quote_id) {
        try {
            $quote = $this->_tekInfoQuote->create()->load($quote_id);
            $quote->setStatus(0);
            $quote->save();
            return true;
        } catch (\Exception $e) {
            $this->_logger->debug($e->getMessage());
            return false;
        }
    }

}