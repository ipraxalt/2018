<?php
namespace Sigma\DisabledPgByCustomergroup\Model;

class PayWay extends \MisterSoft\PayWay\Model\PayWay {
		
	/**
     * Retrieve payment method title
     *
     * @return string
     */
    public function getTitle()
    {
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$customerSession = $objectManager->get('Magento\Customer\Model\Session');
		
		if(null !== $customerSession){
			if($customerSession->isLoggedIn()) {
				if($customerSession->getCustomerGroupId() == 12){
					return 'Vitural Card Payment (via PayWay secure payments)';
				}
			}
		}
        return $this->getConfigData('title');
    }
}