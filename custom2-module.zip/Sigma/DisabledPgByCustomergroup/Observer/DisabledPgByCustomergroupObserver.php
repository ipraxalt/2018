<?php
namespace Sigma\DisabledPgByCustomergroup\Observer;

class DisabledPgByCustomergroupObserver implements \Magento\Framework\Event\ObserverInterface
{
	public function execute(\Magento\Framework\Event\Observer $observer)
	{
		$result = $observer->getEvent()->getResult();
		$method_instance = $observer->getEvent()->getMethodInstance();
		$quote = $observer->getEvent()->getQuote();
		
		/* If Cusomer  group is match then work */
		if(null !== $quote){
			if($quote->getCustomerGroupId() == 12){
				if($method_instance->getCode() == 'purchaseorder'){
					$result->setData('is_available', false);
				}
			}
		}
	}
}