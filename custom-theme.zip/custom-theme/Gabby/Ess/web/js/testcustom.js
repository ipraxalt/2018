require(["jquery"], function($){
    alert("test custom js");
});