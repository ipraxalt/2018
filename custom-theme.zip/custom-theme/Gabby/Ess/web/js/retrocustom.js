require(["jquery"], function($){
    alert("retro custom js called");
});