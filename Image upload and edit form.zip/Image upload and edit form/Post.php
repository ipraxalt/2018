<?php
namespace Company\Test\Controller\Index; 
use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Filesystem\DirectoryList; 
 use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\ObjectManager;
 
class Post extends Action{

protected $fileId = 'avatar';

    public function execute(){
		   $object_manager = $this->_objectManager;
		   
		    $id=3;
		    $bannerImg = $this->getRequest()->getPostValue("avtar");
			$data=[];
			$data['avtar']=$bannerImg;
			$data['name']='laxmi';
		    $fileId = 'avatar';
		   //$data=$this->getRequest();
		   $redirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
		   
		   try {
			   		$uploader = new \Magento\MediaStorage\Model\File\Uploader(
						$fileId,
						$object_manager->create('Magento\MediaStorage\Helper\File\Storage\Database'),
						$object_manager->create('Magento\MediaStorage\Helper\File\Storage'),
						$object_manager->create('Magento\MediaStorage\Model\File\Validator\NotProtectedExtension')
					);
					   // $uploader = $this->_objectManager->create('Magento\Core\Model\File\Uploader', array('fileId' => 'image'));
					 
						$uploader->setAllowedExtensions(array('jpg', 'jpeg', 'gif', 'png'));
						$uploader->setAllowRenameFiles(true);
						$uploader->setFilesDispersion(true);
						
						$mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')
							->getDirectoryRead(DirectoryList::MEDIA);
							$customerId='laxmi';
							
						$result = $uploader->save($mediaDirectory->getAbsolutePath('avatar/'.$customerId));						
						if($result){
			                //return $redirect;
							//unset($result['tmp_name']);
						    //unset($result['path']);
							$this->messageManager->addSuccess( __('image save'));
						    $data['avtar'] = $result['name'];	
						}					
						
				} catch (Exception $e) {
					//$data['image'] = $_FILES['image']['name'];
					  $this->messageManager->addError($e->getMessage());
					  $redirect->setUrl("/Magento21/test");
			          return $redirect;
				}
			
			$model = $this->_objectManager->create("Company\Test\Model\Test");
			 if($id) {
                $model->load($id);
            }
			
			$model->setData('name', $data['name']);    
            $model->setData('avtar', $data['avtar']);			
			try {
				 $model->save();
                $this->messageManager->addSuccess(__(' Exchange Details Has been Updated.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    //$this->_redirect('*/*/edit', array('tractor_exchange_id' => $model->getId(), '_current' => true));
					 $this->_redirect('*/*/');   
                    return;
                }
                $this->_redirect('*/*/');
                return;
            } catch (\Magento\Framework\Model\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the banner.'));
            }

            $this->_getSession()->setFormData($data);
            //$this->_redirect('*/*/edit', array('banner_id' => $this->getRequest()->getParam('banner_id')));
            $this->_redirect('*/*/');           
		    return;
			
	}
}