<?php
session_start();
include_once('comp/session_check.php');
include_once('comp/header.php');
include_once('comp/left_column.php');

/**
 * Template Name: Client Csv Import
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that other
 * 'pages' on your WordPress site will use a different template.
 * @package WordPress
 * @subpackage Twenty_Thirteen
 * @since Twenty Thirteen 1.0
 */

$compName=$_SESSION['company_name'];
$memId=$_SESSION['member_id'];

?>
<div class="col-sm-9 col-md-9 col-lg-9">
<div class="title">
<h2> Import Client <?php echo ucfirst($case); ?> </h2>
</div>

	
<div class="middle-sec">  
 <div class="row">
   <div class="col-sm-12 col-md-12 col-lg-12 ">
    <div class="table-responsive">
	<table class="table table-bordered worker-info" width="98%" align="center">
	<tbody>
	<?php 
if(isset($_POST['submit'])){
//if(isset($_POST['mode']) && $_POST['rg_submit'] == 'submit'){
	//$target_dir= ABSPATH.'wp-content\uploads\clientcsv/';
	$upload_dir = wp_upload_dir();
	 $url=$upload_dir['basedir'];
	$target_dir= $url.'/clientcsv/';
	$newName=time().'.csv';
	$target_file = $target_dir.$newName ;
    if (@move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
		importData($target_file );
	} else {
		echo $successmsg= "<span id='lblError' style='color: red;'>Sorry, there was an error uploading csv file.</span>";
	}
}
/*start importData function*/
	function importData($csv_file){
		if(!empty( $_FILES["file"]['name'])){
		$i=0;
	   if (($handle = fopen($csv_file, "r")) !== FALSE) {
		   while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
			  
           	  $num = count($data);
				for ($c=0; $c < $num; $c++) {
				$col[$c] = $data[$c];
				}
				
           	        $case_id = $col[0]; 
					 $plaint_name = $col[1];
					$case_name = $col[2];
					$funded_date = $col[3]; //date
					$accident_date = $col[4];  //date
					$amount = $col[5]; 
					$attorney_name = $col[6]; 
					$subscr_investor = $col[7]; 
					$case_status = $col[8]; 
					$case_comments = $col[9]; 
					$plaint_dob = $col[10];  //date
					$attorney_firm = $col[11]; 
					$plaint_name_search = $col[12]; 
					$case_name_search = $col[13]; 
					$attorney_name_search = $col[14]; 
					$attorney_firm_search = $col[15];
					$date_entered=$col[16]; //date
					$plaint_last4ssn = $col[17];
					$plaint_lastname = $col[18];
					$plaint_firstname = $col[19];
					$plaint_middlename = $col[20];
					$date_last_modified = $col[21];   //date
					$subscr_state = $col[22];
					$plaint_lastname_temp = $col[23];
					$FunderCaseId = $col[24];
					$firm_id = $col[25];


					if($funded_date!=""){
					$caldateall="";
					/*Convert date in db y-m-d H:i:s formate*/
					$caldate = explode(" ", $funded_date);
					$calDateVal=$caldate[0]; 
					$caldateall = explode("/",$calDateVal);
					$m1=$caldateall[0]; //month
					$d1=$caldateall[1]; //date
					$y1=$caldateall[2]; //year
					$calTimeVal=$caldate[1]; //time
					$funded_date=$y1."-".$m1."-".$d1." ".$calTimeVal;
					$funded_date = date("Y-m-d H:i:s", strtotime($funded_date));
					}else{
					$funded_date="";
					}
					if($accident_date!=""){
					$caldateall="";
					/*Convert date in db y-m-d H:i:s formate*/
					$caldate = explode(" ", $accident_date);
					$calDateVal=$caldate[0]; 
					$caldateall = explode("/",$calDateVal);
					$m1=$caldateall[0]; //month
					$d1=$caldateall[1]; //date
					$y1=$caldateall[2]; //year
					$calTimeVal=$caldate[1]; //time
					$accident_date=$y1."-".$m1."-".$d1." ".$calTimeVal;
					$accident_date = date("Y-m-d H:i:s", strtotime($accident_date));
					}else{
					$accident_date="";
					}

					if($plaint_dob!=""){
					$caldateall="";
					/*Convert date in db y-m-d H:i:s formate*/
					$caldate = explode(" ", $plaint_dob);
					$calDateVal=$caldate[0]; 
					$caldateall = explode("/",$plaint_dob);
					$m1=$caldateall[0]; //month
					$d1=$caldateall[1]; //date
					$y1=$caldateall[2]; //year
					$calTimeVal=$caldate[1]; //time
					$plaint_dob=$y1."-".$m1."-".$d1." ".$calTimeVal;
					$plaint_dob = date("Y-m-d H:i:s", strtotime($plaint_dob));
					}else{
					$plaint_dob="";
					}

					if($date_entered!=""){
					$caldateall="";
					/*Convert date in db y-m-d H:i:s formate*/
					$caldate = explode(" ", $date_entered);
					$calDateVal=$caldate[0]; 
					$caldateall = explode("/",$date_entered);

					$m1=$caldateall[0]; //month
					$d1=$caldateall[1]; //date
					$y1=$caldateall[2]; //year
					//$calTimeVal1=$caldate[1]; //time
					$date_entered=$d1."-".$m1."-".$y1;

					$date_entered = date("Y-m-d H:i:s", strtotime($date_entered));
					}else{
					$date_entered="";
					}

					if($date_last_modified!=""){
					$caldateall="";
					/*Convert date in db y-m-d H:i:s formate*/
					$caldate = explode(" ", $date_last_modified);
					$calDateVal=$caldate[0]; 
					$caldateall = explode("/",$date_last_modified);
					$m1=$caldateall[0]; //month
					$d1=$caldateall[1]; //date
					$y1=$caldateall[2]; //year
					$date_last_modified=$d1."-".$m1."-".$y1;
					$date_last_modified = date("Y-m-d H:i:s", strtotime($date_last_modified));
					}else{
					$date_last_modified="";
					}
					 /*Create array for insert data into table*/		
        $insertData = array(
		    'case_id' =>$case_id, 
			'plaint_name' =>$plaint_name,
			'case_name' =>$case_name,
			'funded_date' => $funded_date,
			'accident_date' =>$accident_date,
			'amount' =>$amount,
			'attorney_name'=>$attorney_name,
			'subscr_investor' =>$subscr_investor,
			'case_status' =>$case_status,
			'case_comments' =>$case_comments,
			'plaint_dob' =>$plaint_dob,
			'attorney_firm' =>$attorney_firm,
			'plaint_name_search' =>$plaint_name_search,
			'case_name_search' =>$case_name_search,
			'attorney_name_search' =>$attorney_name_search,
			'attorney_firm_search'=>$attorney_firm_search,
			'date_entered'=>$date_entered,
			'plaint_last4ssn'=>$plaint_last4ssn,
			'plaint_lastname'=>$plaint_lastname,
			'plaint_firstname'=>$plaint_firstname,
			'plaint_middlename'=>$plaint_middlename,
			'date_last_modified'=>$date_last_modified,
			'subscr_state'=>$subscr_state,
			'plaint_lastname_temp'=>$plaint_lastname_temp,
			'FunderCaseId' =>$FunderCaseId,
			'firm_id' =>$firm_id);
			global $wpdb;
			if($i>=1){
				
				if($wpdb->insert('wp_case_info',$insertData)){
				    $uploadStatus=1;
				}else{
				     $uploadStatus=0;	
                     		}
			}
				
			 $i++;		
	        } //endwhile
		if($uploadStatus==1){
			echo $successmsg="<span id='lblError' style='color: red;'>CSV upload successfully</span>";
		}if($uploadStatus==0){
		   
           echo $successmsg="<span id='lblError' style='color: red;'>Data incorrect CSV have not uploaded. </span>";
        }
        }//end if		
		}	
	}
	/*end importData function*/
?>
	   <form method="post" role="form" id="rg_form" name="rg_form" class="form-horizontal reg-inputs" enctype="multipart/form-data" action="" onsubmit="return validate();">
		<div class="rows">
		   <span id="lblError" style="color: red;"></span><br />
        </div>		
		<div class="col-md-6">
		   <div class="form-group">
		   <div class="error_box errorHandler alert alert-danger1 no-display" id="error_box" style="color:red;">
           </div>
		    	<input type="hidden"  name="memberid"  id="memberid" value="<?php echo $memId;?>">
			</div>	
            <div class="form-group">
			Check CSV format <a href="http://americanlegalfin.com/wp-content/uploads/test.csv" target="_blank"> here</a>
			</div>			
            <div class="form-group">
				<label class="control-label lbs">Upload Csv <span class="symbol required">*</span>
				</label><input type="file" name="file" id="file" value="" class="uploadss" />
			</div>
                  
        <input type="hidden" name="mode"  value="csv_upload">
			<div class="form-group">
                 <div style=" padding-right: 64px;">
						<input type="submit" value="Submit" name='submit' class="btn btn-primary btn-wide">
				</div>
			</div>
			
		  </div>
		      <div class="col-md-6">
			  </div>
		 </form>
	  </div>
	</table>
  </div>
</div>

</div>
<div class="clearfix"></div>
</div> 
<script>
 setTimeout(function() {  jQuery("#lblError").html(''); }, 9000);
  	function validate() {
		jQuery('#lblError').html(''); 
		  var fileUpload=jQuery("#file").val();
		     var actionVal=jQuery("#action").val();
			var flag=0;
		    var allowedFiles = [".csv"];
           var lblError = $("#lblError");



        if (fileUpload == null || fileUpload == "") {
                lblError.html('Please upload csv file');
               jQuery("#fileUpload").css('border','1px solid red');
               flag=1;
                return false;
          }
		  else{
              jQuery("#fileUpload").css('border','1px solid #E7E7E7');
          }
           var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(" + allowedFiles.join('|') + ")$");
            if (!regex.test(fileUpload.toLowerCase())) {
                lblError.html("Please upload files having extensions <b>" + allowedFiles.join(', ') + "</b> only");
                return false;
            }
          lblError.html('');  


       if(flag==0){ 
	    
          return true;		  
        } else{
			return false;
		}   
}
</script> 
</div> 
<?php include_once('comp/footer.php'); ?>
<style>
.uploadss{display:inline-block !important;}
.lbs{width:25% !Important;}
</style>