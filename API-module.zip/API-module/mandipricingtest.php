<?php
ini_set('display_errors', '1');
error_reporting(E_ALL);
use \Magento\Framework\App\Bootstrap;
include('app/bootstrap.php');

// add bootstrap
$bootstrap = Bootstrap::create(BP, $_SERVER);
$objectManager = $bootstrap->getObjectManager();
$obj = \Magento\Framework\App\ObjectManager::getInstance();
$storeManager = $obj->get('\Magento\Store\Model\StoreManagerInterface');

$helper = $objectManager->get('Escorts\MandiPricing\Helper\Data');
$help = $helper->getMarketsDetails();
echo "<pre>+++"; print_r($help); echo "</pre>";
exit();

