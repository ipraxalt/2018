<?php
namespace Escorts\MandiPricing\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * {@inheritdoc}
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
	
        $installer = $setup;

        $installer->startSetup();

		/**
         * Create table 'escorts_markets'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('escorts_markets')
        )
		->addColumn(
            'id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'id'
        )
		->addColumn(
            'state',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'state'
        )
		->addColumn(
            'district',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'district'
        )
		->addColumn(
            'market_name',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'market_name'
        )
		->addColumn(
            'timestamp',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'timestamp'
        )
		        
		/*{{CedAddTableColumn}}}*/
		
		
        ->setComment(
            'Escorts Markets escorts_markets'
        );
		
		
		$installer->getConnection()->createTable($table);

        /**
         * Create table 'escorts_markets_commodity'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('escorts_markets_commodity')
        )
        ->addColumn(
            'id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'id'
        )
        ->addColumn(
            'commodity',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'commodity'
        )
        ->addColumn(
            'variety',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'variety'
        )
        ->addColumn(
            'arrival_date',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'arrival_date'
        )
        ->addColumn(
            'min_price',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'min_price'
        )
        ->addColumn(
            'max_price',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'max_price'
        )
        ->addColumn(
            'modal_price',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'modal_price'
        )
        ->addColumn(
            'market_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'market_id'
        )       
        /*{{CedAddTableColumn}}}*/
        
        
        ->setComment(
            'Escorts Markets Commodity escorts_markets_commodity'
        );

        $installer->getConnection()->createTable($table);
        $installer->endSetup();

    }
}
