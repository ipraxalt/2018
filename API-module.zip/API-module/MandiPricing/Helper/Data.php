<?php
/**
 * Copyright © 2015 Escorts . All rights reserved.
 */
namespace Escorts\MandiPricing\Helper;


class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
     /**
	 * @var \Magento\Framework\HTTP\Client\Curl
	 */
	protected $_curl;
	/**
	 * @var \Escorts\MandiPricing\Model\Markets
	 */
	protected $_markets;


	/**
	 * @var \Escorts\MandiPricing\Model\Commodity
	 */
	protected $_commodity;
	
	
	
	protected $jsonHelper;
	/**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\HTTP\Client\Curl $curl
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper   
	 * @param \Escorts\MandiPricing\Model\MarketsFactory $_markets
	 * @param \Escorts\MandiPricing\Model\CommodityFactory $_commodity
     */
	 
	
	 
	public function __construct(
		\Magento\Framework\App\Helper\Context $context,
		\Magento\Framework\HTTP\Client\Curl $curl,
		\Magento\Framework\Json\Helper\Data $jsonHelper,
		\Escorts\MandiPricing\Model\MarketsFactory $_markets,
		\Escorts\MandiPricing\Model\CommodityFactory $_commodity
		
	) {
		$this->_curl = $curl;
		$this->_markets = $_markets;
		$this->_commodity = $_commodity;
		
		$this->jsonHelper = $jsonHelper;		
		parent::__construct($context);
	}
	
	
	public function getMarketApiCredentials() {
        return array(
            'current_url' => 'https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070',
            'api_key' =>  '579b464db66ec23bdd00000106d15decacb141c0410e87ec97cf4458',
            'offset' =>  '0',
            'limit' =>  '300'            
        );
    }
	
	public function getMarketsDetails()
	{   
	    $credentials = $this->getMarketApiCredentials();
	    $url = $credentials['current_url'].'?api-key='.$credentials['api_key'].'&format=json&offset='.$credentials['offset'].'&limit=1';
		$this->_curl->get($url);
		$response = $this->_curl->getBody();
		$result = $this->jsonHelper->jsonDecode($response);
		$count = $result['total'];
		
		
		for( $i=3002; $i<= $count; $i++){    
		   
 		    $current_url = $credentials['current_url'].'?api-key='.$credentials['api_key'].'&format=json&offset='.$i.'&limit='.$credentials['limit'];
		    $this->_curl->get($current_url);
			$response = $this->_curl->getBody();
			$result = $this->jsonHelper->jsonDecode($response);
			$resultArray = $result['records'];			
			$filteredResultArray = $this->multi_array_search_with_condition($resultArray, array( 'state' => 'Punjab')); 

			
			$marketData=[]; $commodityData=[];			
			foreach($filteredResultArray as $subArray){                
				$marketData[$subArray["market"]] = ["timestamp"=>$subArray["timestamp"], "state"=>$subArray["state"], "district"=>$subArray["district"], "market_name"=>$subArray["market"]];
				$commodityData[$subArray["commodity"]] = ["commodity"=>$subArray["commodity"], "variety"=>$subArray["variety"], "arrival_date"=>$subArray["arrival_date"], "min_price"=>$subArray["min_price"], "max_price"=>$subArray["max_price"], "modal_price"=>$subArray["modal_price"],"market_name"=>$subArray["market"]];
			}
	
		  	foreach($marketData as $markets){			
				
			    $item = $this->_markets->create();
				//$item = $this->_objectManager->create('Escorts\MandiPricing\Model\Markets');
				$item->setState($markets['state']);
				$item->setDistrict($markets['district']);
				$item->setMarketName($markets['market_name']);			
				$item->setTimestamp($markets['timestamp']);				  
				$item->save();
				echo "done";die;
			}
	
			/*foreach($commodityData as $comm){			
				$item = $this->_objectManager->create("Escorts\MandiPricing\Model\Commodity");
				$item->setCommodity($comm['commodity']);
				$item->setVariety($comm['variety']);
				$item->setArrivalDate($comm['arrival_date']);			
				$item->setMinPrice($comm['min_price']);	
				$item->setMaxPrice($comm['max_price']);	
				$item->setModalPrice($comm['modal_price']);	
				$item->setMarketId($comm['market']);		
				$item->save();
			}
			*/
			
				
		}
		
	}
	
	
	
	protected function multi_array_search_with_condition($array, $condition){
    $foundItems = array();
    foreach($array as $item)    {
        $find = TRUE;
        foreach($condition as $key => $value)        {
            if(isset($item[$key]) && $item[$key] == $value)
            {
                $find = TRUE;
            } else {
                $find = FALSE;
            }
        }
        if($find){
            array_push($foundItems, $item);
        }
    }
    return $foundItems;
}

	
}