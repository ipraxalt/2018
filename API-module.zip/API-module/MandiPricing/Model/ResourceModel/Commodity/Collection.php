<?php

namespace Escorts\MandiPricing\Model\ResourceModel\Commodity;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Escorts\MandiPricing\Model\Commodity', 'Escorts\MandiPricing\Model\ResourceModel\Commodity');
        
    }

}
?>