<?php
namespace Escorts\PaymentMethodFilter\Observer;
class Disabledbypaymenttypeobserver implements \Magento\Framework\Event\ObserverInterface
{

  const ATTRIBUTE_SET_ID = 13;
  
  public function execute(\Magento\Framework\Event\Observer $observer)
  {
  
	$result = $observer->getEvent()->getResult();
	$method_instance = $observer->getEvent()->getMethodInstance();
	$quote = $observer->getEvent()->getQuote();
	
	
	/*Load current cart items from quote*/
	$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
	$cart = $objectManager->get('\Magento\Checkout\Model\Cart'); 
	$itemsCollection = $cart->getQuote()->getItemsCollection();
	$itemsVisible = $cart->getQuote()->getAllVisibleItems();
	$items = $cart->getQuote()->getAllItems();
		
		
	foreach($items as $item) {

			$product_id=$item->getProductId();
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$product = $objectManager->create('Magento\Catalog\Model\Product')->load($product_id);
			$attributeSetIdvalue= $product->getAttributeSetId();
			
			/*Attribute set check for Tractor */
			if($attributeSetIdvalue== self::ATTRIBUTE_SET_ID){ 

			    $options = ""; 
				$options = $item->getProduct()->getTypeInstance(true)->getOrderOptions($item->getProduct());
				 
				if (isset($options['options'])) {				
					$customOptions = $options['options'];
					
					if (!empty($customOptions)) {
						foreach ($customOptions as $option) {
							$optionTitle = $option['label'];
							
							/*Contition check only for product custom option payment type*/
							
							if($optionTitle == "Payment Type"  &&  $option['option_type']== "radio"){						   
									$optionId = $option['option_id'];           
									$optionValue = $option['value'];
								    
									/*Disable payment method banktransfer for custom option value loan */
									if($optionValue=="Loan"){							 
										if($method_instance->getCode() == 'banktransfer'){
												$result->setData('is_available', false);
										}
										if($method_instance->getCode() == 'ccavenue'){
												$result->setData('is_available', true);
										}
									}
									
									/*Disable payment method ccavenue for custom option value Bank Transfer */
									if($optionValue=="Bank Transfer"){							
										if($method_instance->getCode() == 'ccavenue'){
												$result->setData('is_available', false);
										}
										if($method_instance->getCode() == 'banktransfer'){
												$result->setData('is_available', true);
										}
									}
							}							
						}					
					}
				}					
		 }//Attribute set check
    }
  }
}