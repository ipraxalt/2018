<?php
namespace Escorts\PaymentMethodFilter\Observer;

class Attributesettypecheckobserver implements \Magento\Framework\Event\ObserverInterface
{



    protected $_messageManager;
	const ATTRIBUTE_SET_ID = 13;
	const ITEM_COUNT = 1;
  
    /**
     * @param \Magento\Framework\Message\ManagerInterface $messageManager
     */
    public function __construct( \Magento\Framework\Message\ManagerInterface $messageManager)
    {
        $this->_messageManager = $messageManager;
    }
	
  public function execute(\Magento\Framework\Event\Observer $observer)
  {
  
		/*Load current cart items from quote*/
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$cart = $objectManager->get('\Magento\Checkout\Model\Cart'); 
		$itemsCollection = $cart->getQuote()->getItemsCollection();
		$itemsVisible = $cart->getQuote()->getAllVisibleItems();
		$items = $cart->getQuote()->getAllItems();
		$productCount=0;
			
		foreach($items as $item) {	    
			$product_id=$item->getProductId();
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$product = $objectManager->create('Magento\Catalog\Model\Product')->load($product_id);
			$attributeSetIdvalue= $product->getAttributeSetId();
			/*Attribute set check for Tractor */
			if($attributeSetIdvalue==self::ATTRIBUTE_SET_ID){ 	
				$productCount++;
			}
		}
  
        /*Load current quote items*/
		$event = $observer->getEvent();
		$request = $observer->getEvent()->getRequest();
		$_quoteProductID = $request->getPost('product');		   
		  
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$quoteProduct = $objectManager->create('Magento\Catalog\Model\Product')->load($_quoteProductID);
		$quoteAttributeSetId= $quoteProduct->getAttributeSetId();
			
        if($quoteAttributeSetId==self::ATTRIBUTE_SET_ID ){	
			
		    if(  $productCount >= self::ITEM_COUNT) {			       
				   $observer->getRequest()->setParam('product', false);
				   //$observer->getRequest()->setParam('return_url', $this->_redirect->getRefererUrl())
				   $this->_messageManager->addError(__('You can add only one product of Tractor Attribute Set'));
					//set false if you not want to add product to cart
					
					return $this;
					
				}
		 }

  }
  
  
}